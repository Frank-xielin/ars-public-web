<script lang="ts" setup>
defineProps<{
  isGlobal?: boolean
}>()
</script>

<template>
  <div :class="['loading-img', { 'table-loading': !isGlobal }]">
    <video src="/loading.mp4" loop autoplay height="80" width="80"></video>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.loading-img {
  display: inline-block;
  height: 80px;
  width: 80px;
  background: @bgClor_main;
  border-radius: 80px;
  box-shadow: 0px 4px 60px 0px rgba(0, 38, 115, 0.2);
  overflow: hidden;
  &.table-loading {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translateX(-50%);
  }
  > video {
    margin: 0;
    padding: 0;
    pointer-events: none;
  }
}
</style>
