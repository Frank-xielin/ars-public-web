import { ApprovalListParams, ApprovalListRes } from '@/models/home/approval'
import { ApprovalToastRes } from '@/models/home/approvalToast'
import { request } from '@/utils/httpConfig'

/** 待审批 - 获取 */
export function pendingApprovalApi(data: ApprovalListParams) {
  return request<ApprovalListRes>({
    url: 'v5/public/approval/get/todo',
    method: 'get',
    data
  })
}

/** 已提交 - 获取 */
export function submitApprovalApi(data: ApprovalListParams) {
  return request<ApprovalListRes>({
    url: 'v5/public/approval/get/submitted',
    method: 'get',
    data
  })
}

/** 仅获取审批弹窗表格数据  */
export function approvalToastApi(id: number) {
  return request<ApprovalToastRes>({
    url: `v5/public/approval/nodes/id/${id}`,
    method: 'get'
  })
}
