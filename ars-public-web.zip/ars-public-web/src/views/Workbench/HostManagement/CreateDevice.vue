<script lang="ts" setup>
import { useAllClientList } from '@/composables/systemSettings/clientInformation'
import {
  requireInput,
  requireSelect
} from '@/composables/systemSettings/clusterInformation/addEditCluster'
import { softwareList, useCreateDevices } from '@/composables/workbench/hostManagement'
import { BatchCreateDevicesItem } from '@/models/workbench/hostManagement'
import { Form } from 'ant-design-vue'
import { ref, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  minerId: string
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()

const formModel = ref<BatchCreateDevicesItem>({
  client_id: '',
  product_model: '',
  sn: '',
  software_type: ''
})
const rules = ref<Utils.RulesObject<BatchCreateDevicesItem>>({
  sn: [requireInput('主机SN')],
  client_id: [requireInput('所属客户')],
  software_type: [requireSelect('软件角色')],
  product_model: [requireInput('产品型号')]
})
const form = Form.useForm(formModel, rules)
const { batchAddDevices } = useCreateDevices(() => {
  emit('search')
  onCancel()
})
const { clients, getAllClients } = useAllClientList()

function onCancel() {
  form.resetFields()
  emit('update:visible', false)
}
async function onSubmit() {
  try {
    await form.validate()
    batchAddDevices(props.minerId, [formModel.value])
  } catch (e) {}
}
watch(
  () => props.visible,
  visible => {
    if (visible) {
      getAllClients()
    }
  }
)
</script>

<template>
  <a-modal
    title="添加主机"
    :visible="visible"
    @cancel="onCancel"
    @ok="onSubmit"
    :ok-button-props="{ disabled: !$auth(20) }"
  >
    <a-form :label-col="{ span: 5 }">
      <a-form-item label="主机SN" v-bind="form.validateInfos.sn">
        <a-input v-model:value="formModel.sn" />
      </a-form-item>
      <a-form-item label="所属客户" v-bind="form.validateInfos.client_id">
        <custom-select
          :data="clients"
          value-field="id"
          label-field="name"
          v-model:value="formModel.client_id"
        />
      </a-form-item>
      <a-form-item label="软件角色" v-bind="form.validateInfos.software_type">
        <custom-select :data="softwareList" v-model:value="formModel.software_type" />
      </a-form-item>
      <a-form-item label="产品型号" v-bind="form.validateInfos.product_model">
        <a-input v-model:value="formModel.product_model" />
      </a-form-item>
    </a-form>
  </a-modal>
</template>
