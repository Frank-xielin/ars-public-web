<script lang="ts" setup>
import { useApprovalLinkOperations } from '@/composables/systemSettings/approvalProcess/linkOperationsModal'
import { asyncRouteGetter } from '@/utils/routerController'
import { watch } from 'vue'

const props = defineProps<{
  visible: boolean
  approvalId: number
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()

const { approvalOperationList, checkedKeys, initOperations, changeOperationByApprovalId } =
  useApprovalLinkOperations(() => {
    emit('update:visible', false)
    emit('search')
    asyncRouteGetter()
  })

watch(
  () => props.visible,
  visible => {
    if (visible) {
      initOperations(props.approvalId)
    } else {
      checkedKeys.value = []
    }
  }
)
</script>

<template>
  <a-modal
    :visible="visible"
    title="关联操作"
    @cancel="$emit('update:visible', false)"
    @ok="changeOperationByApprovalId(approvalId)"
  >
    <a-tree
      v-if="approvalOperationList.length"
      checkable
      default-expand-all
      :tree-data="approvalOperationList"
      :height="500"
      v-model:checked-keys="checkedKeys"
    />
  </a-modal>
</template>
