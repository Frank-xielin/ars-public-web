export interface RoleListAllParams extends Utils.SearchVO {
  search: string
}

export interface RoleListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string
  name: string
  status: number
  sort: number
  keyword: string
  created_by: string
  note: string
  client_id: number
}

export interface RoleListAllRes extends Utils.PageVO {
  list: RoleListItem[]
}

export interface CreateRoleParams {
  owned_customer: number
  name: string
  note: string
}

export type UpdateRoleParams = CreateRoleParams
