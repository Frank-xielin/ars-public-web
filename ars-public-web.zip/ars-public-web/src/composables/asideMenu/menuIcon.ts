export const menuIcons = new Map([
  ['首页', 'icon-nav_icon_home'],
  ['工作台', 'icon-nav_icon_workbench'],
  ['作业管理', 'icon-nav_icon_workmgt1'],
  ['日志管理', 'icon-nav_icon_logmgt'],
  ['系统设置', 'icon-nav_icon_systemsettings']
])
