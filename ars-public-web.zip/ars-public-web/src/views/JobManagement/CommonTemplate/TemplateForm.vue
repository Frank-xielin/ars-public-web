<script lang="ts" setup>
import { useUpdateTemplate } from '@/composables/jobManagement/commonTemplate/checkTemplate'
import { useCreateTemplate } from '@/composables/jobManagement/commonTemplate/createTemplate'
import { useTemplateTypeAllList } from '@/composables/jobManagement/commonTemplate/templateTypeTable'
import { CreateTemplateParams, TemplateInfoRes } from '@/models/jobManagement/commonTemplate'
import router from '@/router'
import { ref, toRefs, unref, watch } from 'vue'
import CreateTemplateTypeModal from './CreateTemplateTypeModal.vue'
import TemplateTypeTable from './TemplateTypeTable.vue'

export interface TemplateFormExpose {
  onSubmitForm: () => Promise<void>
}

const props = withDefaults(
  defineProps<{
    id?: number
    type: '编辑' | '新建'
    model?: TemplateInfoRes | null
  }>(),
  { id: 0 }
)
const emit = defineEmits<{
  (event: 'submit'): void
}>()
const { id } = toRefs(props)

const typeShow = ref(false)
const typeListShow = ref(false)
const formObject = initFormObject()
const { dataSource: typeList, run } = useTemplateTypeAllList()

function initFormObject() {
  if (props.type === '新建') {
    const { formModel, form, submitForm } = useCreateTemplate(afterSubmit)
    return { formModel: unref(formModel), form, submitForm }
  } else {
    const { formModel, form, submitForm } = useUpdateTemplate(id, afterSubmit)
    return { formModel: unref(formModel), form, submitForm }
  }
}
function afterSubmit() {
  emit('submit')
  if (props.type === '新建') {
    router.push('/JobManagement/CommonTemplate')
  }
}
function searchTypes() {
  run().catch()
}
searchTypes()

watch(
  () => props.model,
  model => {
    if (model && props.type === '编辑') {
      const obj: CreateTemplateParams = {
        content: model.content,
        enabled: model.enabled,
        name: model.template_name,
        note: model.note,
        type_id: model.template_type_id
      }
      Object.assign(formObject.formModel, obj)
    }
  },
  { deep: true }
)

defineExpose({
  onSubmitForm: formObject.submitForm
})
</script>

<template>
  <div>
    <a-form class="create-form" :label-col="{ span: 3 }">
      <a-form-item label="模板类型" v-bind="formObject.form.validateInfos.type_id">
        <custom-select
          :data="typeList"
          value-field="id"
          label-field="name"
          style="width: 55%"
          v-model:value="formObject.formModel.type_id"
        />
        <a-button type="link" @click="typeShow = true">添加模板类型</a-button>
        <a-button type="link" @click="typeListShow = true">管理模板类型</a-button>
      </a-form-item>
      <a-form-item label="模板名称" v-bind="formObject.form.validateInfos.name">
        <a-input v-model:value="formObject.formModel.name" />
      </a-form-item>
      <a-form-item label="模板内容" v-bind="formObject.form.validateInfos.content">
        <a-textarea class="content-textarea" v-model:value="formObject.formModel.content" />
      </a-form-item>
      <a-form-item label="备注">
        <a-input v-model:value="formObject.formModel.note" />
      </a-form-item>
    </a-form>

    <create-template-type-modal v-model:visible="typeShow" @change="searchTypes()" />
    <template-type-table v-model:visible="typeListShow" @change="searchTypes()" />
  </div>
</template>

<style scoped lang="less">
.create-form {
  width: 650px;
  margin: auto;
  .content-textarea {
    width: 100%;
    height: 267px;
  }
}
</style>
