import {
  BindPrincipalParams,
  ClusterListAllRes,
  ClusterListRes,
  ClustersByUserRes,
  CreateClusterParams,
  PrincipalListRes,
  UpdateClusterParams
} from '@/models/systemSettings/clusterInformation'
import { defaultPager } from '@/utils/dataJudgement'
import { request } from '@/utils/httpConfig'

/**
 * 获取集群列表-all
 * @returns
 */
export function clusterListAllApi() {
  return request<ClusterListAllRes>({
    url: 'v5/public/miner/get/all',
    method: 'GET',
    loading: true
  })
}

/**
 * 获取集群列表-page
 * @param vo 分页信息
 * @returns
 */
export function clusterListApi(vo?: Utils.SearchVO) {
  return request<ClusterListRes>({
    url: 'v5/public/miner/get/list',
    method: 'get',
    data: defaultPager(vo)
  })
}

/**
 * 新建集群 - 单个
 * @param data
 * @returns
 */
export function createClusterApi(data: CreateClusterParams) {
  return request({
    url: 'v5/public/miner/create/one',
    method: 'POST',
    data,
    loading: true
  })
}

/**
 * 编辑集群
 * @param id 目标集群的 id
 * @param data
 * @returns
 */
export function updateClusterApi(id: number, data: UpdateClusterParams) {
  return request({
    url: `v5/public/miner/update/id/${id}`,
    method: 'put',
    data,
    loading: true
  })
}

/** 负责人列表列表 - 全部 （只展示绑定的用户） */
export function principalsListAllApi(miner_id: string) {
  return request<PrincipalListRes>({
    url: 'v5/public/miner/head/get/all',
    method: 'get',
    data: { miner_id },
    loading: true
  })
}

/**
 * 添加负责人 - 绑定多个
 * @param data
 * @returns
 */
export function bindPrincipalApi(data: BindPrincipalParams) {
  return request({
    url: 'v5/public/miner/head/update/bind',
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 根据当前登录用户id获取集群列表 - 分页
 * @param vo 分页信息
 */
export function clustersByUserApi(vo?: Utils.SearchVO) {
  return request<ClustersByUserRes>({
    url: 'v5/public/miner/get/list/by_user',
    method: 'get',
    data: defaultPager(vo),
    loading: true
  })
}
