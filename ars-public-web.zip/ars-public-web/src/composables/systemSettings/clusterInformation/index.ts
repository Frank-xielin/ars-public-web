import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { ClusterListItem, PrincipalListItem } from '@/models/systemSettings/clusterInformation'
import {
  bindPrincipalApi,
  clusterListAllApi,
  clusterListApi,
  principalsListAllApi
} from '@/services/systemSettings/clusterInformation'
import { message } from 'ant-design-vue'
import { ref } from 'vue'

export const columns: Utils.ColumnField<ClusterListItem>[] = [
  { title: '集群ID', dataIndex: 'miner' },
  { title: '所属客户', dataIndex: 'client_name' },
  { title: '域名', dataIndex: 'domain' },
  { title: '扇区大小', dataIndex: 'sector_size' },
  { title: '备注', dataIndex: 'note' },
  { title: '集群负责人', dataIndex: 'principal' },
  { title: '操作', dataIndex: 'miner' }
]

export function useClusterList() {
  const dataSource = ref<ClusterListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()

  const { run: clustersFetch, loading } = useRequest(clusterListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  function handleSearch(vo?: Utils.SearchVO) {
    try {
      return clustersFetch(vo ?? { page: 1, page_size: pageVo.value.page_size })
    } catch (e) {}
  }

  return { dataSource, pageVo, loading, handleSearch }
}

/** 获取已绑定的负责人列表 */
export function usePrincipalList(successFn?: () => void) {
  const bindedUsers = ref<PrincipalListItem[]>([])

  const { run: listFetch } = useRequest(principalsListAllApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        bindedUsers.value = data || []
      } else {
        message.error(msg)
      }
    }
  })

  async function onSubmit(miner: string, list: number[]) {
    try {
      const reply = await bindPrincipalApi({ miner_id: miner, user_ids: list })
      if (reply.code === 0) {
        message.success('添加负责人成功')
        successFn && successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { bindedUsers, listFetch, onSubmit }
}

/** 全量集群数据 */
export function useClusterAllList() {
  const dataSource = ref<ClusterListItem[]>([])

  async function searchAllClusters() {
    try {
      const reply = await clusterListAllApi()
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { dataSource, searchAllClusters }
}
