<script lang="ts" setup>
import { columns } from '@/composables/jobManagement/commandExecution/chooseDeviceModal'
import { softwareList, useMachineListOfCluster } from '@/composables/workbench/hostManagement'
import { DeviceListItem } from '@/models/workbench/hostManagement'
import { message } from 'ant-design-vue'
import { RowSelectionType } from 'ant-design-vue/es/table/interface'
import { cloneDeep } from 'lodash-es'
import { ref, watch } from 'vue'

const props = withDefaults(
  defineProps<{
    visible: boolean
    clusterId: string
    selectType?: RowSelectionType
    selectedDevices: DeviceListItem[]
  }>(),
  { selectType: 'radio' }
)
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'select', val: DeviceListItem[]): void
}>()

const selectedRows = ref<DeviceListItem[]>([])
const { dataSource, searchForm, form, loading, pageVo, minerId, handleSearch } =
  useMachineListOfCluster()

function selectionHandler(_: Utils.Key[], rows: DeviceListItem[]) {
  selectedRows.value = rows
}
function onSubmit() {
  if (!selectedRows.value.length) {
    message.warn('至少选择一条数据！')
    return
  }
  emit('select', selectedRows.value)
  emit('update:visible', false)
}

watch(
  () => props.visible,
  visible => {
    if (visible) {
      minerId.value = props.clusterId
      selectedRows.value = cloneDeep(props.selectedDevices)
      handleSearch()
    } else {
      form.resetFields()
      dataSource.value.length = 0
      selectedRows.value.length = 0
    }
  }
)
</script>

<template>
  <a-modal
    title="选择主机"
    :visible="visible"
    :width="1000"
    @cancel="$emit('update:visible', false)"
    :footer="null"
  >
    <a-form class="device-search-form" layout="inline">
      <a-form-item label="软件角色">
        <custom-select
          :data="softwareList"
          style="width: 150px"
          v-model:value="searchForm.software_type"
          @change="handleSearch()"
        />
      </a-form-item>
      <a-form-item class="search-input-item">
        <custom-search-input
          placeholder="集群SN/IP"
          v-model:value="searchForm.sn_ip"
          @search-func="handleSearch()"
        />
      </a-form-item>
    </a-form>
    <a-table
      v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
      row-key="id"
      :scroll="$scroller(400)"
      :columns="$columnsSetter(columns)"
      :row-selection="
        $tableSelection({
          type: selectType,
          selectedRowKeys: selectedRows.map(row => row.id),
          onChange: selectionHandler
        })
      "
    >
      <template #bodyCell="{ column, text }">
        <span v-if="column.title === '软件角色'">
          {{ softwareList.find(item => item.value === text)?.label }}
        </span>
      </template>
    </a-table>
    <footer class="footer-operation">
      <a-button @click="$emit('update:visible', false)">取消</a-button>
      <a-button type="primary" @click="onSubmit">确认</a-button>
    </footer>
  </a-modal>
</template>

<style scoped lang="less">
.device-search-form {
  position: relative;
  margin-bottom: 20px;
  .search-input-item {
    position: absolute;
    right: 0;
  }
}
.footer-operation {
  display: flex;
  justify-content: flex-end;
  padding: 20px 0;
  button {
    margin-left: 20px;
  }
}
</style>
