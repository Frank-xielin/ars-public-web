import { ButtonProps, SelectProps, TableProps } from 'ant-design-vue'
import { CSSProperties, HTMLAttributes } from 'vue'

export interface FormRenderOptions<FormData = any, TableCols = any> {
  /** 搜索字段 */
  queryParams: QueryParams<FormData>[]
  /** 是否启用分页 */
  pager?: boolean
  /** 搜索初始条件 */
  initialValues: FormData
  /** 是否不需要在一开始就触发搜索 */
  manaul?: boolean
  /** 表格设置 */
  tableConfigs: {
    /** 列设置，同 antd 的 columns */
    columns: Utils.ColumnField<TableCols>[]
    /** 获取表格数据时触发的请求 */
    onSearch: (
      params: FormData,
      vo?: Utils.SearchVO
    ) => void | Promise<SearchResponse<TableCols> | void>
    /** 更详细的 table 设置 */
    tableProps?: TableProps<TableCols> & HTMLAttributes
  }
  /** 是否需要重置按钮 */
  reset?:
    | {
        text?: string
        itemStyle?: CSSProperties
        onReset?: () => void
      }
    | boolean
}

export interface SearchResponse<T> {
  res: T[]
  vo?: Utils.PageVO | null
}

export interface QueryParams<T> {
  /** 表单项的前置文字 */
  formLabel?: string
  /** 表单项字段名 */
  label: T extends string ? T : keyof T
  /** 字段输入类型 */
  type: 'select' | 'input' | 'search' | 'date-picker' | 'time-picker'
  /** 时间、日期选择器是否需要起始点，默认值：['start_time', 'end_time'] */
  range?: [T extends string ? T : keyof T, T extends string ? T : keyof T]
  placeholder?: string
  /** form-item 的样式设置 */
  itemStyle?: CSSProperties
  /** 时间选择器的格式化设置，默认值：YYYY-MM-DD HH:mm:ss */
  format?: string
  /** 输入框的样式设置 */
  style?: CSSProperties
  /** 下拉框的配置 */
  selectOptions?: {
    /** 下拉框的选择列表 */
    data: any[]
    /** 选择值的字段 */
    valueField?: string
    /** 展示值的字段 */
    labelField?: string
  } & SelectProps
  /** 按钮属性，同 Button 组件 */
  buttonProps?: ButtonProps & HTMLAttributes & { text: string }
  onChange?: (...args: any[]) => void
}
