import IconFont from '@/components/Icons'
import { App } from 'vue'

/** 注册全局组件 */
export function componentRegistration(app: App<Element>) {
  app.component('icon-font', IconFont)
}
