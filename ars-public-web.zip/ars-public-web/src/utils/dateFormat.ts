import dayjs from 'dayjs'

/**
 * 时间数据格式化
 * @param date
 * @param format 目标格式，默认为 YYYY-MM-DD HH:mm:ss
 */
export function dateFormatter(value: string | number | Date, format = 'YYYY-MM-DD HH:mm:ss') {
  const dateObj = dayjs(value)
  if (value && dateObj.isValid()) {
    return dateObj.format(format)
  }
  return ''
}
