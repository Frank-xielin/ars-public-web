import { FuncListItem, MenuListItem } from '@/models/systemSettings/userManagement/auth'
import {
  menuFuncListApi,
  permissionsByRoleApi,
  updateAuthOfRoleApi
} from '@/services/systemSettings/userManagement/auth'
import { message } from 'ant-design-vue'
import { DataNode } from 'ant-design-vue/lib/tree'
import { Ref, ref } from 'vue'

export interface AuthItemInfo extends DataNode {
  id: number
  display: boolean
  menu_id?: number
  parent_id?: number
  children?: AuthItemInfo[]
}

/** 获取所有菜单功能数据 */
export function useAllMenuFuncList() {
  const menuList = ref<MenuListItem[]>([])
  const funcList = ref<FuncListItem[]>([])
  const menuFuncList = ref<AuthItemInfo[]>([])

  async function getAllMenuFuncList() {
    const reply = await menuFuncListApi()
    const { code, data, msg } = reply
    if (code === 0) {
      menuList.value = data?.menu || []
      funcList.value = data?.func || []
    } else {
      message.error(msg)
    }
  }

  function dataProcess() {
    const originList: AuthItemInfo[] = menuList.value.map(item => ({
      key: `menu-${item.id}`,
      id: item.id,
      parent_id: item.parent_id,
      title: `${item.name}(${!item.parent_id && item.name !== '首页' ? '模块' : '页面'})`,
      display: item.display
    }))
    originList.push(
      ...funcList.value.map(item => ({
        key: `func-${item.id}`,
        id: item.id,
        menu_id: item.menu_id,
        title: `${item.name}(功能)`,
        display: item.display
      }))
    )

    menuFuncList.value = originList.filter(first => {
      // 将菜单和功能放在一起做成树状结构
      if (!first.menu_id) {
        const children = originList.filter(second => {
          return (second.parent_id === first.id || second.menu_id === first.id) && second.display
        })
        if (children.length) {
          first.children = children
        }
      }

      return first.parent_id === 0 && first.display
    })
  }

  return { menuList, funcList, menuFuncList, dataProcess, getAllMenuFuncList }
}

/** 获取指定角色的权限数据 */
export function usePermissionOfRole() {
  const menus = ref<number[]>([])
  const funcs = ref<number[]>([])

  async function getAuthsByRole(id: number) {
    const reply = await permissionsByRoleApi(id)
    const { code, data, msg } = reply
    if (code === 0) {
      menus.value = data?.menu_ids || []
      funcs.value = data?.func_ids || []
    } else {
      message.error(msg)
    }
  }

  return { menus, funcs, getAuthsByRole }
}

interface CheckedKeys {
  checked: string[]
  halfChecked: string[]
}

/** 修改角色的权限信息 */
export function useChangeRolesAuthInfo(successFn?: () => void) {
  const expandedKeys = ref<Utils.Key[]>([])
  const checkedKeys = ref<CheckedKeys>({
    checked: [],
    halfChecked: []
  })

  const { menus, funcs, getAuthsByRole } = usePermissionOfRole()
  const { menuList, funcList, menuFuncList, getAllMenuFuncList, dataProcess } = useAllMenuFuncList()
  const { selectAllChildren, checkHandler } = useComplexSelectionHandle(checkedKeys)

  async function initCheckedData(id: number) {
    await getAllMenuFuncList()
    dataProcess()
    await getAuthsByRole(id)
    const arr: Utils.Key[] = []
    menuFuncList.value.forEach(first => {
      first.key && arr.push(first.key)
    })
    const checkedList = [
      ...new Set([
        ...funcs.value.map(funcId => `func-${funcId}`),
        ...menus.value.map(menuId => `menu-${menuId}`)
      ])
    ]
    expandedKeys.value = arr
    checkedKeys.value.checked = checkedList
  }

  async function changeAuth(roleId: number) {
    if (!checkedKeys.value.checked.length) {
      message.warn('请设置至少一项权限')
      return
    }

    const result = checkedDataHandler(funcList.value, menuList.value, checkedKeys.value.checked)
    try {
      const reply = await updateAuthOfRoleApi(roleId, { menu_func: result })
      if (reply.code === 0) {
        message.success('修改权限成功')
        successFn?.()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return {
    checkedKeys,
    expandedKeys,
    menuFuncList,
    selectAllChildren,
    checkHandler,
    initCheckedData,
    changeAuth
  }
}

interface ParentNode extends AuthItemInfo {
  parent?: ParentNode
}

/**
 * 复杂勾选逻辑实现
 * @param checkedKeys
 * @returns
 */
const useComplexSelectionHandle = (checkedKeys: Ref<CheckedKeys>) => {
  const selectAllChildren = (e: any) => {
    const currentSelect: string = e.node.key
    const checkedList: string[] = []
    if (!checkedKeys.value.checked.includes(currentSelect)) {
      checkedList.push(currentSelect)
    }
    const children: AuthItemInfo[] | undefined = e.node.children
    if (children?.length) {
      selectChildren(children, checkedList)
    }
    const parent: ParentNode | undefined = e.node.parent
    parent && checkParents(parent)
    checkedKeys.value.checked.push(...checkedList)
  }

  const selectChildren = (list: AuthItemInfo[], checked: string[]) => {
    list.forEach(child => {
      if (child.children?.length) {
        selectChildren(child.children, checked)
      }
      checked.push(child.key as string)
    })
  }

  const checkHandler = (e: any) => {
    const children: AuthItemInfo[] | undefined = e.node.children
    const isCheck: boolean = e.checked
    const deleteKeys: string[] = []
    if (children?.length && !isCheck) {
      removeChildren(children, deleteKeys)
      checkedKeys.value.checked = checkedKeys.value.checked.filter(key => !deleteKeys.includes(key))
    } else if (isCheck) {
      const parent: ParentNode | undefined = e.node.parent
      parent && checkParents(parent)
    }
  }

  const removeChildren = (list: AuthItemInfo[], deleteKeys: string[]) => {
    list.forEach(child => {
      if (child.children?.length) {
        removeChildren(child.children, deleteKeys)
      }
      const targetKey = checkedKeys.value.checked.find(key => child.key === key)
      targetKey && deleteKeys.push(targetKey)
    })
  }

  const checkParents = (node: ParentNode) => {
    const key = node.key as string
    if (!checkedKeys.value.checked.includes(key)) {
      checkedKeys.value.checked.push(key)
    }
    node.parent && checkParents(node.parent)
  }

  return { selectAllChildren, checkHandler }
}

/**
 * 将勾选的菜单功能打包成可用数据
 * @param funcs
 * @param menus
 * @param checkedKeys
 * @returns
 */
function checkedDataHandler(funcs: FuncListItem[], menus: MenuListItem[], checkedKeys: string[]) {
  const availableList: Record<number, number[]>[] = []
  menus.forEach(menu => {
    const isChecked = checkedKeys.find(key => `menu-${menu.id}` === key)
    isChecked && availableList.push({ [menu.id]: [] })
  })
  funcs.forEach(func => {
    const checkedFunc = checkedKeys.find(key => key === `func-${func.id}`)
    if (checkedFunc) {
      const targetMenuArray = availableList.find(item => item[func.menu_id])
      if (targetMenuArray) {
        targetMenuArray[func.menu_id].push(func.id)
      } else {
        availableList.push({ [func.menu_id]: [func.id] })
      }
    }
  })

  return availableList
}
