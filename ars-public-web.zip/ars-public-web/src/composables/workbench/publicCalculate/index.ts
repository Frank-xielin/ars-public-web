import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import {
  CalculateScheduleParams,
  ClustersOfRoomItem,
  DeviceListOfRoomItem,
  DeviceListOfRoomParams
} from '@/models/workbench/publicCalculate'
import {
  calculateScheduleApi,
  clustersOfRoomApi,
  deviceListOfRoomApi
} from '@/services/workbench/publicCalculate'
import { Form, message } from 'ant-design-vue'
import { InjectionKey, provide, Ref, ref, watch } from 'vue'

export const opsStatusList = [
  { label: '主机状态', value: -1 },
  { label: '未工作', value: 0 },
  { label: '在线', value: 1 },
  { label: '离线', value: 2 }
]
export const machineStatusList = [
  { label: '是否故障', value: -1 },
  { label: '正常', value: 1 },
  { label: '故障', value: 2 }
]
export const lotusStatusList = [
  { label: 'lotus状态', value: -1 },
  { label: '未工作', value: 0 },
  { label: '在线', value: 1 },
  { label: '离线', value: 2 }
]

export const MachineRoomIdKey: InjectionKey<Readonly<Ref<number>>> = Symbol('已选择的机房id')

/** 根据机房获取算力机列表 */
export function useCalculateList(successFn?: () => void) {
  const machineRoomId = ref(0)
  const searchModel = ref<Omit<Utils.NoPager<DeviceListOfRoomParams>, 'machine_room_id'>>({
    lotus_server_status: -1,
    machine_status: -1,
    ops_server_status: -1,
    sn_ip: ''
  })
  const dataSource = ref<DeviceListOfRoomItem[]>([])
  const { pageVo, setPageFromData } = usePagination()
  const form = Form.useForm(searchModel)

  provide(MachineRoomIdKey, machineRoomId)

  const { loading, run } = useRequest(deviceListOfRoomApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
        successFn?.()
      } else {
        message.error(msg)
      }
    }
  })

  async function handleSearch(vo?: Utils.SearchVO) {
    const params: DeviceListOfRoomParams = {
      ...searchModel.value,
      machine_room_id: machineRoomId.value,
      page: vo?.page ?? 1,
      page_size: vo?.page_size ?? pageVo.value.page_size
    }
    try {
      run(params)
    } catch (e) {}
  }

  watch(machineRoomId, () => {
    handleSearch()
  })

  return { loading, form, dataSource, machineRoomId, searchModel, pageVo, handleSearch }
}

/**
 * 算力机调度
 * @param selected 需要调度的机器
 * @param successFn
 * @returns
 */
export function useScheduleMachines(
  selected: Utils.Prop<DeviceListOfRoomItem[]>,
  successFn?: () => void
) {
  const selectedCluster = ref('')

  async function scheduleMachines() {
    if (!selectedCluster.value) {
      message.warn('请选择正确的集群')
      return
    }
    try {
      const params: CalculateScheduleParams = {
        purpose_cluster: selectedCluster.value,
        sns: selected.value.map(row => row.device_sn)
      }
      const reply = await calculateScheduleApi(params)
      if (reply.code === 0) {
        message.success('调度成功')
        successFn?.()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { selectedCluster, scheduleMachines }
}

/** 根据机房获取集群 */
export function useGetClusterListByRoom() {
  const clusterList = ref<ClustersOfRoomItem[]>([])

  async function getClusterList(roomId: number) {
    try {
      const reply = await clustersOfRoomApi(roomId)
      const { code, data, msg } = reply
      if (code === 0) {
        clusterList.value = data || []
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { clusterList, getClusterList }
}
