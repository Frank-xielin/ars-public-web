<script lang="ts" setup>
import { analysisHttpbody } from '@/composables/home/approval'
import { columns, opreateStateShift, useApprovalToast } from '@/composables/home/approvalToast'
import {
  colors,
  useApprovalInfo,
  useApprovalRefuseProcess
} from '@/composables/jobManagement/taskManagement/allTaskApi'
import { ApprovalListItem } from '@/models/home/approval'
import { useMainStore } from '@/store'
import { computed, watch } from 'vue'
// 父组件传值
const props = defineProps<{
  visible: boolean
  recordToast: ApprovalListItem | null
  readonly?: boolean
}>()

// 改父组件
const emit = defineEmits(['update:visible', 'isAgreeOperate'])

// 获取表格数据
const { dataSource, loading, handleSearch } = useApprovalToast()

/**
 * 操作审批批准或拒绝
 *外面是直接同意，函数是拒绝
 * */
const { formModel, checkApprove } = useApprovalRefuseProcess(() => {
  emit('isAgreeOperate')
  emit('update:visible')
})
/**
 * 审核操作流
 * @param action 拒绝/同意
 */
function agreeOrRefuseOperate(action: 'approve' | 'reject') {
  formModel.value.action = action
  checkApprove(props.recordToast?.id || 0)
}

// 拿到当前处理人
const { approveInfo, getApprovalInfo } = useApprovalInfo()

const store = useMainStore()
const isActorUser = computed(
  () =>
    !props.readonly &&
    store.userInfo?.id === approveInfo.value?.current_node.approver_id &&
    approveInfo.value?.state === 1
)
watch([() => props.recordToast?.id, () => props.visible], ([id, visible]) => {
  if (id && visible) {
    formModel.value.note = ''
    handleSearch(props.recordToast?.id || 0)
    getApprovalInfo(id)
  }
})
</script>

<template>
  <a-modal
    class="approval-modal"
    :visible="visible"
    title="审批详情"
    :footer="null"
    @cancel="$emit('update:visible', false)"
    width="756px"
  >
    <div class="wrapper">
      <a-descriptions title="" label="Config Info" class="taskdetail" :column="1">
        <a-descriptions-item label="名称">
          {{ recordToast?.target_type === 'task' ? '任务审批' : '操作审批' }}
        </a-descriptions-item>
        <a-descriptions-item label="集群">
          {{ analysisHttpbody(recordToast?.target?.http_body).miner_id }}
        </a-descriptions-item>
        <a-descriptions-item label="操作">{{ recordToast?.target.name }}</a-descriptions-item>
        <a-descriptions-item label="对象">
          <!-- {{ recordToast?.target.devices.map(item => item.device_sn).join() }} -->
          {{ analysisHttpbody(recordToast?.target.http_body).sns.join() }}
        </a-descriptions-item>
        <a-descriptions-item label="留言">
          {{ analysisHttpbody(recordToast?.target.http_body).message }}
        </a-descriptions-item>
      </a-descriptions>
      <a-descriptions label="Config Info" :column="1" class="scriptContent">
        <a-descriptions-item label="提交人">
          {{ recordToast?.submitor.user_name }}
        </a-descriptions-item>
        <a-descriptions-item label="提交时间">{{ recordToast?.updated_at }}</a-descriptions-item>
        <a-descriptions-item label="状态">
          <a-tag :color="colors.find(item => item.id === recordToast?.state)?.color">
            {{ colors.find(item => item.id === recordToast?.state)?.text }}
          </a-tag>
        </a-descriptions-item>
      </a-descriptions>
      <a-descriptions
        v-if="dataSource.length !== 0"
        title="历史审批"
        label="Config Info"
        class="historyApproval"
      >
        <a-descriptions-item>
          <a-table
            v-bind="$tableConfigs(dataSource, loading)"
            :columns="$columnsSetter(columns)"
            class="approvalTable"
          >
            <template #bodyCell="{ column, text }">
              <template v-if="column.title === '审核人'">{{ text.user_name }}</template>
              <template v-else-if="column.title === '审核结果'">
                {{ opreateStateShift.find(item => item.operateId === text)?.shiftName }}
              </template>
              <template v-else-if="column.title === '评论'">{{ text }}</template>
              <span v-else>{{ text }}</span>
            </template>
          </a-table>
        </a-descriptions-item>
      </a-descriptions>
      <a-descriptions v-if="isActorUser" title="评论" label="Config Info" class="historyApproval">
        <a-descriptions-item>
          <a-textarea v-model:value="formModel.note"></a-textarea>
        </a-descriptions-item>
      </a-descriptions>
      <div v-if="isActorUser" class="wrapper__button">
        <a-button class="wrapper__button__approval" @click="agreeOrRefuseOperate('approve')">
          批准
        </a-button>
        <a-button @click="agreeOrRefuseOperate('reject')">拒绝</a-button>
      </div>
    </div>
  </a-modal>
</template>

<style lang="less" scoped>
.wrapper {
  padding-bottom: 20px;
  .taskdetail {
    // background-color: @bgClor_deep;
    padding: 20px 0 0 20px;
  }

  .scriptContent {
    position: absolute;
    top: 102px;
    left: 44%;
  }
  .historyApproval {
    margin: 20px 20px 0px 20px;
    textarea {
      width: 100%;
      min-width: 300px;
      min-height: 74px;
      max-height: 150px;
      margin-bottom: 20px;
    }
    :deep(.ant-descriptions-view > table > tbody > tr > td) {
      padding: 0 !important;
      margin: 0;
    }
  }
  .approvalInfo {
    margin: 20px 0 20px 20px;
  }
  &__button {
    display: flex;
    justify-content: flex-end;
    padding-bottom: 10px;
    margin-right: 20px;
    &__approval {
      margin-right: 10px;
    }
  }
}
</style>
