import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { MessageListItem, MessageListParams } from '@/models/personal/myMessages'
import { messageListApi, messageReadApi } from '@/services/personal/myMessages'
import { message } from 'ant-design-vue'
import { Dayjs } from 'dayjs'
import { ref } from 'vue'

export const columns: Utils.ColumnField<MessageListItem>[] = [
  { title: '时间', dataIndex: 'updated_at' },
  { title: '内容', dataIndex: 'content' },
  { title: '操作', dataIndex: 'id' }
]
const partten = 'YYYY-MM-DD HH:mm:ss'

interface SearchForm extends Utils.NoPager<MessageListParams> {
  dates?: [Dayjs, Dayjs]
}

/** 获取我的消息数据 */
export function useMessageList(successFn?: (val: number) => void) {
  const searchModel = ref<SearchForm>({
    search: '',
    start_date: '',
    end_date: '',
    dates: undefined,
    is_read: undefined // 筛选未读消息字段
  })
  const dataSource = ref<MessageListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()

  const { loading, run } = useRequest(messageListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
        successFn?.(data?.total || 0)
      } else {
        message.error(msg)
      }
    }
  })

  function handleSearch(vo?: Utils.SearchVO) {
    try {
      const values = searchModel.value
      values.start_date = values.dates?.[0].format(partten) || ''
      values.end_date = values.dates?.[1].format(partten) || ''
      const params: MessageListParams = {
        ...values,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params)
    } catch (e) {}
  }

  return { loading, searchModel, dataSource, pageVo, handleSearch }
}

/**
 * 标记指定消息为已读
 * @param successFn
 * @returns
 */
export function useUpdateMsgReadState(successFn: () => void) {
  async function readTargetMessages(ids: number[]) {
    const reply = await messageReadApi(ids)
    if (reply.code === 0) {
      successFn()
    } else {
      message.error(reply.msg)
    }
  }

  return { readTargetMessages }
}
