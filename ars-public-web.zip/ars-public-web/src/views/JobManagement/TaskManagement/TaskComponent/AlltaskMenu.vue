<script lang="tsx" setup>
import {
  colors,
  columns,
  statefilterOptions,
  useAlltaskApproval,
  useDeleteTask,
  useTaskManagement
} from '@/composables/jobManagement/taskManagement/taskManagement'
import { computed, unref } from 'vue'
import { useRouter } from 'vue-router'

const props = defineProps<{
  type: string
}>()

const router = useRouter()
/** 删除任务 */
const { deleteTask } = useDeleteTask(() => handleSearch())
// const { pageVo, searchModel, loading, form, handleSearch, dataSource } = useTaskManagement()

const searcher = computed(() => {
  if (props.type === '1') {
    const { pageVo, searchModel, loading, form, handleSearch, dataSource } = useTaskManagement()
    return { pageVo, searchModel, loading, form, handleSearch, dataSource }
  } else {
    const { pageVo, searchModel, loading, form, handleSearch, dataSource } = useAlltaskApproval()
    return { pageVo, searchModel, loading, form, handleSearch, dataSource }
  }
})
const { pageVo, searchModel, loading, form, handleSearch, dataSource } = unref(searcher)

/** 清空 */
function resetForm() {
  form.resetFields()
  handleSearch()
}

/** 去查看任务 */
function viewTask(id: number) {
  router.push({
    path: '/JobManagement/TaskManagement/ViewTask',
    query: { id, type: 'view' }
  })
}

handleSearch()
</script>

<template>
  <a-form class="search-form-wrapper" layout="inline" @submit="handleSearch()">
    <a-form-item>
      <a-button
        type="primary"
        shape="round"
        @click="$router.push('/JobManagement/TaskManagement/AddTasks')"
        :disabled="!$auth(25, 'menu')"
      >
        添加任务
      </a-button>
    </a-form-item>
    <div class="searchAnddata__task">
      <a-form-item>
        <a-select
          ref="select"
          v-model:value="searchModel.state"
          style="width: 160px; text-align: center"
          :options="statefilterOptions"
          @change="handleSearch()"
        ></a-select>
      </a-form-item>
      <a-form-item>
        <a-range-picker
          separator="至"
          format="YYYY-MM-DD HH:mm:ss"
          v-model:value="searchModel.dates"
          @change="handleSearch()"
          :allow-clear="false"
        />
      </a-form-item>
      <a-form-item>
        <custom-search-input
          class="search-input"
          placeholder="输入关键字搜索"
          v-model:value="searchModel.search"
          @search-func="handleSearch()"
        />
        <a-button @click="resetForm">清空</a-button>
      </a-form-item>
    </div>
  </a-form>
  <a-table
    class="approvalTable contentDiv"
    v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
    :columns="$columnsSetter(columns)"
    :scroll="$scroller('calc(100vh - 400px)')"
  >
    <template #bodyCell="{ column, text, record }">
      <template v-if="column.title === '状态'">
        <a-tag :color="colors.find(item => item.id === record.state)?.color">
          {{ colors.find(item => item.id === record.state)?.text }}
        </a-tag>
      </template>
      <template v-else-if="column.title === '操作'">
        <a-button
          type="link"
          class="table-btn"
          @click="viewTask(record.id)"
          :disabled="!$auth(26, 'menu')"
        >
          查看
        </a-button>
        <a-button
          type="link"
          v-if="record.state === 0"
          class="table-btn"
          @click="deleteTask(record.id)"
          :disabled="!$auth(41)"
        >
          删除
        </a-button>
        <!-- <a-button type="link" v-if="record.state === 0" class="table-btn">提交审批</a-button> -->
        <!-- <a-button type="link" v-if="record.state === 2" class="table-btn">发布</a-button> -->
      </template>
      <!-- 以下是显示除去状态外需要封装悬浮的内容 -->
      <custom-tooltip v-else>{{ text }}</custom-tooltip>
    </template>
  </a-table>
</template>

<style lang="less" scoped>
.search-form-wrapper {
  display: flex;
  position: relative;
  margin: 30px 0 40px 0;
  justify-content: space-between;
  .search-input {
    width: 310px;
    margin-right: 10px;
  }
  .searchAnddata__task {
    display: flex;
  }
}
</style>
