import { DeviceListItem } from '@/models/workbench/hostManagement'

export const columns: Utils.ColumnField<DeviceListItem>[] = [
  { title: '主机SN', dataIndex: 'device_sn' },
  { title: '软件角色', dataIndex: 'software_type' },
  { title: 'IP', dataIndex: 'ips' }
]
