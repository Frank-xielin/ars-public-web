import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { RoleListAllParams, RoleListItem } from '@/models/systemSettings/userManagement/role'
import { deleteRoleApi, roleAllListApi } from '@/services/systemSettings/userManagement/role'
import { message, Modal } from 'ant-design-vue'
import { ref } from 'vue'

export const columns: Utils.ColumnField<RoleListItem>[] = [
  { title: '角色名', dataIndex: 'name' },
  { title: '所属客户', dataIndex: 'client_id' },
  { title: '权限', dataIndex: 'id' },
  { title: '备注', dataIndex: 'note' },
  { title: '自定义', dataIndex: 'keyword' },
  { title: '操作', dataIndex: 'id' }
]

export function deleteRole(id: number, successFn: () => void) {
  Modal.confirm({
    content: '是否删除该角色？',
    async onOk() {
      try {
        const reply = await deleteRoleApi(id)
        if (reply.code === 0) {
          message.success('删除角色成功')
          successFn()
        } else {
          message.error(reply.msg)
        }
      } catch (e) {}
    }
  })
}

export function useRoleAllList() {
  const dataSource = ref<RoleListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()
  const searchModel = ref<Utils.NoPager<RoleListAllParams>>({ search: '' })

  const { run: rolesFetch, loading } = useRequest(roleAllListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  async function handleSearch(vo?: Utils.SearchVO) {
    try {
      const params: RoleListAllParams = {
        ...searchModel.value,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return rolesFetch(params)
    } catch (e) {}
  }

  return { searchModel, dataSource, loading, pageVo, handleSearch }
}
