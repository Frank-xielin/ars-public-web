<script lang="ts" setup>
import { useRoomList } from '@/composables/systemSettings/roomInformation'
import {
  lotusStatusList,
  machineStatusList,
  opsStatusList,
  useCalculateList
} from '@/composables/workbench/publicCalculate'
import { DeviceListOfRoomItem } from '@/models/workbench/publicCalculate'
import { message } from 'ant-design-vue'
import { ref } from 'vue'
import CalculateTable from './PublicCalculate/CalculateTable.vue'
import MachineScheduleModal from './PublicCalculate/MachineScheduleModal.vue'

const selectedRows = ref<DeviceListOfRoomItem[]>([])
const scheduleShow = ref(false)

const { dataSource: roomList, handleSearch: getAllRooms } = useRoomList()
const { loading, form, dataSource, machineRoomId, searchModel, pageVo, handleSearch } =
  useCalculateList(() => {
    selectedRows.value = []
  })

function handleSchedule() {
  if (!selectedRows.value.length) {
    message.warn('至少选择一条数据')
    return
  }
  scheduleShow.value = true
}
function resetForm() {
  form.resetFields()
  handleSearch()
}
getAllRooms({ page: 1, page_size: 10000 }).then(() => {
  machineRoomId.value = roomList.value[0]?.id || 0
})
</script>

<template>
  <div class="public-calculate page">
    <div class="room-selection">
      <h3 class="title">机房</h3>
      <ul class="room-list">
        <li
          v-for="room of roomList"
          :class="['room-list-item', { active: machineRoomId === room.id }]"
          :key="room.id"
          @click="machineRoomId = room.id"
        >
          {{ room.name }}
        </li>
      </ul>
    </div>
    <div class="device-management">
      <h3 class="title">主机</h3>
      <div class="main">
        <a-form layout="inline" class="search-form-wrapper">
          <a-form-item class="operation">
            <a-button type="primary" shape="round" :disabled="!$auth(174)" @click="handleSchedule">
              批量调度
            </a-button>
          </a-form-item>

          <a-form-item class="search-form-item" style="right: 600px">
            <custom-select
              class="form-select"
              :data="machineStatusList"
              v-model:value="searchModel.machine_status"
              @change="handleSearch()"
            />
          </a-form-item>
          <a-form-item class="search-form-item" style="right: 470px">
            <custom-select
              class="form-select"
              :data="opsStatusList"
              v-model:value="searchModel.ops_server_status"
              @change="handleSearch()"
            />
          </a-form-item>
          <a-form-item class="search-form-item" style="right: 340px">
            <custom-select
              class="form-select"
              :data="lotusStatusList"
              v-model:value="searchModel.lotus_server_status"
              @change="handleSearch()"
            />
          </a-form-item>
          <a-form-item class="search-form-item" style="right: 70px">
            <custom-search-input
              style="width: 250px"
              placeholder="主机SN/所在集群/资产归属/IP"
              @search-func="handleSearch()"
            />
          </a-form-item>
          <a-form-item class="search-form-item" style="right: 0">
            <a-button @click="resetForm">清空</a-button>
          </a-form-item>
        </a-form>

        <calculate-table
          :data-source="dataSource"
          :page-vo="pageVo"
          v-model:selected-rows="selectedRows"
          :loading="loading"
          @search="handleSearch"
        />
        <machine-schedule-modal
          :selected-rows="selectedRows"
          v-model:visible="scheduleShow"
          @search="handleSearch(pageVo)"
        />
      </div>
    </div>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.public-calculate {
  display: flex;
  padding: 0 !important;
  background: @backDivColor;
  overflow: hidden !important;
  .title {
    height: 48px;
    padding-left: 20px;
    font-size: 16px;
    font-weight: bold;
    line-height: 50px;
  }
  .room-selection {
    width: 136px;
    height: 100%;
    margin-right: 15px;
    background: @bgClor_main;
    .room-list {
      height: calc(100% - 60px);
      overflow: hidden auto;
      &-item {
        width: 128px;
        height: 44px;
        margin: auto;
        text-align: center;
        font-size: 12px;
        line-height: 44px;
        cursor: pointer;
        .animate(background);
        &:hover,
        &.active {
          background: @ueColor_fifth;
        }
        &.active {
          color: #35a4f5;
        }
      }
    }
  }
  .device-management {
    width: calc(100% - 151px);
    background: @bgClor_main;
    .main {
      height: calc(100% - 50px);
      padding: 0 20px 20px;
      overflow: hidden auto;
    }
    .search-form-wrapper {
      position: relative;
      margin-bottom: 20px;
      .operation {
        margin-right: 50px;
      }
      .search-form-item {
        position: absolute;
        .form-select {
          width: 120px;
        }
      }

      @media screen and (max-width: 1258px) {
        .search-form-item {
          position: unset;
        }
      }
    }
  }
}
</style>
