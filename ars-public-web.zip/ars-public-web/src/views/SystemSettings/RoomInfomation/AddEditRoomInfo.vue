<script lang="ts" setup>
import { useEditRoomInfo } from '@/composables/systemSettings/roomInformation/addEditRoomInfo'
import { ModalType } from '@/composables/workbench/errorRecord'
import { GetRoomListItem } from '@/models/systemSettings/roomInfomation'
import { watch } from 'vue'

const props = defineProps<{
  visible: boolean
  modalType: ModalType
  targetInfo?: GetRoomListItem | null
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'update:targetInfo', val: null): void
  (event: 'search'): void
}>()

const { formModel, form, handleSubmit } = useEditRoomInfo(() => {
  emit('update:targetInfo', null)
  emit('update:visible', false)
  emit('search')
})

watch(
  () => props.visible,
  val => {
    const { modalType, targetInfo } = props
    if (val && modalType === '编辑' && targetInfo) {
      formModel.value = {
        domain: targetInfo.domain,
        machine_name: targetInfo.name,
        machine_site: targetInfo.site,
        note: targetInfo.note,
        scheduling: targetInfo.scheduling
      }
    } else {
      form.resetFields()
    }
  }
)
</script>

<template>
  <a-modal
    :visible="visible"
    :title="`${modalType}机房`"
    @cancel="$emit('update:visible', false)"
    @ok="handleSubmit(modalType, targetInfo?.id)"
  >
    <a-form :label-col="{ span: 7 }">
      <a-form-item label="机房名称" v-bind="form.validateInfos.machine_name">
        <a-input v-model:value="formModel.machine_name" />
      </a-form-item>
      <a-form-item label="机房所在地" v-bind="form.validateInfos.machine_site">
        <a-input v-model:value="formModel.machine_site" />
      </a-form-item>
      <a-form-item label="域名">
        <a-input v-model:value="formModel.domain" />
      </a-form-item>
      <a-form-item label="备注">
        <a-input v-model:value="formModel.note" />
      </a-form-item>
      <a-form-item label="算力机是否可调度">
        <a-checkbox v-model:checked="formModel.scheduling"></a-checkbox>
      </a-form-item>
    </a-form>
  </a-modal>
</template>
