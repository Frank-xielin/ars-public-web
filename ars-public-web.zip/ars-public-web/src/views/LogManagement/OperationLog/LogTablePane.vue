<script lang="ts" setup>
import { useGetCorrectLogs } from '@/composables/logManagement/operationLog/logTablePane'
import { unref } from 'vue'

const { pageVo, dataSource, columns, searchModel, loading, handleSearch } = unref(
  useGetCorrectLogs()
)

handleSearch()
</script>

<template>
  <div class="log-table-pane">
    <a-form class="search-form" layout="inline" @submit="handleSearch()">
      <a-form-item class="search-form-item" style="right: 210px">
        <a-range-picker
          separator="至"
          format="YYYY-MM-DD HH:mm:ss"
          v-model:value="searchModel.dates"
          @change="handleSearch()"
        />
      </a-form-item>
      <a-form-item class="search-form-item" style="right: 0">
        <custom-search-input
          placeholder="输入关键字进行搜索"
          v-model:value="searchModel.key_word"
          @search-func="handleSearch()"
        />
      </a-form-item>
    </a-form>

    <a-table
      v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
      class="table-box"
      row-key="id"
      :scroll="$scroller('calc(100vh - 400px)')"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ text }">
        <custom-tooltip>{{ text }}</custom-tooltip>
      </template>
    </a-table>
  </div>
</template>

<style scoped lang="less">
.search-form {
  position: relative;
  min-height: 32px;
  .search-form-item {
    position: absolute;
  }
}
</style>
