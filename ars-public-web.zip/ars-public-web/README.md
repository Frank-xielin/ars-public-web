# 集群运维系统 v5.0+

## 技术架构

本项目采用 [vue 3.0](https://v3.cn.vuejs.org/guide/composition-api-introduction.html) 配合最新的 [setup script](https://v3.cn.vuejs.org/api/sfc-script-setup.html) 编写，脚手架使用 [vite](https://cn.vitejs.dev/) （因此不支持所有版本的 IE 浏览器），为了代码健壮性和后续维护方便，使用了 typescript 增强类型校验，css 预处理器使用 [less](https://less.bootcss.com/)，UI 组件库使用 [ant-design-vue@3.0.0+](https://next.antdv.com/components/overview-cn/)。为了更好的类型提示，本项目并没有使用 vuex，而是改为 [pinia](https://pinia.esm.dev/)，该状态管理库为 vue 官方开发人员推出的新库，对 ts 支持比 vuex 强很多。

## 项目运行环境

不支持所有版本的 IE 浏览器

Edge >= 16

Chrome >= 61

Firefox >= 60

[点击查看具体支持数据](https://caniuse.com/?search=esm)

## 项目基础配置

.husky 目录下为 git 提交钩子，在提交代码时会自行检测代码错误和类型错误，拦截可能的错误代码。

.vscode 目录为定制的 vscode 配置项，如果需要用到其他的代码编辑器或 IDE，请自行搜索其他的配置进行定制。

configs 目录为项目配置，目前只有一套 antd 的样式参数覆盖

public 为静态文件夹，使用方式与 vue-cli 或者 webpack 相同

src 为项目的代码目录

## 项目结构设计

```
├───assets  资源文件夹
│   ├───images  图片资源
│   └───styles  公共样式
├───common  公共 hooks
├───components  全局公共组件（该目录下的组件不需要手动引入，直接在组件中引用即可）
├───composables 组件的逻辑代码
├───config  项目环境配置
├───models  页面、组件的类型声明
├───router  路由管理
├───services  api 请求管理
├───store 状态管理（pinia）
├───typings 公共类型管理
├───utils 通用工具函数
│   ├───storage 封装的 localStorage api 实例
│   └───vue-tools 注册 vue 的全局组件或者全局功能函数
└───views 页面组件目录树（结构对应路由地址）
```
