import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { UserGroupListItem, UserGroupListParams } from '@/models/systemSettings/userManagement/user'
import { deleteUserGroupApi, userGroupListApi } from '@/services/systemSettings/userManagement/user'
import { requestHandler } from '@/utils/formTools'
import { message } from 'ant-design-vue'
import { inject, ref, watch } from 'vue'
import { ActiveKey } from './'

export const userGroupCols: Utils.ColumnField<UserGroupListItem>[] = [
  { title: '组名', dataIndex: 'name' },
  { title: '父级', dataIndex: 'parent_id' },
  { title: '描述', dataIndex: 'note' },
  { title: '操作', dataIndex: 'id' }
]

export function useGetUserGroupList() {
  const dataSource = ref<UserGroupListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()
  const { loading, run: groupListFetch } = useRequest(userGroupListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  return { loading, pageVo, dataSource, groupListFetch }
}

export function useUserGroupManager() {
  const activeTab = inject(ActiveKey)
  const searchModel = ref<Utils.NoPager<UserGroupListParams>>({ search: '' })

  const { loading, pageVo, dataSource, groupListFetch } = useGetUserGroupList()

  watch(
    () => activeTab?.value,
    act => {
      if (act === 'group') {
        handleSearch()
      }
    },
    { immediate: true }
  )

  async function handleSearch(vo?: Utils.SearchVO) {
    try {
      const params: UserGroupListParams = {
        ...searchModel.value,
        page: vo?.page ?? 0,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return groupListFetch(params)
    } catch (e) {}
  }

  return { loading, pageVo, dataSource, searchModel, handleSearch }
}

/**
 * 删除指定的用户组
 * @param successFn
 * @returns
 */
export function useRemoveUserGroup(successFn: () => void) {
  const { run } = useRequest(deleteUserGroupApi, {
    onSuccess: reply => {
      if (reply.code === 0) {
        successFn()
      }
      requestHandler('删除成功')(reply)
    }
  })

  return { run }
}
