export interface ClusterListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string
  miner: string
  client_name: string
  client_id: number
  machine_room_id: number
  domain: string
  note: string
  sector_size: number
  principal: string[]
}

export interface ClusterListRes extends Utils.PageVO {
  list: ClusterListItem[]
}

export type ClusterListAllRes = ClusterListRes

export interface CreateClusterParams {
  cluster_id: string
  machine_room: number
  owned_customer: number
  sector_size: number
  domain: string
  note: string
}

export type UpdateClusterParams = CreateClusterParams

export interface PrincipalListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string
  miner_id: string
  principal_id: number
}

export type PrincipalListRes = PrincipalListItem[]

export interface BindPrincipalParams {
  miner_id: string
  user_ids: number[]
}

export interface ClustersByUserRes extends Utils.PageVO {
  list: ClusterListItem[]
}
