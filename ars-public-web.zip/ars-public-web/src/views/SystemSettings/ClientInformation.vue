<script lang="ts" setup>
import {
  columns,
  deleteClient,
  useClientList
} from '@/composables/systemSettings/clientInformation'
import { useAddEditModal } from '@/composables/workbench/errorRecord'
import { ClientListItem } from '@/models/systemSettings/clientInformation'
import AddEditClient from './ClientInformation/AddEditClient.vue'

const { visible, modalType, targetInfo, addModal, editModal } = useAddEditModal<ClientListItem>()
const { dataSource, pageVo, loading, handleSearch } = useClientList()
</script>

<template>
  <div class="client-information page">
    <a-button :disabled="!$auth(51)" class="add-btn" type="primary" shape="round" @click="addModal">
      新建客户
    </a-button>

    <a-table
      class="table-box"
      v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
      row-key="id"
      :scroll="$scroller('calc(100vh - 320px)')"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ column: col, text, record }">
        <div v-if="col.title === '操作'">
          <a-button type="link" :disabled="!$auth(52)" class="table-btn" @click="editModal(record)">
            编辑
          </a-button>
          <a-button
            type="link"
            :disabled="!$auth(53)"
            class="table-btn"
            @click="deleteClient(record.id, handleSearch)"
          >
            删除
          </a-button>
        </div>
        <custom-tooltip v-else>
          {{ text }}
        </custom-tooltip>
      </template>
    </a-table>

    <add-edit-client
      v-model:visible="visible"
      :modal-type="modalType"
      :target-info="targetInfo"
      @search="handleSearch(modalType === '编辑' ? pageVo : undefined)"
    />
  </div>
</template>

<style scoped lang="less">
.add-btn {
  position: absolute;
  right: 50px;
}
.table-box {
  margin-top: 55px;
}
</style>
