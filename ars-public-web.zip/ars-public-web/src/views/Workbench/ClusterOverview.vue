<script lang="ts" setup>
import emptyImage from '@/assets/images/empty_table.svg'
import invalidImage from '@/assets/images/miner_invalid.svg'
import { useGetAllClustersInfo } from '@/composables/workbench/clusterOverview'
import ClusterInfo from './ClusterOverview/ClusterInfo.vue'

const { dataSource, isEmpty, errorDescription, searchModel, handleSearch } = useGetAllClustersInfo()

function getCurrentImage(desc: string) {
  return desc.includes('无集群') ? emptyImage : invalidImage
}

handleSearch()
</script>

<template>
  <div class="cluster-overview page">
    <a-empty
      class="empty-content"
      v-show="isEmpty === 'true'"
      :image="getCurrentImage(errorDescription)"
      :image-style="{ height: '323px' }"
      :description="errorDescription"
    />
    <custom-search-input
      class="search-input"
      v-model:value="searchModel.search"
      placeholder="输入客户/集群ID/集群负责人进行搜索"
      @search-func="handleSearch"
    />
    <div class="cluster-list" v-if="isEmpty === 'false'">
      <cluster-info v-for="info of dataSource" :key="info.miner_id" :data="info" />
    </div>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.cluster-overview {
  position: relative;
  width: 100%;
  padding: 20px;
  background: @bgClor_main;
  overflow: hidden !important;

  .empty-content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    :deep(.ant-empty-description) {
      font-size: 22.4px;
      color: @textColor_second;
      letter-spacing: 4px;
    }
  }
  .search-input {
    position: absolute;
    right: 50px;
    width: 300px;
  }
  .cluster-list {
    position: relative;
    top: 50px;
    display: flex;
    flex-wrap: wrap;
    height: calc(100% - 50px);
    overflow: hidden auto;
  }
}
</style>
