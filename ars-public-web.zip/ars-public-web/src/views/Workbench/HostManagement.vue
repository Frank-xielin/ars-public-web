<script lang="ts" setup>
import {
  ApprovalInfo,
  machineStatusList,
  softwareList,
  useCurrentUsersClusterList,
  useDeleteFaultDevices,
  useLotusOperations,
  useMachineListOfCluster,
  workStatusList
} from '@/composables/workbench/hostManagement'
import { useShutdownRebootModal } from '@/composables/workbench/hostManagement/shutdownDevicesModal'
import { DeviceListItem } from '@/models/workbench/hostManagement'
import { ref } from 'vue'
import CreateDevice from './HostManagement/CreateDevice.vue'
import HostTable from './HostManagement/HostTable.vue'
import ImportDevicesModal from './HostManagement/ImportDevicesModal.vue'

const selectedRows = ref<DeviceListItem[]>([])
const createShow = ref(false)
const uploadShow = ref(false)
const formMoreFilter = ref(false)
const approvalInfo = ref<ApprovalInfo>({ visible: false, operation: '', submit: null, func: 0 })

const { dataSource: clusterList, searchCurrentUsersClusters } = useCurrentUsersClusterList()
const { dataSource, loading, minerId, form, statistics, searchForm, pageVo, handleSearch } =
  useMachineListOfCluster(() => {
    selectedRows.value.length = 0
  })
const { rebootOrShutdownModal } = useShutdownRebootModal(minerId, selectedRows, approvalInfo, () =>
  handleSearch(pageVo.value)
)
const { deleteDevices } = useDeleteFaultDevices(minerId, selectedRows, approvalInfo, () =>
  handleSearch(pageVo.value)
)
const { triggerLotus } = useLotusOperations(minerId, selectedRows, approvalInfo, () =>
  handleSearch(pageVo.value)
)

function getCorrectSoftType(typeNum: number) {
  return softwareList.find(item => item.value === typeNum)?.label || ''
}
function resetForm() {
  form.resetFields()
  handleSearch()
}
searchCurrentUsersClusters().then(() => {
  // 第一次先查询所有集群，然后用第一个集群进行主机搜索
  minerId.value = clusterList.value[0]?.miner || ''
})
</script>

<template>
  <div class="host-management page">
    <div class="cluster-selection">
      <h3 class="title">集群</h3>
      <ul class="cluster-list">
        <li
          v-for="cluster of clusterList"
          :class="['cluster-item', { active: minerId === cluster.miner }]"
          :key="cluster.id"
          @click="minerId = cluster.miner"
        >
          {{ cluster.client_name }} {{ cluster.miner }}
        </li>
      </ul>
    </div>
    <div class="cluster-table-content">
      <h3 class="title">主机</h3>
      <div class="main">
        <a-form class="search-form-wrapper" layout="inline">
          <a-form-item>
            <custom-search-input
              style="width: 300px"
              placeholder="集群SN/IP"
              v-model:value="searchForm.sn_ip"
              @search-func="handleSearch()"
            />
          </a-form-item>
          <a-form-item>
            <custom-tooltip :title="formMoreFilter ? '隐藏更多' : '更多条件'">
              <a-button @click="formMoreFilter = !formMoreFilter"><filter-outlined /></a-button>
            </custom-tooltip>
          </a-form-item>
          <div v-show="formMoreFilter" class="more-form-box">
            <a-form layout="vertical">
              <a-form-item label="软件角色">
                <custom-select
                  class="form-select soft"
                  :data="softwareList"
                  v-model:value="searchForm.software_type"
                />
              </a-form-item>
              <a-form-item label="机器状态">
                <custom-select
                  class="form-select"
                  :data="machineStatusList"
                  v-model:value="searchForm.machine_status"
                />
              </a-form-item>
              <a-form-item label="工作状态">
                <custom-select
                  class="form-select"
                  :data="workStatusList"
                  v-model:value="searchForm.worker_status"
                />
              </a-form-item>
              <a-form-item class="form-operator">
                <a-button @click="resetForm">清空</a-button>
                <a-button type="primary" @click="handleSearch()">确定</a-button>
              </a-form-item>
            </a-form>
          </div>
          <a-form-item class="operation-groups">
            <div class="hardware-control">
              <a-button :disabled="!$auth(28)" @click="rebootOrShutdownModal('关机')">
                关机
              </a-button>
              <a-button :disabled="!$auth(23)" @click="rebootOrShutdownModal('重启')">
                重启
              </a-button>
              <a-button :disabled="!$auth(27)" @click="deleteDevices">移除</a-button>
            </div>
            <div class="lotus-control">
              <a-button :disabled="!$auth(29)" @click="triggerLotus('启动Lotus')">
                启动lotus
              </a-button>
              <a-button :disabled="!$auth(30)" @click="triggerLotus('重启Lotus')">
                重启lotus
              </a-button>
              <a-button :disabled="!$auth(31)" @click="triggerLotus('停止Lotus')">
                停止lotus
              </a-button>
            </div>
            <div class="cluster-upload">
              <a-dropdown>
                <a-button><plus-outlined /></a-button>
                <template #overlay>
                  <a-menu>
                    <a-menu-item>
                      <a-button :disabled="!$auth(20)" type="text" @click="createShow = true">
                        添加主机
                      </a-button>
                    </a-menu-item>
                    <a-menu-item>
                      <a-button :disabled="!$auth(21)" type="text" @click="uploadShow = true">
                        批量导入
                      </a-button>
                    </a-menu-item>
                  </a-menu>
                </template>
              </a-dropdown>
              <custom-tooltip title="下载模版">
                <a-button href="devices.csv" download="批量导入机器.csv">
                  <download-outlined />
                </a-button>
              </custom-tooltip>
            </div>
          </a-form-item>
        </a-form>

        <host-table
          :data-source="dataSource"
          :loading="loading"
          :page-vo="pageVo"
          :statistics="statistics"
          v-model:selected-rows="selectedRows"
          @search="handleSearch"
        />
        <create-device v-model:visible="createShow" :miner-id="minerId" />
        <import-devices-modal
          v-model:visible="uploadShow"
          :miner-id="minerId"
          @search="handleSearch()"
        />
        <approval-confirm-modal
          v-model:visible="approvalInfo.visible"
          :objects="
            selectedRows.map(row => `${row.device_sn}(${getCorrectSoftType(row.software_type)})`)
          "
          :func-id="approvalInfo.func"
          :operation="approvalInfo.operation"
          @submit="approvalInfo.submit?.($event)"
        />
      </div>
    </div>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.host-management {
  display: flex;
  padding: 0 !important;
  background: @backDivColor;
  overflow: hidden !important;
  .title {
    height: 48px;
    padding-left: 20px;
    font-size: 16px;
    font-weight: bold;
    line-height: 50px;
  }
  .cluster-selection {
    width: 136px;
    height: 100%;
    margin-right: 15px;
    background: @bgClor_main;
    .cluster-list {
      height: calc(100% - 60px);
      overflow: hidden auto;
      .cluster-item {
        width: 128px;
        height: 44px;
        margin: auto;
        text-align: center;
        font-size: 12px;
        line-height: 44px;
        cursor: pointer;
        .animate(background);
        &:hover,
        &.active {
          background: @ueColor_fifth;
        }
        &.active {
          color: #35a4f5;
        }
      }
    }
  }
  .cluster-table-content {
    width: calc(100% - 151px);
    background: @bgClor_main;
    .main {
      height: calc(100% - 50px);
      padding: 0 20px 20px;
      overflow: hidden auto;
    }
    .search-form-wrapper {
      position: relative;
      margin-bottom: 20px;
      .more-form-box {
        position: absolute;
        top: 40px;
        width: 300px;
        padding: 10px;
        border: @tableBorder;
        background: @bgClor_main;
        z-index: 5;
        :deep(.ant-form-item) {
          margin-bottom: 10px;
        }
        .form-select {
          width: 100%;
        }
        .form-operator {
          :deep(.ant-form-item-control-input-content) {
            display: flex;
            justify-content: space-between;
            .ant-btn {
              width: 46%;
            }
          }
        }
      }
    }
    .operation-groups {
      position: absolute;
      right: 0;
    }
    .hardware-control,
    .lotus-control {
      display: inline-block;
      margin-right: 50px;
    }
    .cluster-upload {
      display: inline-block;
      margin-left: 50px;
    }

    @media screen and (max-width: 1550px) {
      .operation-groups {
        position: unset;
        margin-top: 10px;
      }
    }
  }
}
</style>
