<script lang="ts" setup>
import { useInitSystemConfigs, useLoginUserInfo } from '@/composables/login'
import { ref } from 'vue'
import Account from './Login/Account.vue'
import UpdatePassword from './Login/UpdatePassword.vue'

const count = ref(0)
const handleShow = (num: number) => {
  count.value = num
}
useLoginUserInfo()
useInitSystemConfigs()
</script>

<template>
  <div class="backGroundImage">
    <div class="loginMainArea">
      <div class="left">
        <div></div>
      </div>
      <div class="right">
        <div class="logo-header">
          <svg class="icon svg-icon svg-logo" aria-hidden="true">
            <use href="#iconnav_icon_logo" />
          </svg>
          <h5 class="system-title">集群运维系统</h5>
        </div>
        <account v-if="count === 0" @next-page="handleShow" />
        <update-password v-else @back-login="handleShow" />
      </div>
    </div>
  </div>
</template>

<style lang="less">
@import (reference) '@/assets/styles/index.less';

.login-page {
  position: relative;
  top: 50%;
  left: 50%;
  width: 400px;
  transform: translate(-50%, -50%);
  background: @backDivColor;
}

.backGroundImage {
  position: fixed;
  top: 0;
  left: 0;
  height: 100vh;
  width: 100vw;
  margin: 0 auto;
  background-image: url('@/assets/images/background.png');
  background-size: cover;
  .single-bg-image;
  .display-flex;

  .wait-img {
    position: relative;
    width: 246px;
    top: 50%;
    left: 12%;
    transform: translate(0, -50%);
  }

  // 登录公用模块样式
  .loginMainArea {
    margin: 0 auto;
    width: 0.85 * @minWidth;
    height: 0.42 * @minWidth;

    .left {
      float: left;
      width: 54.74%;
      height: 100%;
      background-image: linear-gradient(#2d82fe, #1f1cc3);

      div {
        width: 70.3%;
        height: 80.32%;
        margin: 10.21% 20.36%;
        .single-bg-image;
        background-image: url('@/assets/images/pic1.png');
        background-size: 100% 100%;
      }
    }

    .right {
      float: left;
      width: 45.26%;
      background-color: #fbf6fa;
      height: 100%;

      .logo-header {
        padding: 11% 0;
        .display-flex;
        .system-title {
          font-size: 24px;
          font-weight: bold;
          color: @textColor_first;
          margin: 0;
        }
        .svg-logo {
          height: 58px;
          width: 58px;
          margin: 0;
        }
      }
      .login-form {
        margin: 0 auto;
        .ant-form-item-control-input-content {
          display: flex;
          justify-content: center;
          height: 100%;
        }
        .login-form-item {
          margin-bottom: 4px;
          height: 66px;
        }
        // 账号密码输入框样式修改
        .account-input,
        .password-input,
        .login-button {
          height: 41.7px;

          input {
            text-indent: 20px;
            font-size: 17px;
            &::placeholder {
              text-align: start;
            }
          }
          .label-text {
            position: relative;
            width: 52px;
            height: 21px;
            font-size: 12px;
            color: @textColor_first;
            line-height: 21px;
            letter-spacing: 1px;
            text-align: center;
            &::after {
              content: '';
              position: absolute;
              right: -4px;
              top: -10px;
              height: 41.7px;
              border-right: 1px solid #d9d9d9;
            }
          }

          .border-radius;

          .svg-icon {
            height: 29px;
            width: 26px;
          }

          .ant-input-prefix,
          .ant-input-suffix {
            display: flex;
          }

          p {
            cursor: pointer;
            font-size: 17px;
            font-family: AppleSystemUIFont;
            color: @ueColor_first;
            margin: 0 10px 0 0;
            transform: translate(0, -2.5%);
          }
        }

        .login-button {
          background-image: linear-gradient(to right, #3494ff, @ueColor_first);
          font-size: 17px;
        }
      }
    }
  }
  .error-tips {
    font-size: 17px;
    color: #cc1818;
    position: absolute;
    left: 54%;
    top: 83%;
    transform: translate(-50%, 0);
  }
}
</style>
