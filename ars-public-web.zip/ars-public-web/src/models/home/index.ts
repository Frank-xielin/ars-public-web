export interface AssetsInfoRes {
  total_fil: string
  total_power: string
}
