<script lang="ts" setup>
import { useAsideMenuList } from '@/composables/asideMenu'
import { useMainStore } from '@/store'

const store = useMainStore()

const { selectedKey, openKeys, changeMenu } = useAsideMenuList()
</script>

<template>
  <aside class="aside-menu">
    <div class="logo-box">
      <icon-font class="svg-logo" type="iconnav_icon_logo" />
      <p>集群运维系统</p>
    </div>
    <a-menu
      v-model:selected-keys="selectedKey"
      v-model:open-keys="openKeys"
      mode="inline"
      theme="dark"
      @click="changeMenu"
    >
      <sub-menu v-for="item of store.menuList" :key="item.path" :menu-object="item" />
    </a-menu>
  </aside>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.aside-menu {
  position: sticky;
  top: 0;
  left: 0;
  width: 240px;
  height: 100vh;
  background: #001529;
  overflow: hidden auto;

  .logo-box {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin: 15px 0 20px;
    .svg-logo {
      font-size: 50px;
    }
    p {
      width: 163px;
      height: 19px;
      margin-top: 14px;
      font-size: 14px;
      font-weight: bold;
      color: @bgClor_main;
      line-height: 19px;
      text-align: center;
      letter-spacing: 1px;
    }
  }
}

@media screen and (max-width: 1440px) {
  .aside-menu {
    width: 194px;
  }
}
</style>
