<script lang="ts" setup>
import { useSmsByPhone } from '@/composables/login/account'
import { useUpdateCurrentPw } from '@/composables/personal/personalInfomation/updateCurrentPassword'
import { SmsByPhoneParams } from '@/models/login'
import { useMainStore } from '@/store'
import { watch } from 'vue'

const props = defineProps<{ visible: boolean }>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()

const store = useMainStore()
const { form, formModel, submitForm } = useUpdateCurrentPw(() => {
  emit('update:visible', false)
  emit('search')
})
const { excessTime, readyToSend, getCodeBySms } = useSmsByPhone()

function getSmsCode() {
  const params: SmsByPhoneParams = {
    phone: formModel.value.phone,
    sms_type: 'modify_passwd'
  }
  getCodeBySms(params).catch()
}

watch(
  () => props.visible,
  visible => {
    if (visible) {
      formModel.value.phone = store.userInfo?.phone || ''
    } else {
      form.resetFields()
    }
  }
)
</script>

<template>
  <a-modal
    class="update-password-modal"
    title="修改登录密码"
    :visible="visible"
    :footer="null"
    @cancel="$emit('update:visible', false)"
    :width="455"
  >
    <a-form>
      <a-form-item v-bind="form.validateInfos.phone">
        <a-input :value="formModel.phone" disabled />
      </a-form-item>
      <a-form-item v-bind="form.validateInfos.new_password">
        <a-input-password
          placeholder="输入新密码"
          v-model:value="formModel.new_password"
          :visibility-toggle="false"
        />
      </a-form-item>
      <a-form-item v-bind="form.validateInfos.sms_code">
        <a-input placeholder="输入手机验证码" v-model:value="formModel.sms_code">
          <template #suffix>
            <a-button class="sms-btn" type="link" @click="getSmsCode()" :disabled="!readyToSend">
              {{ readyToSend ? '获取验证码' : `已发送${excessTime}` }}
            </a-button>
          </template>
        </a-input>
      </a-form-item>
      <a-form-item class="submit-item">
        <a-button type="primary" block @click="submitForm()">提交</a-button>
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<style scoped lang="less">
.sms-btn {
  height: 22px;
  padding: 0;
  line-height: 1 !important;
}
.submit-item {
  padding-bottom: 22px;
}
</style>
