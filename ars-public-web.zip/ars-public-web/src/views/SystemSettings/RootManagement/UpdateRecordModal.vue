<script lang="ts" setup>
import {
  columns,
  OperationTypeComp,
  useRootUpdateRecord
} from '@/composables/systemSettings/rootManagement/updateRecord'
import { useGetUpdateResult } from '@/composables/systemSettings/rootManagement/updateRootPassword'
import { computed, watch } from 'vue'
import UpdateResultModal from './UpdateResultModal.vue'

const props = defineProps<{
  visible: boolean
}>()
defineEmits<{
  (event: 'update:visible', val: boolean): void
}>()

const { pageVo, loading, dataSource, handleSearch } = useRootUpdateRecord()
const { updatedRes, initUpdatedData, getUpdateResult } = useGetUpdateResult(false)

const resultVisible = computed({
  get: () => !!updatedRes.value.list.length,
  set: val => {
    !val && initUpdatedData()
  }
})

watch(
  () => props.visible,
  val => {
    if (val) {
      dataSource.value.length = 0
      handleSearch()
    }
  }
)
</script>

<template>
  <a-modal
    title="修改记录"
    :visible="visible"
    :width="1000"
    :footer="null"
    @cancel="$emit('update:visible', false)"
  >
    <a-table
      v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
      :scroll="$scroller(400)"
      row-key="id"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ column, record, text }">
        <a-button
          v-if="column.title === '操作'"
          type="link"
          class="table-btn"
          @click="getUpdateResult(text)"
        >
          查看明细
        </a-button>
        <operation-type-comp v-else-if="column.title === '操作结果'" :record="record" />
        <span v-else-if="column.title === '操作类型'">{{ text === 1 ? '手动' : '自动' }}更新</span>
      </template>
    </a-table>
  </a-modal>
  <update-result-modal v-model:visible="resultVisible" :update-result="updatedRes" />
</template>

<style scoped lang="less">
.operation-result {
  :deep(.result-item) {
    margin-right: 20px;
    .error-text {
      text-decoration: underline;
    }
  }
}
</style>
