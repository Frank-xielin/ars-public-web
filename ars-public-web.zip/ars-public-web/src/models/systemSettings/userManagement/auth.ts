import { ApprovalTempListItem } from '../approvalProcess'

export interface MenuListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string | null
  domain: string
  name: string
  title: string
  path: string
  sort: string
  status: number
  visible: number
  parent_id: number
  display: boolean
}

export interface FuncListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string | null
  domain: string
  menu_id: number
  name: string
  title: string
  status: number
  api_route_group: string
  api_method: string
  api_desc: string
  need_approval: boolean
  approval_flow_templates?: ApprovalTempListItem[]
  display: boolean
}

export interface MenuFuncListRes {
  menu: MenuListItem[]
  func: FuncListItem[]
}

export interface AvailablePermissionsRes {
  menu_ids: number[]
  func_ids: number[]
}

export interface UpdateAuthOfRoleParams {
  menu_func: Record<number, number[]>[]
}

export type PermissionsByRoleRes = AvailablePermissionsRes
