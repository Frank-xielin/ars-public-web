<script lang="ts" setup>
import { useApprovalRefuseProcess } from '@/composables/jobManagement/taskManagement/allTaskApi'

// 父组件传值
defineProps<{
  visible: boolean
  approvalId: number
}>()
// 传给父组件
const emit = defineEmits(['update:visible', 'handleRefuseOk'])

const { formModel, checkApprove } = useApprovalRefuseProcess(() => {
  emit('handleRefuseOk')
  emit('update:visible', false)
})
formModel.value.action = 'reject'
</script>

<template>
  <a-modal
    class="sumbitApprovalModal"
    :visible="visible"
    title="拒绝"
    @ok="checkApprove(approvalId)"
    okText="确定"
    @cancel="$emit('update:visible', false)"
    cancelText="取消"
    width="356px"
  >
    <a-textarea class="RefuseReason" v-model:value="formModel.note"></a-textarea>
  </a-modal>
</template>

<style scoped>
.RefuseReason {
  width: 100%;
  min-width: 300px;
  min-height: 74px;
  max-height: 150px;
  margin-bottom: 20px;
}
</style>
