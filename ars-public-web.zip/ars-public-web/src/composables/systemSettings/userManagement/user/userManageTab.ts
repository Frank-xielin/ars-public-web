import { message } from 'ant-design-vue'
import { inject, ref, watch } from 'vue'

import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import {
  UserInfoByIdRes,
  UserListItem,
  UserListParams
} from '@/models/systemSettings/userManagement/user'
import { getUserInfoByIdApi, userListApi } from '@/services/systemSettings/userManagement/user'

import { ActiveKey } from './'

export const userCols: Utils.ColumnField<UserListItem>[] = [
  { title: '用户名', dataIndex: 'user_name' },
  { title: '所属客户', dataIndex: 'clients' },
  { title: '分组', dataIndex: 'user_group' },
  { title: '角色', dataIndex: 'roles' },
  { title: '手机号', dataIndex: 'phone' },
  { title: '邮箱', dataIndex: 'email' },
  { title: 'Leader', dataIndex: 'leader' },
  { title: '参与审批', dataIndex: 'approve' },
  { title: '启用', dataIndex: 'enable' },
  { title: '操作', dataIndex: 'id', width: 170 }
]

const initialUserInfo: UserInfoByIdRes = {
  id: 0,
  created_at: '',
  updated_at: '',
  deleted_at: '',
  user_name: '',
  passwd: '',
  phone: '',
  email: '',
  avatar: '',
  nick_name: '',
  introduction: '',
  created_by: 0,
  updated_by: 0,
  last_login: '',
  is_first_login: 0,
  passwd_need_modify: 0,
  passwd_expired: '',
  passwd_last_updated: '',
  client_id: 0,
  leader: false,
  approve: false,
  enable: false,
  user_group_id: 0,
  role_id: []
}

export function useGetUserList() {
  const dataSource = ref<UserListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()
  const { loading, run: userListFetch } = useRequest(userListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  return { loading, pageVo, dataSource, userListFetch }
}

/** 管理用户数据 */
export function useUserManager(callback?: () => void) {
  const activeTab = inject(ActiveKey)
  const selectedUser = ref<UserListItem | null>(null)
  const rolesShow = ref(false)
  const minersShow = ref(false)
  const searchModel = ref<Utils.NoPager<UserListParams>>({ client_id: -1, user: '' })

  const { loading, pageVo, dataSource, userListFetch } = useGetUserList()

  async function handleSearch(vo?: Utils.SearchVO) {
    try {
      const params: UserListParams = {
        ...searchModel.value,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      userListFetch(params)
      callback?.()
    } catch (e) {}
  }

  watch(
    () => activeTab?.value,
    act => {
      if (act === 'user') {
        handleSearch()
      }
    },
    { immediate: true }
  )

  return {
    loading,
    rolesShow,
    minersShow,
    pageVo,
    dataSource,
    selectedUser,
    searchModel,
    handleSearch
  }
}

/** 根据 id 获取用户信息 */
export function useGetUserInfo() {
  const userInfo = ref<UserInfoByIdRes>({ ...initialUserInfo })

  async function getUserById(id: number) {
    try {
      const reply = await getUserInfoByIdApi(id)
      const { code, data, msg } = reply
      if (code === 0) {
        data && (userInfo.value = data)
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { userInfo, getUserById }
}
