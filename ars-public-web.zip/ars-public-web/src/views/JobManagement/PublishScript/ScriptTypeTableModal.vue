<script lang="ts" setup>
import {
  columns,
  useDeleteScriptType,
  useScriptTypeAllList,
  useUpdateScriptType
} from '@/composables/jobManagement/publishScript/scriptTypeTable'
import { ScriptTypeListItem } from '@/models/jobManagement/publishScript'
import { ref, unref, watch } from 'vue'

const props = defineProps<{
  visible: boolean
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'change'): void
}>()

const isChanged = ref(false)
const { dataSource, loading, run } = useScriptTypeAllList()
const { deleteType } = useDeleteScriptType(changeHandler)
const { updateForm, updateType } = useUpdateScriptType(changeHandler)

function selectToEdit(record: ScriptTypeListItem) {
  updateForm.value = { id: record.id, name: record.name }
}
function changeHandler() {
  isChanged.value = true
  run().catch()
}
function isAvailableRow(rowId: number) {
  const { id } = unref(updateForm)
  return !id || id !== rowId
}

watch(
  () => props.visible,
  visible => {
    if (visible) {
      run().catch()
      updateForm.value = { id: 0, name: '' }
      isChanged.value = false
    } else if (isChanged.value) {
      emit('change')
    }
  }
)
</script>

<template>
  <a-modal
    title="管理脚本类型"
    :visible="visible"
    @cancel="$emit('update:visible', false)"
    @ok="$emit('update:visible', false)"
  >
    <a-table
      v-bind="$tableConfigs(dataSource, loading)"
      :columns="$columnsSetter(columns)"
      :scroll="$scroller(400)"
    >
      <template #bodyCell="{ column, text, record }">
        <template v-if="column.title === '操作'">
          <a-button
            type="link"
            class="table-btn"
            :disabled="!isAvailableRow(text)"
            @click="selectToEdit(record)"
          >
            编辑
          </a-button>
          <a-button type="link" class="table-btn" @click="deleteType(text)">删除</a-button>
        </template>
        <a-input
          v-if="column.title === '脚本类型名称' && updateForm.id === record.id"
          v-model:value="updateForm.name"
        >
          <template #suffix>
            <a @click="updateType">保存</a>
            <a style="margin-left: 10px" @click="updateForm.id = 0">取消</a>
          </template>
        </a-input>
      </template>
    </a-table>
  </a-modal>
</template>
