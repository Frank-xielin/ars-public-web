import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { BrokenRecordListItem, BrokenRecordListParams } from '@/models/workbench/errorRecord'
import { brokenRecordListApi, deleteBrokenRecordApi } from '@/services/workbench/errorRecord'
import { Form, message, Modal } from 'ant-design-vue'
import { Dayjs } from 'dayjs'
import { omit } from 'lodash-es'
import { Ref, ref, watch } from 'vue'

export type ModalType = '编辑' | '新建'

export const errorTypeList = [
  { label: '故障分类', value: -1 },
  { label: '硬件问题', value: 1 },
  { label: '软件问题', value: 2 },
  { label: '同步问题', value: 3 },
  { label: '运维失误', value: 4 },
  { label: '其他', value: 0 }
]

export const errorLevelList = [
  { label: '故障等级', value: -1 },
  { label: '高', value: 1 },
  { label: '中', value: 2 },
  { label: '低', value: 3 }
]

export const processStateList = [
  { label: '处理状态', value: -1 },
  { label: '未处理', value: 1 },
  { label: '进行中', value: 2 },
  { label: '已完成', value: 3 }
]

export const columns: Utils.ColumnField<BrokenRecordListItem & BrokenRecordListItem['broken']>[] = [
  { title: '日期', dataIndex: 'record_time' },
  { title: '集群', dataIndex: 'miner_id' },
  { title: '所属客户', dataIndex: 'clients' },
  { title: '故障描述', dataIndex: 'fault_description' },
  { title: '故障原因', dataIndex: 'fault_reason' },
  { title: '故障分类', dataIndex: 'fault_sort' },
  { title: '故障等级', dataIndex: 'fault_grade' },
  { title: '处理状态', dataIndex: 'processing_status' },
  { title: '记录人', dataIndex: 'users' },
  { title: '操作', dataIndex: 'id' }
]

export function useAddEditModal<T>(info: T | null = null) {
  const modalType = ref<ModalType>('新建')
  const visible = ref(false)
  const targetInfo = ref(info) as Ref<T | null>

  function addModal() {
    modalType.value = '新建'
    visible.value = true
  }

  function editModal(target: T) {
    targetInfo.value = target
    modalType.value = '编辑'
    visible.value = true
  }

  watch(visible, val => {
    if (!val) {
      targetInfo.value = null
    }
  })

  return { modalType, visible, targetInfo, editModal, addModal }
}

interface SearchForm extends Utils.NoPager<BrokenRecordListParams> {
  dates?: [Dayjs, Dayjs]
}

export function useBrokenRecordList() {
  const searchModel = ref<SearchForm>({
    fault_grade: -1,
    fault_sort: -1,
    processing_status: -1,
    end_time: '',
    start_time: '',
    search: '',
    dates: undefined
  })
  const dataSource = ref<BrokenRecordListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()
  const form = Form.useForm(searchModel)

  const { loading, run } = useRequest(brokenRecordListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list.map(item => ({ ...item, ...item.broken })) || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  function handleSearch(vo?: Utils.SearchVO) {
    const formatStr = 'YYYY-MM-DD HH:mm:ss'
    const { dates } = searchModel.value
    searchModel.value.start_time = dates?.[0].format(formatStr) || ''
    searchModel.value.end_time = dates?.[1].format(formatStr) || ''
    try {
      const params: BrokenRecordListParams = {
        ...omit(searchModel.value, ['dates']),
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params)
    } catch (e) {}
  }

  return { dataSource, pageVo, searchModel, loading, form, handleSearch }
}

/**
 * 删除指定的故障记录
 * @param id 记录 id
 * @param successFn
 */
export function deleteBrokenRecord(id: number, successFn: () => void) {
  Modal.confirm({
    content: '是否删除该条记录？',
    async onOk() {
      const reply = await deleteBrokenRecordApi(id)
      if (reply.code === 0) {
        message.success('删除记录成功')
        successFn()
      } else {
        message.error(reply.msg)
      }
    }
  })
}
