<script lang="ts" setup>
import buttonProps from 'ant-design-vue/lib/button/buttonTypes'
import { omit } from 'lodash-es'
import { mergeProps } from 'vue'

defineProps(buttonProps())
</script>

<script lang="ts">
export default {
  inheritAttrs: false
}
</script>

<template>
  <custom-tooltip :title="title">
    <a-button v-bind="mergeProps(omit($props, ['title']), $attrs)" type="link" class="icon-button">
      <slot></slot>
    </a-button>
  </custom-tooltip>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.icon-button {
  height: 28px;
  padding: 0 8px;
  border-radius: 32px;
  .animate;
  &:hover {
    background: #e6edf2;
  }

  .anticon {
    font-size: 18px;
  }
}
</style>
