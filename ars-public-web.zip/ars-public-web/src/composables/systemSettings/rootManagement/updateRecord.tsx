import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { GetUpdatePwdRecordItem } from '@/models/systemSettings/rootManagement'
import { getUpdatePwdRecord } from '@/services/systemSettings/rootManagement'
import { message } from 'ant-design-vue'
import classnames from 'classnames'
import { FunctionalComponent, ref } from 'vue'

export const columns: Utils.ColumnField<GetUpdatePwdRecordItem>[] = [
  { title: '时间', dataIndex: 'Time' },
  { title: '操作类型', dataIndex: 'operation_type' },
  { title: '操作结果', dataIndex: 'id' },
  { title: '操作', dataIndex: 'id' }
]

/** 获取主机密码修改记录 */
export const useRootUpdateRecord = () => {
  const dataSource = ref<GetUpdatePwdRecordItem[]>([])

  const { pageVo, setPageFromData } = usePagination()
  const { loading, run } = useRequest(getUpdatePwdRecord, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  const handleSearch = async (vo?: Utils.SearchVO) => {
    try {
      const params: Utils.SearchVO = {
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params)
    } catch (e) {}
  }

  return { pageVo, loading, dataSource, handleSearch }
}

/**
 * 操作结果的详细内容展示
 * @param props
 * @returns
 */
export const OperationTypeComp: FunctionalComponent<{ record: GetUpdatePwdRecordItem }> = props => {
  const { record } = props

  return (
    <div class="operation-result">
      <span class="result-item">总数: {record.total}</span>
      <span class="result-item">成功: {record.success}</span>
      <span class="result-item">
        失败: <span class={classnames({ 'error-text': !!record.fail })}>{record.fail}</span>
      </span>
    </div>
  )
}
