import {
  CreateRoleParams,
  RoleListAllParams,
  RoleListAllRes,
  UpdateRoleParams
} from '@/models/systemSettings/userManagement/role'
import { request } from '@/utils/httpConfig'

/**
 * 角色列表 - 全部
 * @returns
 */
export function roleAllListApi(data: RoleListAllParams) {
  return request<RoleListAllRes>({
    url: 'v5/public/role/get/list',
    method: 'GET',
    data,
    loading: true
  })
}

/**
 * 角色创建 - 单个
 * @param data
 * @returns
 */
export function createRoleApi(data: CreateRoleParams) {
  return request({
    url: 'v5/public/role/create/one',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 角色编辑 - 单个
 * @param id 目标角色 id
 * @param data
 * @returns
 */
export function updateRoleApi(id: number, data: UpdateRoleParams) {
  return request({
    url: `v5/public/role/update/id/${id}`,
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 角色删除 - 单个
 * @param id 目标角色 id
 * @returns
 */
export function deleteRoleApi(id: number) {
  return request({
    url: `v5/public/role/delete/id/${id}`,
    method: 'delete',
    loading: true
  })
}
