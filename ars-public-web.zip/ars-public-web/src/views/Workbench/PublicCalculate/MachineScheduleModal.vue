<script lang="ts" setup>
import {
  MachineRoomIdKey,
  useGetClusterListByRoom,
  useScheduleMachines
} from '@/composables/workbench/publicCalculate'
import { DeviceListOfRoomItem } from '@/models/workbench/publicCalculate'
import { computed, inject, toRefs, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  selectedRows: DeviceListOfRoomItem[]
}>()
const emit = defineEmits<{
  (event: 'update:visible', value: boolean): void
  (event: 'search'): void
}>()
const { selectedRows } = toRefs(props)
const machineRoomId = inject(MachineRoomIdKey)

const { clusterList, getClusterList } = useGetClusterListByRoom()
const { selectedCluster, scheduleMachines } = useScheduleMachines(selectedRows, () => {
  emit('update:visible', false)
  emit('search')
})

const clusters = computed(() => {
  const miners = props.selectedRows.map(row => row.miner)
  return clusterList.value
    .filter(cluster => !miners.includes(cluster.miner_id))
    .map(cluster => {
      return {
        ...cluster,
        label: cluster.client_name + cluster.miner_id
      }
    })
})

watch(
  () => props.visible,
  visible => {
    if (visible && machineRoomId) {
      getClusterList(machineRoomId.value).then(() => {
        selectedCluster.value = clusters.value[0]?.miner_id || ''
      })
    } else {
      selectedCluster.value = ''
    }
  }
)
</script>

<template>
  <a-modal
    title="机器调度"
    :visible="visible"
    @ok="scheduleMachines"
    @cancel="$emit('update:visible', false)"
  >
    <div>
      请选择目的集群：
      <custom-select
        style="width: 200px; margin: 20px 0"
        :data="clusters"
        value-field="miner_id"
        v-model:value="selectedCluster"
      />
    </div>
  </a-modal>
</template>
