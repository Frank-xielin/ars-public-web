<script lang="ts" setup>
import { useAutoUpdateTitle } from '@/composables/layout'
import { selectData, useSystemVersionInfo } from '@/composables/layout/headerWrapper'
import { useLogout } from '@/composables/login'
import { useMainStore } from '@/store'
import { Modal } from 'ant-design-vue'

defineProps<{ visible: boolean }>()

const store = useMainStore()
const { logout } = useLogout()
const { versionShow, versionInfo } = useSystemVersionInfo()
useAutoUpdateTitle()

function handleLogout() {
  Modal.confirm({
    content: '是否退出登录',
    onOk() {
      return logout()
    }
  })
}
</script>

<template>
  <div v-show="visible" class="wrapper">
    <div class="wrapper__header">
      <div class="wrapper__header__left">
        <span class="txt1">当前位置</span>
        <span class="txt2">公有云</span>
      </div>
      <div class="wrapper__header__right">
        <icon-font class="wrapper__header__right__icon--mine" type="iconhead_icon_mine" />
        <a-dropdown>
          <a class="ant-dropdown-link" @click.prevent>
            {{ store.userInfo?.user_name || '用户' }}
            <DownOutlined />
          </a>
          <template #overlay>
            <a-menu class="dropdown">
              <a-menu-item v-for="item of selectData" :key="item.name" class="dropdown__son">
                <a-button class="dropdown__son__btn" type="text" @click="$router.push(item.link)">
                  {{ item.name }}
                </a-button>
              </a-menu-item>
              <a-menu-item class="dropdown__son">
                <a-button class="dropdown__son__btn" type="text" @click="versionShow = true">
                  帮助信息
                </a-button>
              </a-menu-item>
              <a-menu-item class="dropdown__son">
                <a-button class="dropdown__son__btn" type="text" @click="handleLogout">
                  退出登录
                </a-button>
              </a-menu-item>
            </a-menu>
          </template>
        </a-dropdown>
      </div>
    </div>
  </div>
  <a-breadcrumb v-show="visible" class="breadcrumb" separator=">">
    <a-breadcrumb-item v-for="item of store.breadList" :key="item.path">
      {{ item.name }}
    </a-breadcrumb-item>
  </a-breadcrumb>

  <a-modal
    title="帮助信息"
    class="version-modal"
    v-model:visible="versionShow"
    @ok="versionShow = false"
    @cancel="versionShow = false"
  >
    <div class="version-info">
      <h3>客户端版本：</h3>
      <p>{{ versionInfo.client }}</p>
      <h3>服务端版本：</h3>
      <p>{{ versionInfo.service }}</p>
    </div>
  </a-modal>
</template>

<style lang="less" scoped>
@import (reference) '@/assets/styles/index.less';
.wrapper {
  display: flex;
  height: 64px;
  align-items: center;
  background-color: @bgClor_main;
  margin-bottom: 2px;
  position: relative;
  &__header {
    height: 26px;
    display: flex;
    width: 100%;
    justify-content: space-between;

    &__left {
      display: flex;
      margin-left: 24px;
      .txt1 {
        display: block;
        overflow-wrap: break-word;
        color: rgba(0, 21, 41, 1);
        font-size: 18px;
        letter-spacing: 0.81px;
        font-family: MicrosoftYaHei;
        white-space: nowrap;
        line-height: 24px;
        text-align: left;
        margin-top: 1px;
      }
      .txt2 {
        display: block;
        overflow-wrap: break-word;
        color: rgba(57, 69, 101, 1);
        font-size: 20px;
        letter-spacing: 0.91px;
        white-space: nowrap;
        line-height: 26px;
        margin-left: 20px;
        font-weight: bold;
      }
    }
    &__right {
      display: flex;
      align-items: center;
      margin-right: 60px;
      &__icon--mine {
        font-size: 22px;
        padding-right: 10px;
      }
      &__txt3 {
        overflow-wrap: break-word;
        color: rgba(57, 69, 101, 1);
        font-size: 18px;
        letter-spacing: 2px;
        white-space: nowrap;
        line-height: 25px;
      }
      &__icon--arrow {
        font-size: 14px;
        transform: rotate(180deg);
      }
    }
  }
}
.version-info {
  h3 {
    font-weight: bold;
  }
  p {
    padding-left: 30px;
    margin: 10px 0;
  }
}
.breadcrumb {
  font-size: 14px;
  padding-left: 24px;
  height: 42px;
  display: flex;
  align-items: center;
}
.ant-dropdown-link {
  color: @textColor_first;
}
</style>

<style lang="less">
@import (reference) '@/assets/styles/index.less';

.dropdown {
  position: absolute;
  right: -5px;
  top: 13px;
  &__son {
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    line-height: 40px;
    width: 100%;
    height: 40px;
    font-size: 14px;
    background: #fff;
    color: @textColor_first;
    &__btn {
      width: 100%;
    }
    &:hover {
      font-size: 14px;
      background: #177eff !important;
      color: #fff !important;
      .dropdown__son__btn span {
        color: #fff !important;
      }
    }
  }
}
</style>
