<script lang="ts" setup>
import { columns, useClusterList } from '@/composables/systemSettings/clusterInformation'
import { sectorSizeList } from '@/composables/systemSettings/clusterInformation/addEditCluster'
import { useAddEditModal } from '@/composables/workbench/errorRecord'
import { ClusterListItem } from '@/models/systemSettings/clusterInformation'
import { ref } from 'vue'
import AddEditCluster from './ClusterInformation/AddEditCluster.vue'
import ChangePrincipal from './ClusterInformation/ChangePrincipal.vue'

const principalShow = ref(false)
const targetMiner = ref('')

const {
  modalType: editType,
  visible: editShow,
  editModal: editCluster,
  addModal: addCluster,
  targetInfo
} = useAddEditModal<ClusterListItem>()
const { dataSource, pageVo, loading, handleSearch } = useClusterList()

function bindPrincipal(minerId: string) {
  targetMiner.value = minerId
  principalShow.value = true
}

function onSearch(vo?: Utils.SearchVO) {
  handleSearch(vo)
}
onSearch()
</script>

<template>
  <div class="cluster-information page">
    <a-button
      :disabled="!$auth(12)"
      class="add-btn"
      type="primary"
      shape="round"
      @click="addCluster()"
    >
      新建集群
    </a-button>

    <a-table
      class="table-box"
      v-bind="$tableConfigs(dataSource, loading, pageVo, onSearch)"
      row-key="id"
      :columns="$columnsSetter(columns)"
      :scroll="$scroller('calc(100vh - 320px)')"
    >
      <template #bodyCell="{ column: col, text, record }">
        <div v-if="col.title === '操作'">
          <a-button
            type="link"
            :disabled="!$auth(13)"
            class="table-btn"
            @click="editCluster(record)"
          >
            编辑
          </a-button>
          <a-button
            type="link"
            :disabled="!$auth(15)"
            class="table-btn"
            @click="bindPrincipal(record.miner)"
          >
            添加负责人
          </a-button>
        </div>
        <custom-tooltip v-else>
          <span v-if="col.title === '集群负责人'">
            {{ text.join(', ') }}
          </span>
          <span v-else-if="col.title === '扇区大小'">
            {{ sectorSizeList.find(size => size.value === text)?.label }}
          </span>
          <span v-else>{{ text }}</span>
        </custom-tooltip>
      </template>
    </a-table>

    <change-principal
      v-model:visible="principalShow"
      :miner-id="targetMiner"
      @search="onSearch(pageVo)"
    />
    <add-edit-cluster
      v-model:visible="editShow"
      :modal-type="editType"
      :target-info="targetInfo"
      @search="onSearch(editType === '编辑' ? pageVo : undefined)"
    />
  </div>
</template>

<style scoped lang="less">
.add-btn {
  position: absolute;
  right: 50px;
}
.table-box {
  margin-top: 55px;
}
</style>
