<script lang="ts" setup>
import {
  useEnableTemplate,
  useGetTemplateInfo
} from '@/composables/jobManagement/commonTemplate/checkTemplate'
import router from '@/router'
import { dateFormatter } from '@/utils/dateFormat'
import { ref } from 'vue'
import { useRoute } from 'vue-router'
import TemplateForm, { TemplateFormExpose } from './TemplateForm.vue'

const route = useRoute()
const formRef = ref<TemplateFormExpose>()

const { templateModel, isEdit, templateId, initTemplate } = useGetTemplateInfo()
const { enableTemplate } = useEnableTemplate(initTemplate)

function submitForm() {
  formRef.value?.onSubmitForm()
}
function formatter(date = '') {
  return dateFormatter(date, 'YYYY年MM月DD日 HH:mm')
}
function onCancel(init?: boolean) {
  const { type } = route.query
  if (type === 'edit') {
    router.push('/JobManagement/CommonTemplate')
  } else {
    isEdit.value = false
    init && initTemplate()
  }
}
initTemplate()
</script>

<template>
  <div class="check-template page" :class="{ 'check-mode': !isEdit }">
    <div class="content-wrapper top">
      <h2 v-show="isEdit" class="page-title">编辑模板</h2>
      <div class="operation-top">
        <template v-if="!isEdit">
          <a-button @click="isEdit = true" :disabled="templateModel?.enabled || !$auth(85)">
            编辑
          </a-button>
          <a-button
            @click="enableTemplate(templateId, !templateModel?.enabled)"
            :disabled="!$auth(89)"
          >
            {{ templateModel?.enabled ? '弃用' : '启用' }}
          </a-button>
        </template>
        <template v-else>
          <a-button type="primary" @click="submitForm">保存</a-button>
          <a-button @click="onCancel()">取消</a-button>
        </template>
      </div>
    </div>

    <div v-show="!isEdit" class="content-wrapper">
      <h3 class="form-title">用户管理</h3>
      <a-form class="template-edit-form" layout="inline" :wrapper-col="{ span: 13 }">
        <a-form-item label="模板类型">
          <span>{{ templateModel?.template_type }}</span>
        </a-form-item>
        <a-form-item label="模板名称">
          <span>{{ templateModel?.template_name }}</span>
        </a-form-item>
        <a-form-item label="模板内容">
          <pre class="template-code">{{ templateModel?.content }}</pre>
        </a-form-item>
        <a-form-item label="启用">
          <a-checkbox disabled :checked="templateModel?.enabled" />
        </a-form-item>
        <a-form-item label="备注">
          <span>{{ templateModel?.note }}</span>
        </a-form-item>
      </a-form>
    </div>

    <div v-show="!isEdit" class="content-wrapper">
      <h3 class="form-title">系统信息</h3>
      <a-row class="sys-info">
        <a-col :span="12">
          <span class="label">创建人:</span>
          <span class="name">{{ templateModel?.creator }}</span>
          <span class="time">{{ formatter(templateModel?.created_at) }}</span>
        </a-col>
        <a-col :span="12">
          <span class="label">最近修改:</span>
          <span class="name">{{ templateModel?.updater }}</span>
          <span class="time">{{ formatter(templateModel?.updated_at) }}</span>
        </a-col>
      </a-row>
    </div>
    <template-form
      v-show="isEdit"
      type="编辑"
      :id="templateId"
      :model="templateModel"
      ref="formRef"
      @submit="onCancel(true)"
    />
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.check-mode {
  padding: 0 !important;
  background: @backDivColor;
  .content-wrapper.top {
    padding-top: 27px;
  }
}
.page-title {
  padding-bottom: 11px;
  margin: 0 36px 45px;
  font-size: 14px;
  font-weight: bold;
  border-bottom: 1px solid @ueColor_fifth;
}
.content-wrapper {
  padding-bottom: 27px;
  margin-bottom: 10px;
  background: #fff;
}
.operation-top {
  display: flex;
  justify-content: center;
  > button {
    width: 100px;
    margin: 0 10px;
  }
}
.sys-info {
  width: 80%;
  margin: 0 auto 48px;
  .ant-col {
    span {
      margin-right: 20px;
      font-size: 14px;
    }
  }
}
.form-title {
  margin: 0 36px 24px;
  padding: 11px 0;
  font-size: 14px;
  font-weight: bold;
  border-bottom: 1px solid @ueColor_fifth;
}
.template-edit-form {
  width: 80%;
  margin: auto;
  .template-code {
    max-height: 250px;
  }
  :deep(.ant-form-item) {
    width: 45%;
    min-height: 56px;
    margin-bottom: 5px;
    &.ant-form-item-with-help {
      margin-bottom: 5px;
    }
    .ant-form-item-label {
      min-width: 80px;
    }
  }
}
.create-form {
  width: 650px;
  margin: auto;
  .content-textarea {
    width: 100%;
    height: 267px;
  }
}
</style>
