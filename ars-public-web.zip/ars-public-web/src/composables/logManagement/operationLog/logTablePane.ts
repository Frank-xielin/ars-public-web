import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import {
  ClusterOperationLogsItem,
  ClusterOperationLogsParams,
  SystemOperationLogsItem,
  SystemOperationLogsParams
} from '@/models/logManagement/operationLog'
import {
  clusterOperationLogsApi,
  systemOperationLogsApi
} from '@/services/logManagement/operationLog'
import { message } from 'ant-design-vue'
import { Dayjs } from 'dayjs'
import { omit } from 'lodash-es'
import { computed, inject, InjectionKey, Ref, ref, watch } from 'vue'
import { clusterCols, systemCols } from './'

interface SearchForm extends Utils.NoPager<SystemOperationLogsParams> {
  dates?: [Dayjs, Dayjs]
}

/** 系统操作日志获取 */
export function useSystemOperationLogs() {
  const searchModel = ref<SearchForm>({
    key_word: '',
    start_time: '',
    end_time: '',
    dates: undefined
  })
  const dataSource = ref<SystemOperationLogsItem[]>([])
  const { pageVo, setPageFromData } = usePagination()

  const { loading, run: logFetch } = useRequest(systemOperationLogsApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  async function handleSearch(vo?: Utils.SearchVO) {
    const formatStr = 'YYYY-MM-DD HH:mm:ss'
    const { dates } = searchModel.value
    searchModel.value.start_time = dates?.[0].format(formatStr) || ''
    searchModel.value.end_time = dates?.[1].format(formatStr) || ''
    const params: SystemOperationLogsParams = {
      ...omit(searchModel.value, ['dates']),
      page: vo?.page ?? 1,
      page_size: vo?.page_size ?? pageVo.value.page_size
    }
    try {
      return logFetch(params)
    } catch (e) {}
  }

  return { pageVo, dataSource, searchModel, loading, handleSearch }
}

/** 集群操作日志获取 */
export function useClusterOperationLogs() {
  const searchModel = ref<SearchForm>({
    key_word: '',
    start_time: '',
    end_time: '',
    dates: undefined
  })
  const dataSource = ref<ClusterOperationLogsItem[]>([])
  const { pageVo, setPageFromData } = usePagination()

  const { loading, run: logFetch } = useRequest(clusterOperationLogsApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  async function handleSearch(vo?: Utils.SearchVO) {
    const formatStr = 'YYYY-MM-DD HH:mm:ss'
    const { dates } = searchModel.value
    searchModel.value.start_time = dates?.[0].format(formatStr) || ''
    searchModel.value.end_time = dates?.[1].format(formatStr) || ''
    const params: ClusterOperationLogsParams = {
      ...omit(searchModel.value, ['dates']),
      page: vo?.page ?? 1,
      page_size: vo?.page_size ?? pageVo.value.page_size
    }
    try {
      return logFetch(params)
    } catch (e) {}
  }

  return { pageVo, dataSource, searchModel, loading, handleSearch }
}

export const activeLogTab: InjectionKey<Readonly<Ref<'cluster' | 'system'>>> =
  Symbol('activeLogTab')

/** 根据激活的 tab 获取集群/系统的操作日志 */
export function useGetCorrectLogs() {
  const activeTab = inject(activeLogTab)

  const systemHandler = useSystemOperationLogs()
  const clusterHandler = useClusterOperationLogs()

  const viewHandler = computed(() => {
    if (activeTab?.value === 'system') {
      return { ...systemHandler, columns: systemCols }
    }
    return { ...clusterHandler, columns: clusterCols }
  })

  watch(
    () => activeTab?.value,
    () => {
      viewHandler.value.handleSearch()
    }
  )

  return viewHandler
}
