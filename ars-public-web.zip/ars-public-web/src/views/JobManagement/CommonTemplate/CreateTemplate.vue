<script lang="ts" setup>
import { ref } from 'vue'
import TemplateForm, { TemplateFormExpose } from './TemplateForm.vue'

const formRef = ref<TemplateFormExpose>()
function submitForm() {
  formRef.value?.onSubmitForm()
}
</script>

<template>
  <div class="create-template page">
    <h2 class="page-title">新建模板</h2>
    <div class="operation-top">
      <a-button type="primary" @click="submitForm">保存</a-button>
      <a-button @click="$router.push('/JobManagement/CommonTemplate')">取消</a-button>
    </div>
    <template-form type="新建" ref="formRef" />
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.page-title {
  padding: 0 0 11px;
  margin: 0 36px 45px;
  font-size: 14px;
  font-weight: bold;
  border-bottom: 1px solid @ueColor_fifth;
}
.operation-top {
  display: flex;
  justify-content: center;
  margin: 20px 0 30px;
  > button {
    width: 100px;
    margin: 0 10px;
  }
}
</style>
