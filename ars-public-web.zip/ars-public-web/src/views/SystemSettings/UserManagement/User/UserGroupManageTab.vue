<script lang="ts" setup>
import {
  useRemoveUserGroup,
  userGroupCols,
  useUserGroupManager
} from '@/composables/systemSettings/userManagement/user/userGroupManageTab'
import { useAddEditModal } from '@/composables/workbench/errorRecord'
import { UserGroupListItem } from '@/models/systemSettings/userManagement/user'
import AddEditUserGroup from './AddEditUserGroup.vue'

const { modalType, visible, targetInfo, addModal, editModal } = useAddEditModal<UserGroupListItem>()
const { loading, pageVo, dataSource, searchModel, handleSearch } = useUserGroupManager()
const { run: deleteFetch } = useRemoveUserGroup(handleSearch)
</script>

<template>
  <div class="user-group-manage-tab">
    <a-form layout="inline">
      <a-form-item>
        <custom-search-input
          v-model:value="searchModel.search"
          @search-func="handleSearch()"
          placeholder="输入组名进行搜索"
        />
      </a-form-item>

      <a-form-item class="right-operator">
        <a-button :disabled="!$auth(62)" shape="round" @click="addModal">新建用户组</a-button>
      </a-form-item>
    </a-form>

    <a-table
      class="table-box"
      v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
      row-key="id"
      :scroll="$scroller('calc(100vh - 430px)')"
      :columns="$columnsSetter(userGroupCols)"
    >
      <template #bodyCell="{ column: col, text, record }">
        <div v-if="col.title === '操作'">
          <a-button
            type="link"
            class="table-btn"
            :disabled="!$auth(172)"
            @click="editModal(record)"
          >
            编辑
          </a-button>
          <a-button
            type="link"
            v-if="text !== 1"
            :disabled="!$auth(173)"
            class="table-btn"
            @click="deleteFetch(text).catch()"
          >
            删除
          </a-button>
        </div>
        <custom-tooltip v-else>
          <span v-if="col.title === '父级'">
            {{ text ? dataSource.find(item => item.id === text)?.name : '无' }}
          </span>
          <span v-else>{{ text }}</span>
        </custom-tooltip>
      </template>
    </a-table>

    <add-edit-user-group
      v-model:visible="visible"
      :modal-type="modalType"
      :target-info="targetInfo"
      :data-source="dataSource"
      @search="handleSearch(modalType === '编辑' ? pageVo : undefined)"
    />
  </div>
</template>

<style scoped lang="less">
.right-operator {
  position: absolute;
  right: 20px;
}
</style>
