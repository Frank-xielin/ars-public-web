export interface LoginLogListParams extends Utils.SearchVO {
  start_time: string
  end_time: string
  is_abnormal: number
}

export interface LoginLogListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string | null
  user_id: number
  phone: string
  ip: string
  city: string
  user_agent: string
  datetime: string
  status: number
  is_abnormal: number
  note: string
}

export interface LoginLogListRes extends Utils.PageVO {
  list: LoginLogListItem[]
}
