import { request } from '@/utils/httpConfig'

/** 公有云版本信息 */
export function backendVersionApi() {
  return request<string>({
    url: 'v5/public/version/get/info',
    method: 'get',
    loading: true
  })
}
