<template>
  <div class="404-page">
    <a-result status="403" title="403" sub-title="您访问的页面不存在或无权限">
      <template #extra>
        <a-button type="primary" @click="$router.push('/')">回到主页</a-button>
      </template>
    </a-result>
  </div>
</template>
