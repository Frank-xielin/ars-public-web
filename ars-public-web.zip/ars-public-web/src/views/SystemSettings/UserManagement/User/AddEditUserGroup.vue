<script lang="ts" setup>
import { useEditUserGroup } from '@/composables/systemSettings/userManagement/user/addEditUserGroup'
import { ModalType } from '@/composables/workbench/errorRecord'
import { UserGroupListItem } from '@/models/systemSettings/userManagement/user'
import { toRefs, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  modalType: ModalType
  dataSource: UserGroupListItem[]
  targetInfo: UserGroupListItem | null
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()
const { modalType } = toRefs(props)

const { form, formModel, handleSubmit } = useEditUserGroup(modalType, () => {
  form.resetFields()
  emit('update:visible', false)
  emit('search')
})

watch(
  () => props.visible,
  nValue => {
    if (nValue) {
      formModel.value.parent_id = props.dataSource[0].id
      const info = props.targetInfo
      if (info) {
        formModel.value = {
          group_name: info.name,
          note: info.note,
          parent_id: info.parent_id || props.dataSource[0].id
        }
      }
    } else {
      form.resetFields()
    }
  }
)
</script>

<template>
  <a-modal
    :visible="visible"
    :title="`${modalType}分组`"
    @cancel="$emit('update:visible', false)"
    @ok="handleSubmit(targetInfo?.id)"
  >
    <a-form :label-col="{ span: 3 }">
      <a-form-item label="组名" v-bind="form.validateInfos.group_name">
        <a-input v-model:value="formModel.group_name" />
      </a-form-item>
      <a-form-item label="父级" v-bind="form.validateInfos.parent_id">
        <custom-select
          :data="dataSource"
          label-field="name"
          value-field="id"
          v-model:value="formModel.parent_id"
        />
      </a-form-item>
      <a-form-item label="描述">
        <a-input v-model:value="formModel.note" />
      </a-form-item>
    </a-form>
  </a-modal>
</template>
