import {
  BrokenRecordListParams,
  BrokenRecordListRes,
  CreateBrokenRecordParams,
  UpdateBrokenRecordParams
} from '@/models/workbench/errorRecord'
import { request } from '@/utils/httpConfig'

/**
 * 故障记录列表 - 分页
 * @param data
 * @returns
 */
export function brokenRecordListApi(data: BrokenRecordListParams) {
  return request<BrokenRecordListRes>({
    url: 'v5/public/broken/get/list',
    method: 'GET',
    data
  })
}

/**
 * 故障记录创建 - 单个
 * @param data
 * @returns
 */
export function createBrokenRecordApi(data: CreateBrokenRecordParams) {
  return request({
    url: 'v5/public/broken/create/one',
    method: 'POST',
    data,
    loading: true
  })
}

/**
 * 故障记录更新 - 单个
 * @param id 目标记录的 id
 * @param data
 * @returns
 */
export function updateBrokenRecordApi(id: number, data: UpdateBrokenRecordParams) {
  return request({
    url: `v5/public/broken/update/id/${id}`,
    method: 'PUT',
    data,
    loading: true
  })
}

/**
 * 故障记录删除 - 单个
 * @param id 目标记录的 id
 * @returns
 */
export function deleteBrokenRecordApi(id: number) {
  return request({
    url: `v5/public/broken/delete/id/${id}`,
    method: 'delete',
    loading: true
  })
}
