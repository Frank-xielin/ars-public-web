import { InjectionKey, provide, Ref, ref } from 'vue'

type ActiveKey = 'user' | 'group'

export const ActiveKey: InjectionKey<Ref<ActiveKey>> = Symbol('激活标签')

export function useUserTabManager() {
  const activeTab = ref<ActiveKey>('user')

  provide(ActiveKey, activeTab)

  return { activeTab }
}
