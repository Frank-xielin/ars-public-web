import { Form } from 'ant-design-vue'
import { ref } from 'vue'

import useRequest from '@/common/useRequest'
import { ModalType } from '@/composables/workbench/errorRecord'
import { CreateRoleParams } from '@/models/systemSettings/userManagement/role'
import { createRoleApi, updateRoleApi } from '@/services/systemSettings/userManagement/role'
import { requestHandler } from '@/utils/formTools'

export function useAddEditRole(successFn: () => void) {
  const formModel = ref<CreateRoleParams>({ name: '', note: '', owned_customer: 0 })
  const rules = ref<Utils.RulesObject<CreateRoleParams>>({
    name: [{ required: true, message: '请输入角色名' }],
    owned_customer: [{ required: true, message: '请选择所属客户' }]
  })
  const form = Form.useForm(formModel, rules)

  const { run: updateFetch } = useRequest(updateRoleApi, {
    onSuccess: reply => {
      requestHandler('编辑角色成功')(reply)
      reply.code === 0 && successFn()
    }
  })
  const { run: createFetch } = useRequest(createRoleApi, {
    onSuccess: reply => {
      requestHandler('编辑角色成功')(reply)
      reply.code === 0 && successFn()
    }
  })

  async function submitForm(type: ModalType, id?: number) {
    try {
      await form.validate()
      if (type === '新建') {
        createFetch(formModel.value)
      } else if (id != null) {
        updateFetch(id, formModel.value)
      }
    } catch (e) {}
  }

  return { formModel, form, submitForm }
}
