<script lang="ts" setup>
import { useEditScriptInfo } from '@/composables/jobManagement/publishScript/scriptEditor'
import { useScriptTypeAllList } from '@/composables/jobManagement/publishScript/scriptTypeTable'
import { GetScriptInfoRes } from '@/models/jobManagement/publishScript'
import { ref, watch } from 'vue'
import CreateScriptTypeModal from './CreateScriptTypeModal.vue'
import ScriptTypeTableModal from './ScriptTypeTableModal.vue'

export interface ScriptEditorExpose {
  onSubmitForm: (id?: number | undefined) => Promise<void>
}

const props = defineProps<{
  type: 'edit' | 'add'
  model?: GetScriptInfoRes | null
}>()
defineEmits<{ (event: 'submit'): void }>()

const inputRef = ref<HTMLInputElement>()
const typeCreateShow = ref(false)
const typeTableShow = ref(false)
const { formModel, form, submitForm, selectLocalFile } = useEditScriptInfo()
const { dataSource: typeList, run: getTypeList } = useScriptTypeAllList()

getTypeList()

watch(
  () => props.model,
  model => {
    if (model) {
      formModel.value = {
        content: model.content,
        enabled: model.enabled,
        name: model.script_name,
        note: model.note,
        type_id: model.script_type_id,
        version: model.version
      }
    }
  },
  { deep: true }
)

defineExpose({
  onSubmitForm: submitForm
})
</script>

<template>
  <div>
    <a-form class="script-form" :label-col="{ span: 3 }">
      <a-form-item label="脚本类型" v-bind="form.validateInfos.type_id">
        <custom-select
          style="width: 55%"
          :data="typeList"
          value-field="id"
          label-field="name"
          v-model:value="formModel.type_id"
        />
        <a-button type="link" @click="typeCreateShow = true">添加脚本类型</a-button>
        <a-button type="link" @click="typeTableShow = true">管理脚本类型</a-button>
      </a-form-item>
      <a-form-item label="脚本名称" v-bind="form.validateInfos.name">
        <a-input
          class="script-name-input"
          placeholder="请上传脚本"
          disabled
          :value="formModel.name"
        />
        <a-button @click="inputRef?.click()">本地选择</a-button>
        <input type="file" style="display: none" ref="inputRef" @change="selectLocalFile" />
      </a-form-item>
      <a-form-item label="版本号" v-bind="form.validateInfos.version">
        <a-input v-model:value="formModel.version" />
      </a-form-item>
      <a-form-item label="脚本内容" v-bind="form.validateInfos.content">
        <a-textarea style="height: 200px" readonly :value="formModel.content" />
      </a-form-item>
      <a-form-item label="脚本描述" v-bind="form.validateInfos.note">
        <a-textarea v-model:value="formModel.note" />
      </a-form-item>
    </a-form>

    <create-script-type-modal v-model:visible="typeCreateShow" @submit="getTypeList" />
    <script-type-table-modal v-model:visible="typeTableShow" @change="getTypeList" />
  </div>
</template>

<style scoped lang="less">
.script-form {
  width: 600px;
  margin: auto;
  .script-name-input {
    width: 80%;
    margin-right: 15px;
  }
}
</style>
