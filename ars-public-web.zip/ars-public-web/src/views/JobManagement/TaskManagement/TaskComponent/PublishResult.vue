<script lang="ts" setup>
import { useCommandExec } from '@/composables/jobManagement/commandExecution'
import { ViewTaskRes } from '@/models/jobManagement/taskManagement'
import { watch } from 'vue'

// 父组件传值
const props = defineProps<{
  publishData: ViewTaskRes | null
}>()

const { getExecList, commandUuid, execResult } = useCommandExec()
watch(
  () => props?.publishData?.publish_uuid,
  uuid => {
    if (uuid) {
      commandUuid.value = uuid
      getExecList()
    }
  },
  { immediate: true }
)
</script>

<template>
  <div class="publishResult">
    <h3 class="big__title">发布结果</h3>
    <pre class="publishResult__content">
      {{ execResult }}
    </pre>
  </div>
</template>

<style lang="less" scoped>
@import (reference) '@/assets/styles/index.less';
.publishResult {
  padding: 17px 36px 48px 36px !important;
  background: #fff;
  &__content {
    min-height: 220px;
    max-height: 500px;
    overflow-y: auto;
    line-height: 15px;
    margin: 24px auto;
    padding: 20px;
    width: 80%;
    background: #ebf1f5;
  }
}
.big__title {
  font-size: 14px;
  font-weight: bold;
  line-height: 19px;
  border-bottom: 1px solid #ebf1f5;
  padding-bottom: 12px;
}
* {
  color: @textColor_first !important;
  font-size: 14px;
}
</style>
