import useRequest from '@/common/useRequest'
import { ApprovalListItem } from '@/models/home/approval'
import { ApprovalToastItem } from '@/models/home/approvalToast'
import { approvalToastApi } from '@/services/home/approval'
import { message } from 'ant-design-vue'
import { ref } from 'vue'

export const columns: Utils.ColumnField<ApprovalToastItem>[] = [
  { title: '时间', dataIndex: 'updated_at' },
  { title: '审核人', dataIndex: 'approver' },
  { title: '审核结果', dataIndex: 'state' },
  { title: '评论', dataIndex: 'note' }
]

export const colors = [
  { text: '待审核', color: 'blue', id: 0, words: '去审核' },
  { text: '审核通过，待发布', color: 'cyan', id: 1, words: '查看' },
  { text: '审核失败', color: 'red', id: 2, words: '查看' },
  { text: '已发布', color: 'yellow', id: 3, words: '查看' }
]

export const opreateStateShift = [
  { operateId: 0, shiftName: '未处理' },
  { operateId: 1, shiftName: '已通过' },
  { operateId: 2, shiftName: '已驳回' }
]

/** 操作审批弹窗和任务审批表格 仅获取表格数据 */
export function useApprovalToast() {
  const dataSource = ref<ApprovalToastItem[]>([])

  const { loading, run } = useRequest(approvalToastApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data || []
      } else {
        message.error(msg)
      }
    }
  })

  function handleSearch(id: number) {
    try {
      return run(id)
    } catch (e) {}
  }

  return { loading, dataSource, handleSearch }
}

/** 非接口封装函数，是公用的操作审批弹窗 */
export const useAprovalToastEffect = (successFn: () => void) => {
  const visible = ref<boolean>(false)
  const recordToast = ref<ApprovalListItem | null>(null)
  const handleShow = (record: ApprovalListItem) => {
    recordToast.value = record
    visible.value = true
  }
  const isAgreeOperate = () => {
    successFn()
    visible.value = false
  }
  return { visible, handleShow, isAgreeOperate, recordToast }
}
