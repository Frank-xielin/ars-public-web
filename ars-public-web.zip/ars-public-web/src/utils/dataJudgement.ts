type KeysCallback<T> = (key: T, keys: Array<T>) => void | boolean

/**
 * 获取对象自身可枚举属性的数组
 * @param obj
 */
export function keysArray<T extends Utils.Dict>(obj: T) {
  return Object.keys(obj) as (keyof T)[]
}

/**
 * 遍历对象的 key 值
 * @param obj 目标对象
 * @param callback 遍历的回调
 * @returns 返回 true 可以提前停止遍历
 */
export function Objectkeys<T extends Utils.Dict>(obj: T, callback: KeysCallback<keyof T>) {
  const keys = keysArray(obj)
  keys.some(key => callback(key, keys))
}

/**
 * 判断字符串是否相同
 * @param str1
 * @param str2
 * @description 判断忽略大小写
 */
export function strEquals(str1: string, str2: string) {
  return str1.toLowerCase() === str2.toLowerCase()
}

/**
 * 获取数字，如果不是数字或为空则返回 0
 * @param value
 */
export function getCurrentNum(value: string | number) {
  if (isNaN(+value)) {
    return 0
  }
  return +value
}

/**
 * 格式化秒数为带单位的字符串
 * @param sec
 * @returns
 */
export function formatTime(sec: number): string {
  if (sec >= 86400) {
    return Math.floor(sec / 86400) + '天' + (sec % 86400 ? formatTime(sec % 86400) : '')
  } else if (sec >= 3600) {
    return Math.floor(sec / 3600) + '小时' + (sec % 3600 ? formatTime(sec % 3600) : '')
  } else if (sec >= 60) {
    return Math.floor(sec / 60) + '分钟' + (sec % 60 ? formatTime(sec % 60) : '')
  }
  return sec + '秒'
}

/**
 * 带缺省的分页数据
 * @param vo
 * @returns
 */
export function defaultPager(vo?: Utils.SearchVO) {
  return vo ?? { page: 1, page_size: 10000 }
}
