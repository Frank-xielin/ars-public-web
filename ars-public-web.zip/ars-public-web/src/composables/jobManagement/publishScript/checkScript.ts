import { ScriptListItem } from '@/models/jobManagement/publishScript'
import router from '@/router'
import { getScriptInfoApi } from '@/services/jobManagement/publishScript'
import { message } from 'ant-design-vue'
import { ref } from 'vue'
import { useRoute } from 'vue-router'

/** 获取单个脚本信息 */
export function useGetScriptInfo() {
  const isEdit = ref(false)
  const route = useRoute()
  const scriptId = ref(0)
  const scriptInfo = ref<ScriptListItem | null>(null)

  async function getScriptById(id: number) {
    try {
      const reply = await getScriptInfoApi(id)
      const { code, data, msg } = reply
      if (code === 0 && data) {
        scriptInfo.value = data
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  function initScriptInfo() {
    const { type, id } = route.query
    isEdit.value = type === 'edit'
    if (type && id) {
      scriptId.value = +id
      getScriptById(scriptId.value)
    } else {
      message.warn('无效的脚本id！')
      router.push({ path: '/JobManagement/PublishScript' })
    }
  }

  return { scriptInfo, scriptId, isEdit, getScriptById, initScriptInfo }
}
