interface EnvConfig {
  baseApi: string
  mockApi: string
}

export enum EnvTypes {
  DEV = 'development',
  PROD = 'production'
}

const env: EnvTypes = (import.meta.env.MODE as EnvTypes) || EnvTypes.PROD
const url = import.meta.env.VITE_BASE_URL

const envConfigs: Record<EnvTypes, EnvConfig> = {
  development: {
    baseApi: url,
    mockApi: ''
  },
  production: {
    baseApi: url,
    mockApi: ''
  }
}

const config = {
  env,
  mock: false,
  namespace: 'system-public',
  version: 'v5.1.0',
  ...envConfigs[env]
}

export default config
