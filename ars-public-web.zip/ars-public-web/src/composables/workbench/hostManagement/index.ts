import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import {
  BatchCreateDevicesItem,
  DeviceListItem,
  DeviceListParams,
  ShutdownDevicesParams,
  UsersClusterListItem
} from '@/models/workbench/hostManagement'
import {
  batchCreateDevicesApi,
  batchRemoveFaultMachinesApi,
  deviceListApi,
  importDevicesApi,
  restartLotusApi,
  startLotusApi,
  stopLotusApi,
  usersClusterListApi
} from '@/services/workbench/hostManagement'
import { requestHandler } from '@/utils/formTools'
import { Form, message } from 'ant-design-vue'
import { Ref, ref, watch } from 'vue'

export interface ApprovalInfo {
  visible: boolean
  operation: string
  func: number
  submit: ((msg: string) => void) | null
}
export const softwareList = [
  { value: -1, label: '全部' },
  { value: 0, label: 'unset' },
  { value: 1, label: 'node' },
  { value: 2, label: 'miner' },
  { value: 3, label: 'miner-back' },
  { value: 4, label: 'seal' },
  { value: 5, label: 'storage' },
  { value: 6, label: 'window/winning' }
]
export const workStatusList = [
  { label: '全部', value: -1 },
  { label: '未工作', value: 0 },
  { label: '在线', value: 1 },
  { label: '离线', value: 2 }
]
export const machineStatusList = [
  { label: '全部', value: -1 },
  { label: '正常', value: 1 },
  { label: '故障', value: 2 }
]

/** 获取当前用户的集群列表 */
export function useCurrentUsersClusterList() {
  const dataSource = ref<UsersClusterListItem[]>([])

  async function searchCurrentUsersClusters() {
    try {
      const reply = await usersClusterListApi()
      if (reply.code === 0) {
        dataSource.value = reply.data || []
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { dataSource, searchCurrentUsersClusters }
}

/** 根据集群 id 获取主机数据列表 */
export function useMachineListOfCluster(callback?: () => void) {
  const minerId = ref('')
  const searchForm = ref<Omit<Utils.NoPager<DeviceListParams>, 'miner_id'>>({
    software_type: -1,
    worker_status: -1,
    machine_status: -1,
    sn_ip: ''
  })
  const dataSource = ref<DeviceListItem[]>([])
  const statistics = ref({ online: 0, offline: 0 })
  const form = Form.useForm(searchForm)
  const { pageVo, setPageFromData } = usePagination()

  const { run: devicesFetch, loading } = useRequest(deviceListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        statistics.value = { online: data?.online_size || 0, offline: data?.offline_size || 0 }
        setPageFromData(data)
      } else {
        message.error(msg)
      }
      callback?.()
    }
  })

  async function handleSearch(vo?: Utils.SearchVO) {
    try {
      const params: DeviceListParams = {
        ...searchForm.value,
        miner_id: minerId.value,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      devicesFetch(params)
    } catch (e) {}
  }

  watch(minerId, () => {
    handleSearch()
  })

  return { loading, form, minerId, statistics, pageVo, searchForm, dataSource, handleSearch }
}

/** 添加主机 */
export function useCreateDevices(successFn: () => void) {
  async function batchAddDevices(miner_id: string, list: BatchCreateDevicesItem[]) {
    try {
      const reply = await batchCreateDevicesApi({ miner_id, list })
      if (reply.code === 0) {
        message.success('添加成功')
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  async function importDevices(miner_id: string, files: FormData) {
    try {
      const reply = await importDevicesApi(miner_id, files)
      if (reply.code === 0) {
        message.success('导入成功')
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { batchAddDevices, importDevices }
}

/**
 * 移除故障机
 * @param selected 已选的机器
 * @param successFn 删除成功的回调
 * @returns
 */
export function useDeleteFaultDevices(
  minerId: Ref<string>,
  selected: Ref<DeviceListItem[]>,
  approvalInfo: Ref<ApprovalInfo>,
  successFn: () => void
) {
  const { run } = useRequest(batchRemoveFaultMachinesApi, {
    onSuccess: reply => {
      if (reply.code === 0) {
        approvalInfo.value.visible = false
        successFn()
      }
      requestHandler('移除成功')(reply)
    }
  })

  async function deleteDevices() {
    if (!selected.value.length) {
      message.warn('请选择至少一条数据')
      return
    }
    const isAllFault = selected.value.every(sel => sel.machine_status === 2)
    if (!isAllFault) {
      message.warn('只能移除故障机')
      return
    }
    approvalInfo.value = {
      visible: true,
      func: 27,
      operation: '移除故障机',
      submit: async message => {
        try {
          const sns = selected.value.map(sel => sel.device_sn)
          return run({ sns, message, miner_id: minerId.value })
        } catch (e) {}
      }
    }
  }

  return { deleteDevices }
}

export type LotusOperation = '启动Lotus' | '重启Lotus' | '停止Lotus'

/**
 * 操作 lotus 进程
 * @param selected 已选的机器
 * @param successFn
 * @returns
 */
export function useLotusOperations(
  minerId: Ref<string>,
  selected: Ref<DeviceListItem[]>,
  approvalInfo: Ref<ApprovalInfo>,
  successFn: () => void
) {
  const { run: startFetch } = useRequest(startLotusApi, {
    onSuccess: reply => {
      approvalInfo.value.visible = false
      successFn()
      requestHandler('lotus启动成功')(reply)
    }
  })
  const { run: restartFetch } = useRequest(restartLotusApi, {
    onSuccess: reply => {
      approvalInfo.value.visible = false
      successFn()
      requestHandler('lotus重启成功')(reply)
    }
  })
  const { run: stopFetch } = useRequest(stopLotusApi, {
    onSuccess: reply => {
      approvalInfo.value.visible = false
      successFn()
      requestHandler('lotus停止成功')(reply)
    }
  })

  function triggerLotus(type: LotusOperation) {
    if (!selected.value.length) {
      message.warn('请至少选择一条数据')
      return
    }
    approvalInfo.value = {
      visible: true,
      func: type.includes('重启') ? 30 : type.includes('启动') ? 29 : 31,
      operation: type,
      submit: async message => {
        try {
          const params: ShutdownDevicesParams = {
            sns: selected.value.map(sel => sel.device_sn),
            miner_id: minerId.value,
            message
          }
          if (type === '启动Lotus') {
            startFetch(params)
          } else if (type === '重启Lotus') {
            restartFetch(params)
          } else {
            stopFetch(params)
          }
        } catch (e) {}
      }
    }
  }

  return { triggerLotus }
}
