import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { TaskManagementItem, TaskManagementParams } from '@/models/jobManagement/taskManagement'
import {
  allTaskApprovalApi,
  deleteTaskApi,
  taskManagementApi
} from '@/services/jobManagement/taskManagement'
import { Form, message, Modal, SelectProps } from 'ant-design-vue'
import { Dayjs } from 'dayjs'
import { ref } from 'vue'

export const columns: Utils.ColumnField<TaskManagementItem>[] = [
  { title: '任务名称', dataIndex: 'name' },
  { title: '目标集群', dataIndex: 'miner' },
  { title: '主机', dataIndex: 'devices' },
  { title: '提交人', dataIndex: 'creator' },
  { title: '提交时间', dataIndex: 'created_at' },
  { title: '状态', dataIndex: 'state' },
  { title: '操作', dataIndex: 'id', width: 150 }
]

export const colors = [
  // { text: '全部', color: 'purple', id: 0 },
  { text: '待提交', color: 'purple', id: 0 },
  { text: '待审核', color: 'blue', id: 1 },
  { text: '审核失败', color: 'red', id: 2 },
  { text: '审核通过，待发布', color: 'cyan', id: 3 },
  { text: '已发布', color: 'yellow', id: 4 }
]

/** 任务状态筛选 */
export const statefilterOptions = ref<SelectProps['options']>([
  {
    value: '',
    label: '全部'
  },
  {
    value: 1,
    label: '待审核'
  },
  {
    value: 2,
    label: '审核失败'
  },
  {
    value: 3,
    label: '审核通过，待发布'
  },
  {
    value: 4,
    label: '已发布'
  }
])

interface SearchForm extends Utils.NoPager<TaskManagementParams> {
  dates?: [Dayjs, Dayjs]
}

/** 查看全部任务 */
export function useAlltaskApproval() {
  const searchModel = ref<SearchForm>({
    state: '',
    search: '',
    start_date: '',
    end_date: '',
    dates: undefined
  })
  const dataSource = ref<TaskManagementItem[]>([])
  const { pageVo, setPageFromData } = usePagination() // pageVo是分页的数据，底下的setPageFromData是再拿一遍，防止没拿到
  const form = Form.useForm(searchModel)

  const { loading, run } = useRequest(allTaskApprovalApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  // 手动刷新函数，可直接执行 handleSearch()
  function handleSearch(vo?: Utils.SearchVO) {
    try {
      // 设置开始时间至结束时间的逻辑
      searchModel.value.start_date =
        searchModel.value.dates?.[0].format('YYYY-MM-DD HH:mm:ss') || ''
      searchModel.value.end_date = searchModel.value.dates?.[1].format('YYYY-MM-DD HH:mm:ss') || ''
      const params: TaskManagementParams = {
        ...searchModel.value,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params) // run就是刷新核心，可直接用
    } catch (e) {}
  }

  return { loading, searchModel, dataSource, form, pageVo, handleSearch }
}

/** 任务管理列表 分页 */
export function useTaskManagement() {
  const searchModel = ref<SearchForm>({
    state: '',
    search: '',
    start_date: '',
    end_date: '',
    dates: undefined
  })
  const dataSource = ref<TaskManagementItem[]>([])
  const { pageVo, setPageFromData } = usePagination() // pageVo是分页的数据，底下的setPageFromData是再拿一遍，防止没拿到
  const form = Form.useForm(searchModel)

  const { loading, run } = useRequest(taskManagementApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  // 手动刷新函数，可直接执行 handleSearch()
  function handleSearch(vo?: Utils.SearchVO) {
    try {
      // 设置开始时间至结束时间的逻辑
      searchModel.value.start_date =
        searchModel.value.dates?.[0].format('YYYY-MM-DD HH:mm:ss') || ''
      searchModel.value.end_date = searchModel.value.dates?.[1].format('YYYY-MM-DD HH:mm:ss') || ''
      const params: TaskManagementParams = {
        ...searchModel.value,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params) // run就是刷新核心，可直接用
    } catch (e) {}
  }

  return { loading, searchModel, dataSource, form, pageVo, handleSearch }
}

/** 删除任务 单个 */
export function useDeleteTask(successFn: () => void) {
  async function deleteTask(id: number) {
    Modal.confirm({
      content: '是否删除此任务',
      onOk: async () => {
        try {
          const reply = await deleteTaskApi(id)
          if (reply.code === 0) {
            message.success('删除成功')
            successFn()
          } else {
            message.error(reply.msg)
          }
        } catch (e) {}
      }
    })
  }
  return { deleteTask }
}
