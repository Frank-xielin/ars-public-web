<script lang="ts" setup>
import { useMainStore } from '@/store'
import { strEquals } from '@/utils/dataJudgement'
import { ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const store = useMainStore()
const route = useRoute()
const router = useRouter()
const isReady = ref(false)
const showHeader = ref(false)

watch(
  () => route.path,
  path => {
    isReady.value = false
    showHeader.value = false
    router.isReady().then(() => {
      isReady.value = true
      strEquals(path, '/Login')
        ? setTimeout(() => {
            showHeader.value = true
          }, 500)
        : (showHeader.value = true)
    })
  },
  { immediate: true }
)
</script>

<template>
  <aside-menu v-show="isReady" v-if="!strEquals($route.path, '/Login')" />
  <main>
    <header-wrapper :visible="showHeader" />
    <div :class="['main-content', { current: !strEquals($route.path, '/Login') }]">
      <router-view />
    </div>
  </main>
  <loading :spinning="store.globalLoading.loading || store.routerLoading" :delay="500" />
</template>

<style lang="less">
@import (reference) '@/assets/styles/index.less';

main {
  flex: 1;
  height: 100%;
  background: @backDivColor;
  .main-content {
    position: relative;
    height: 100vh;
    background: @backDivColor;
    border-radius: 3px;

    &.current {
      height: calc(100vh - 109px);
      max-width: calc(100vw - 240px);
      .safety-padding;
      padding-top: 0;

      > div[class*='-page'],
      div.page {
        position: relative;
        height: calc(100vh - 129px);
        width: 100%;
        overflow: hidden auto;
        .safety-padding;
      }
    }
    @media screen and (max-width: 1440px) {
      &.current {
        max-width: calc(100vw - 194px);
      }
    }
  }
}

button.header-wrapper-logout {
  position: fixed;
  top: 20px;
  right: 20px;
}
</style>
