import {
  OverviewDetailParams,
  OverviewDetailRes,
  OverviewListAllParams,
  OverviewListAllRes,
  OverviewListParams,
  OverviewListRes
} from '@/models/workbench/clusterOverview'
import { request } from '@/utils/httpConfig'

/**
 * 集群概览列表 - 分页
 * @param data
 * @returns
 */
export function overviewListApi(data: OverviewListParams) {
  return request<OverviewListRes>({
    url: 'v5/public/overview/get/list',
    method: 'GET',
    data,
    loading: true
  })
}

/**
 * 集群概览列表 - 全部
 * @param data
 * @returns
 */
export function overviewListAllApi(data: OverviewListAllParams) {
  return request<OverviewListAllRes>({
    url: 'v5/public/overview/get/all',
    method: 'GET',
    data,
    loading: true
  })
}

/**
 * 集群概览列表详情
 * @param data
 * @returns
 */
export function overviewDetailApi(data: OverviewDetailParams) {
  return request<OverviewDetailRes>({
    url: 'v5/public/overview/get/info',
    method: 'GET',
    data
  })
}
