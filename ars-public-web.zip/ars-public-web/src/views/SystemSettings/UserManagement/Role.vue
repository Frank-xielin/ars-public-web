<script lang="ts" setup>
import { useAllClientList } from '@/composables/systemSettings/clientInformation'
import {
  columns,
  deleteRole,
  useRoleAllList
} from '@/composables/systemSettings/userManagement/role'
import { useAddEditModal } from '@/composables/workbench/errorRecord'
import { RoleListItem } from '@/models/systemSettings/userManagement/role'
import { useRouter } from 'vue-router'
import AddEditRole from './Role/AddEditRole.vue'

const router = useRouter()
const { searchModel, dataSource, loading, pageVo, handleSearch } = useRoleAllList()
const { visible, modalType, targetInfo, addModal, editModal } = useAddEditModal<RoleListItem>()
const { clients, getAllClients } = useAllClientList()

/** 进入权限修改/查看页面 */
function changeRolesAuth(id: number) {
  router.push({
    path: '/SystemSettings/UserManagement/Role/Auth',
    query: { type: id === 1 ? 'check' : 'change', id }
  })
}
function handleDelete(id: number) {
  deleteRole(id, onSearch)
}
function onSearch(vo?: Utils.SearchVO) {
  handleSearch(vo)
  getAllClients()
}
onSearch()
</script>

<template>
  <div class="role page">
    <a-form layout="inline">
      <a-form-item label="搜索">
        <custom-search-input
          placeholder="输入关键字"
          v-model:value="searchModel.search"
          @search-func="onSearch()"
        />
      </a-form-item>
      <a-form-item class="right-form-item">
        <a-button :disabled="!$auth(64)" type="primary" shape="round" @click="addModal()">
          新建角色
        </a-button>
      </a-form-item>
    </a-form>

    <a-table
      class="table-box"
      v-bind="$tableConfigs(dataSource, loading, pageVo, onSearch)"
      row-key="id"
      :scroll="$scroller('calc(100vh - 350px)')"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ column: col, text, record }">
        <div v-if="col.title === '操作'">
          <template v-if="!record.keyword">
            <a-button
              type="link"
              :disabled="!$auth(65)"
              class="table-btn"
              @click="editModal(record)"
            >
              编辑
            </a-button>
            <a-button
              type="link"
              :disabled="!$auth(66)"
              class="table-btn"
              @click="handleDelete(text)"
            >
              删除
            </a-button>
          </template>
          <span v-else>---</span>
        </div>
        <a
          :disabled="!$auth(70)"
          v-else-if="col.title === '权限'"
          :class="['table-btn', { 'text-btn': record.keyword }]"
          @click="changeRolesAuth(text)"
        >
          {{ record.keyword ? '查看' : '设置' }}
        </a>
        <custom-tooltip v-else>
          <span v-if="col.title === '自定义'">
            {{ text ? '否' : '是' }}
          </span>
          <span v-else-if="col.title === '所属客户'">
            {{ clients.find(client => client.id === text)?.name }}
          </span>
          <span v-else>{{ text }}</span>
        </custom-tooltip>
      </template>
    </a-table>

    <add-edit-role
      v-model:visible="visible"
      :modal-type="modalType"
      :target-info="targetInfo"
      @search="handleSearch(modalType === '编辑' ? pageVo : undefined)"
    />
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.right-form-item {
  position: absolute;
  right: 30px;
}
a.text-btn {
  color: @textColor_first;
  text-decoration: underline;
}
</style>
