import useRequest from '@/common/useRequest'
import {
  requireInput,
  requireSelect
} from '@/composables/systemSettings/clusterInformation/addEditCluster'
import { CreateTaskParams, UpdateTaskParams } from '@/models/jobManagement/taskManagement'
import { createTaskApi, upadateTaskApi } from '@/services/jobManagement/taskManagement'
import { requestHandler } from '@/utils/formTools'
import { Form } from 'ant-design-vue'
import { ref } from 'vue'

const initialValues: CreateTaskParams = {
  name: '',
  miner: '',
  device_sn_list: [],
  script_id: undefined,
  script_content: '',
  script_params: '',
  timeout: 0,
  exec_user: 'root',
  note: '',
  auto_submit: false
}
const rulesObj: Utils.RulesObject<CreateTaskParams> = {
  name: [requireInput('任务名称')],
  miner: [requireSelect('目标集群')],
  device_sn_list: [requireInput('目标主机')],
  // script_id: [requireSelect('选择脚本')],
  script_content: [requireInput('脚本内容')],
  timeout: [requireInput('超时时长')],
  // exec_user: [requireInput('执行账号')],
  note: [requireInput('备注')]
}

/**
 * 新建任务
 * @returns
 */
export function useCreateTasks(successFn: (id: number) => void) {
  const formModel = ref<CreateTaskParams>({ ...initialValues })
  const rules = ref(rulesObj)
  const form = Form.useForm(formModel, rules)

  const { run: createRun } = useRequest(createTaskApi, {
    onSuccess: reply => {
      if (reply.code === 0) {
        successFn(reply.data?.id || 0)
      }
      requestHandler('新建任务成功')(reply)
    }
  })

  async function submitForm(submit_approve: boolean) {
    try {
      await form.validate()
      // 提交审核的核心字段  为了解决点击两次的问题，将OnSubmit的校验逻辑移到这了
      formModel.value.auto_submit = submit_approve
      formModel.value.timeout = +formModel.value.timeout

      return createRun(formModel.value)
    } catch (e) {
      console.log(e)
    }
  }

  return { formModel, form, submitForm }
}

/**
 * 编辑任务
 * @param successFn
 * @returns
 */
export function useUpdateTasks(successFn: () => void) {
  const formModel = ref<UpdateTaskParams>({ ...initialValues })
  const rules = ref(rulesObj)
  const form = Form.useForm(formModel, rules)

  const { run: updateRun } = useRequest(upadateTaskApi, {
    onSuccess: reply => {
      if (reply.code === 0) {
        successFn()
      }
      requestHandler('编辑成功')(reply)
    }
  })

  async function submitForm(id: number, auto: boolean) {
    try {
      await form.validate()
      formModel.value.auto_submit = auto // 编辑的保存是否自动审核校验移动到这了，本应该在editTask里
      updateRun(id, formModel.value)
    } catch (e) {
      console.log(e)
    }
  }

  return { formModel, form, submitForm }
}
