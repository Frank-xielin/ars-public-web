import useRequest from '@/common/useRequest'
import { CurrentUserLog, UpdateCurrentUserParams } from '@/models/personal/personalInfomation'
import { UserInfoByIdRes } from '@/models/systemSettings/userManagement/user'
import { currentUserLogsApi, updateCurrentUserApi } from '@/services/personal/personalInfomation'
import { getUserInfoByIdApi } from '@/services/systemSettings/userManagement/user'
import { useMainStore } from '@/store'
import { message } from 'ant-design-vue'
import { Ref, ref } from 'vue'

export const historyCols: Utils.ColumnField<CurrentUserLog>[] = [
  { title: '登录时间', dataIndex: 'datetime' },
  { title: '位置', dataIndex: 'city' },
  { title: 'IP地址', dataIndex: 'ip' },
  { title: '浏览器', dataIndex: 'user_agent' },
  { title: '手机号', dataIndex: 'phone' },
  { title: '登录结果', dataIndex: 'status' },
  { title: '状态', dataIndex: 'is_abnormal' }
]

const initialInfo: UserInfoByIdRes = {
  id: 0,
  created_at: '',
  updated_at: '',
  deleted_at: '',
  user_name: '',
  passwd: '',
  phone: '',
  email: '',
  avatar: '',
  nick_name: '',
  introduction: '',
  created_by: 0,
  last_login: '',
  is_first_login: 0,
  passwd_need_modify: 0,
  passwd_expired: '',
  passwd_last_updated: '',
  client_id: 0,
  updated_by: 0,
  leader: false,
  approve: false,
  enable: false,
  user_group_id: 0,
  role_id: []
}

/**
 * 获取当前登录用户的信息和登录历史
 * @param successFn
 * @returns
 */
export function useCurrentUserInfo(successFn: () => void) {
  const store = useMainStore()
  const userInfo = ref<UserInfoByIdRes>({ ...initialInfo })
  const loginLogs = ref<CurrentUserLog[]>([])

  const { run: infoFetch } = useRequest(getUserInfoByIdApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        data && (userInfo.value = data)
      } else {
        message.error(msg)
      }
    }
  })
  const { run: logsFetch, loading } = useRequest(currentUserLogsApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        loginLogs.value = data || []
        successFn()
      } else {
        message.error(msg)
      }
    }
  })

  function getCurrentUserInfo() {
    try {
      infoFetch(store.userInfo?.id || 0)
      logsFetch()
    } catch (e) {}
  }

  return { loading, userInfo, loginLogs, getCurrentUserInfo }
}

/**
 * 更新当前用户信息
 * @param userInfo
 * @param successFn
 * @returns
 */
export function useUpdateCurrentUser(userInfo: Ref<UserInfoByIdRes>, successFn?: () => void) {
  const { run: updateFetch } = useRequest(updateCurrentUserApi, {
    onSuccess: reply => {
      const { code, msg } = reply
      if (code === 0) {
        message.success('修改成功')
        successFn?.()
      } else {
        message.error(msg)
      }
    }
  })

  function submitChanged() {
    console.log(userInfo.value)
    if (!userInfo.value.user_name || !userInfo.value.email) {
      message.warn('请输入正确的内容')
      return
    }
    const params: UpdateCurrentUserParams = {
      user_name: userInfo.value.user_name,
      email: userInfo.value.email
    }
    return updateFetch(params).catch()
  }

  return { submitChanged }
}
