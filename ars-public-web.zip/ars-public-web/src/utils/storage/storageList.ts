enum Modules {
  MINER_INFO = 'minerInfo',
  USER = 'user',
  MENUS = 'menus'
}

export const storageKeys = {
  token: 'public-jwt',
  /** 上一页路由地址 */
  lastPath: 'lastPath',
  /** 当前集群 id */
  currentId: { key: 'currentId', module: Modules.MINER_INFO },
  /** 用户信息 */
  userId: { key: 'userId', module: Modules.USER },
  /** 可用菜单列表 */
  menuList: { key: 'menuList', module: Modules.MENUS },
  /** 可用菜单映射表 */
  menuMap: { key: 'menuMap', module: Modules.MENUS },
  /** 可用按钮 */
  buttonAuths: { key: 'buttonAuths', module: Modules.MENUS }
}
