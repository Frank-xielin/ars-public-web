export interface CurrentUserLog {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string
  user_id: number
  phone: string
  ip: string
  city: string
  user_agent: string
  datetime: string
  status: number
  is_abnormal: number
  note: string
}

export type CurrentUserLogsRes = CurrentUserLog[]

export interface UpdateCurrentUserParams {
  user_name: string
  email: string
}
