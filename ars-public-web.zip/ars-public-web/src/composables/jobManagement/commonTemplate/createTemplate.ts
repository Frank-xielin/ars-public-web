import {
  requireInput,
  requireSelect
} from '@/composables/systemSettings/clusterInformation/addEditCluster'
import { CreateTemplateParams } from '@/models/jobManagement/commonTemplate'
import { createTemplateApi } from '@/services/jobManagement/commonTemplate'
import { Form, message } from 'ant-design-vue'
import { ref } from 'vue'

export const templateFormValues: CreateTemplateParams = {
  content: '',
  enabled: false,
  name: '',
  note: '',
  type_id: undefined
}

/** 创建公共模板 */
export function useCreateTemplate(successFn?: () => void) {
  const formModel = ref<CreateTemplateParams>({ ...templateFormValues })
  const rules = ref<Utils.RulesObject<CreateTemplateParams>>({
    type_id: [requireSelect('模板类型')],
    name: [requireInput('模板名称')],
    content: [requireInput('模板内容')]
  })
  const form = Form.useForm(formModel, rules)

  async function submitForm() {
    try {
      await form.validate()
      const reply = await createTemplateApi(formModel.value)
      if (reply.code === 0) {
        message.success('新建模板成功')
        successFn?.()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { formModel, form, submitForm }
}
