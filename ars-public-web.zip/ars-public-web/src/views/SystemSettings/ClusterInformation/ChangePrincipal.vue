<script lang="ts" setup>
import { usePrincipalList } from '@/composables/systemSettings/clusterInformation'
import { useUserManager } from '@/composables/systemSettings/userManagement/user/userManageTab'
import { ref, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  minerId: string
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()

const columns: Utils.ColumnField[] = [{ title: '用户', dataIndex: 'user_name' }]
const selectedRows = ref<number[]>([])

const { dataSource, loading, handleSearch } = useUserManager()
const { bindedUsers, listFetch, onSubmit } = usePrincipalList(() => {
  emit('update:visible', false)
  emit('search')
})

function selectionHandle(keys: Utils.Key[]) {
  selectedRows.value = keys as number[]
}

watch(
  () => props.visible,
  visible => {
    if (visible) {
      handleSearch({ page: 1, page_size: 10000 })
      listFetch(props.minerId)
        .then(() => {
          selectedRows.value = bindedUsers.value.map(user => user.principal_id)
        })
        .catch()
    } else {
      dataSource.value.length = 0
      selectedRows.value.length = 0
    }
  }
)
</script>

<template>
  <a-modal
    title="添加负责人"
    :visible="visible"
    @ok="onSubmit(minerId, selectedRows)"
    @cancel="$emit('update:visible', false)"
  >
    <a-table
      v-bind="$tableConfigs(dataSource, loading)"
      :row-selection="{ selectedRowKeys: selectedRows, onChange: selectionHandle }"
      :columns="$columnsSetter(columns)"
      row-key="id"
      :scroll="{ y: 400 }"
    />
  </a-modal>
</template>
