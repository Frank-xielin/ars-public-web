<script lang="ts" setup>
import { useInitCurrentUserInfo } from '@/composables/layout'
import { loginStatusList } from '@/composables/logManagement/loginLog'
import {
  historyCols,
  useCurrentUserInfo,
  useUpdateCurrentUser
} from '@/composables/personal/personalInfomation'
import { useRoleAllList } from '@/composables/systemSettings/userManagement/role'
import { useUserGroupManager } from '@/composables/systemSettings/userManagement/user/userGroupManageTab'
import { ref } from 'vue'
import UpdateCurrentPassword from './PersonalInfomation/UpdateCurrentPassword.vue'

const editName = ref(false)
const editEmail = ref(false)
const editPwd = ref(false)
const { initUserInfo } = useInitCurrentUserInfo()
const { loading, userInfo, loginLogs, getCurrentUserInfo } = useCurrentUserInfo(() => {
  editName.value = false
  editEmail.value = false
  editPwd.value = false
})
const { submitChanged } = useUpdateCurrentUser(userInfo, () => {
  onSearch()
  initUserInfo()
})
const { dataSource: groupList, handleSearch: getAllGroups } = useUserGroupManager()
const { dataSource: roleList, handleSearch: getAllRoles } = useRoleAllList()

function showRoleNameList(roleIds: number[]) {
  if (!roleIds.length) {
    return '未设置'
  }
  return roleIds.map(id => roleList.value.find(role => role.id === id)?.name).join()
}
function onSearch() {
  getCurrentUserInfo()
  getAllGroups()
  getAllRoles()
}
onSearch()
</script>

<template>
  <div class="personal-infomation page">
    <div class="info-block">
      <h3 class="block-title">基本信息</h3>
      <div class="info-list">
        <a-form layout="inline" class="base-info-form">
          <a-form-item label="用户名">
            <div class="readonly-text" v-if="!editName">
              <span class="value-text">{{ userInfo.user_name }}</span>
              <icon-font type="icon-icon_edit" @click="editName = true" />
            </div>
            <template v-else>
              <a-input style="width: 250px" v-model:value="userInfo.user_name" />
              <a-button @click="submitChanged()">
                <check-outlined />
              </a-button>
              <a-button @click="editName = false">
                <close-outlined />
              </a-button>
            </template>
          </a-form-item>
          <a-form-item label="中文名">
            <span class="value-text">{{ userInfo.nick_name }}</span>
          </a-form-item>
          <a-form-item label="手机号">
            <span class="value-text">{{ userInfo.phone }}</span>
          </a-form-item>
          <a-form-item label="邮箱">
            <div class="readonly-text" v-if="!editEmail">
              <span class="value-text">{{ userInfo.email }}</span>
              <icon-font type="icon-icon_edit" @click="editEmail = true" />
            </div>
            <template v-else>
              <a-input style="width: 250px" type="email" v-model:value="userInfo.email" />
              <a-button @click="submitChanged()">
                <check-outlined />
              </a-button>
              <a-button @click="editEmail = false">
                <close-outlined />
              </a-button>
            </template>
          </a-form-item>
          <a-form-item label="分组">
            <span class="value-text">
              {{ groupList.find(item => item.id === userInfo.user_group_id)?.name }}
            </span>
          </a-form-item>
          <a-form-item label="角色">
            <span class="value-text">{{ showRoleNameList(userInfo.role_id) }}</span>
          </a-form-item>
        </a-form>
      </div>
    </div>
    <div class="info-block">
      <h3 class="block-title">帐号安全</h3>
      <div class="info-list">
        <a-form class="base-info-form">
          <a-form-item label="登录密码">
            <div class="readonly-text">
              <span class="value-text">******</span>
              <icon-font type="icon-icon_edit" @click="editPwd = true" />
            </div>
          </a-form-item>
        </a-form>
      </div>
    </div>
    <update-current-password v-model:visible="editPwd" @search="onSearch" />

    <div class="info-block">
      <h3 class="block-title">
        登录历史
        <span class="tips">如果发现非本人登录，请及时修改密码</span>
      </h3>
      <div class="info-list">
        <a-table
          class="login-history-table"
          v-bind="$tableConfigs(loginLogs, loading)"
          :columns="$columnsSetter(historyCols)"
          bordered
          row-class-name="white-row"
          row-key="id"
        >
          <template #bodyCell="{ column: col, text }">
            <custom-tooltip>
              <template v-if="col.title === '状态'">
                {{ loginStatusList.find(item => item.value === text)?.label }}
              </template>
              <template v-else-if="col.title === '登录结果'">
                {{ text === 0 ? '成功' : '失败' }}
              </template>
              <template v-else>{{ text }}</template>
            </custom-tooltip>
          </template>
        </a-table>
        <a-button type="text" @click="$router.push('/Personal/LoginHistory')">
          <u>查看更多</u>
        </a-button>
      </div>
    </div>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';
.personal-infomation {
  background: @backDivColor;
  padding: 0 !important;

  .info-block {
    display: flex;
    flex-direction: column;
    background: @bgClor_main;
    margin-bottom: 20px;
    &:last-of-type {
      margin-bottom: 0;
    }
    .block-title {
      height: 44px;
      margin: 0;
      padding-left: 24px;
      font-size: 14px;
      font-weight: bold;
      color: @textColor_first;
      line-height: 44px;
      border-bottom: 1px solid @ueColor_fifth;
      .tips {
        margin-left: 50px;
        font-size: 12px;
        color: @textColor_third;
      }
    }
    .info-list {
      flex: 1;
      padding: 20px;
      .base-info-form {
        padding-left: 83px;
        .ant-form-item {
          width: 45%;
          margin-bottom: 10px;
        }
      }
      .login-history-table {
        :deep(.white-row) {
          .ant-table-cell {
            line-height: 20px;
            border-bottom: 1px solid #e8ecf0;
          }
        }
      }
    }
    :deep(.ant-form-item-label) {
      margin-right: 50px;
    }
    .value-text {
      display: inline-block;
      min-width: 200px;
      font-size: 14px;
      font-weight: bold;
      color: @textColor_first;
    }
  }
}
</style>
