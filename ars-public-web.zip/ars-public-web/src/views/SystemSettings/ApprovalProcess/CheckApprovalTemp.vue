<script lang="ts" setup>
import { useGetApprovalTempInfo } from '@/composables/systemSettings/approvalProcess/checkApprovalTemp'
import { useNotifyChannelAllList } from '@/composables/systemSettings/approvalProcess/createApprovalTemp'
import { useUserManager } from '@/composables/systemSettings/userManagement/user/userManageTab'
import { dateFormatter } from '@/utils/dateFormat'
import { computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'

const route = useRoute()
const router = useRouter()
const { dataSource: userList, handleSearch: searchUsers } = useUserManager()
const { notifyChannels, getAllNotifyChannels } = useNotifyChannelAllList()
const { formModel, fullTempInfo, form, isEdit, submitChange } = useGetApprovalTempInfo()

const users = computed(() => userList.value.filter(user => user.approve))

function formatter(date = '') {
  return dateFormatter(date, 'YYYY年MM月DD日 HH:mm')
}
function handleCancel() {
  if (route.query.type === 'edit') {
    router.push('/SystemSettings/ApprovalProcess')
  } else {
    isEdit.value = false
  }
}

searchUsers({ page: 1, page_size: 10000 })
getAllNotifyChannels()
</script>

<template>
  <div class="check-approval-temp page">
    <h2 class="title">{{ isEdit ? '编辑' : '查看' }}审批流</h2>
    <div class="operator-wrapper">
      <a-button
        v-if="!isEdit"
        :disabled="!$auth(77)"
        size="middle"
        shape="round"
        @click="isEdit = true"
      >
        编辑
      </a-button>
      <template v-else>
        <a-button shape="round" type="primary" @click="submitChange">保存</a-button>
        <a-button shape="round" @click="handleCancel">取消</a-button>
      </template>
    </div>

    <h3 class="form-title">审批流信息</h3>
    <a-form class="approval-temp-form" :label-col="{ span: 4 }">
      <a-form-item label="名称" v-bind="form.validateInfos.title">
        <span v-if="!isEdit">{{ formModel.title }}</span>
        <a-input v-else v-model:value="formModel.title" />
      </a-form-item>
      <a-form-item label="审核人1" v-bind="form.validateInfos.approver1_id">
        <span v-if="!isEdit">{{ fullTempInfo?.approver1?.user_name }}</span>
        <custom-select
          v-else
          :data="users"
          label-field="user_name"
          value-field="id"
          v-model:value="formModel.approver1_id"
        />
      </a-form-item>
      <a-form-item label="审核人2" v-bind="form.validateInfos.approver2_id">
        <span v-if="!isEdit">{{ fullTempInfo?.approver2?.user_name }}</span>
        <custom-select
          v-else
          :data="users"
          label-field="user_name"
          value-field="id"
          v-model:value="formModel.approver2_id"
          allow-clear
        />
      </a-form-item>
      <a-form-item label="审核人3" v-bind="form.validateInfos.approver3_id">
        <span v-if="!isEdit">{{ fullTempInfo?.approver3?.user_name }}</span>
        <custom-select
          v-else
          :data="users"
          label-field="user_name"
          value-field="id"
          v-model:value="formModel.approver3_id"
          allow-clear
        />
      </a-form-item>
      <a-form-item label="通知人">
        <span v-if="!isEdit">
          {{
            formModel.notifiers
              .map(item => userList.find(user => user.id === item)?.user_name)
              .join(', ')
          }}
        </span>
        <custom-select
          v-else
          :data="userList"
          label-field="user_name"
          value-field="id"
          mode="multiple"
          v-model:value="formModel.notifiers"
        />
      </a-form-item>
      <a-form-item label="通知方式">
        <span v-if="!isEdit">
          {{
            formModel.notify_channels
              .map(item => notifyChannels.find(user => user.id === item)?.name)
              .join(', ')
          }}
        </span>
        <custom-select
          v-else
          :data="notifyChannels"
          value-field="id"
          label-field="name"
          mode="multiple"
          v-model:value="formModel.notify_channels"
        />
      </a-form-item>
      <a-form-item label="启用">
        <a-checkbox
          :disabled="!isEdit || formModel.tag === 'task'"
          v-model:checked="formModel.enabled"
        />
      </a-form-item>
    </a-form>

    <h3 class="form-title">系统信息</h3>
    <a-row class="sys-info">
      <a-col :span="12">
        <span class="label">创建人:</span>
        <span class="name">{{ fullTempInfo?.creator?.user_name }}</span>
        <span class="time">{{ formatter(fullTempInfo?.created_at) }}</span>
      </a-col>
      <a-col :span="12">
        <span class="label">最近修改:</span>
        <span class="name">{{ fullTempInfo?.updater?.user_name }}</span>
        <span class="time">{{ formatter(fullTempInfo?.updated_at) }}</span>
      </a-col>
    </a-row>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.title {
  font-size: 20px;
  padding: 0 20px 20px;
  border-bottom: @tableBorder;
}
.operator-wrapper {
  display: flex;
  justify-content: center;
  margin: 30px;
  > button {
    width: 100px;
    margin: 0 10px;
  }
}
.form-title {
  padding: 10px;
  margin-bottom: 30px;
  font-size: 16px;
  background: @titleBack;
}
.approval-temp-form {
  width: 500px;
  margin: auto;
}
.sys-info {
  width: 80%;
  margin: auto;
  .ant-col {
    span {
      margin-right: 20px;
      font-size: 14px;
    }
  }
}
</style>
