import { MessageListParams, MessageListRes } from '@/models/personal/myMessages'
import { request } from '@/utils/httpConfig'

/** 我的消息 - 获取 */
export function messageListApi(data: MessageListParams) {
  return request<MessageListRes>({
    url: 'v5/public/message/get/list',
    method: 'get',
    data: data
  })
}

/**
 * 我的消息 - 标记已读
 * @param id 消息 id
 * @returns
 */
export function messageReadApi(ids: number[]) {
  return request({
    url: 'v5/public/message/read',
    method: 'patch',
    data: { ids },
    loading: true
  })
}
