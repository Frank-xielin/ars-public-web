import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { ClientListItem } from '@/models/systemSettings/clientInformation'
import {
  clientListAllApi,
  clientListApi,
  deleteClientApi
} from '@/services/systemSettings/clientInformation'
import { message, Modal } from 'ant-design-vue'
import { computed, ref } from 'vue'

export const columns: Utils.ColumnField<ClientListItem>[] = [
  { title: '客户简称', dataIndex: 'name' },
  { title: '备注', dataIndex: 'note' },
  { title: '操作', dataIndex: 'id' }
]

/**
 * 删除客户
 * @param record
 */
export function deleteClient(id: number, successFn: () => void) {
  Modal.confirm({
    content: '是否删除该客户信息',
    async onOk() {
      const reply = await deleteClientApi(id)
      if (reply.code === 0) {
        message.success('删除客户成功')
        successFn()
      } else {
        message.error(reply.msg)
      }
    }
  })
}

export function useClientList() {
  const dataSource = ref<ClientListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()

  const { run: clientListFetch, loading } = useRequest(clientListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  async function handleSearch(vo?: Utils.SearchVO) {
    try {
      return clientListFetch(vo ?? { page: 1, page_size: pageVo.value.page_size })
    } catch (e) {}
  }
  handleSearch()

  return { dataSource, pageVo, loading, handleSearch }
}

const defaultItem = {
  id: -1,
  name: '所属客户',
  created_at: '',
  updated_at: '',
  deleted_at: '',
  note: ''
}

/** 全量客户数据 */
export function useAllClientList() {
  const dataSource = ref<ClientListItem[]>([])
  const clients = computed(() => dataSource.value.filter(item => item.id !== -1))

  async function getAllClients() {
    try {
      const reply = await clientListAllApi()
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = [defaultItem, ...(data || [])]
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { dataSource, clients, getAllClients }
}
