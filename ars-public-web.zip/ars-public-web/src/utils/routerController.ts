import { useCurrentUserAuths, useInitCurrentUserInfo } from '@/composables/layout'
import { MenuListItem } from '@/models/systemSettings/userManagement/auth'
import router from '@/router'
import { useMainStore } from '@/store'
import Cookies from 'js-cookie'
import { cloneDeep } from 'lodash-es'
import { NavigationGuardWithThis } from 'vue-router'
import { strEquals } from './dataJudgement'
import { removeAllPending } from './httpConfig'
import storage from './storage'
import { storageKeys } from './storage/storageList'

const modules = import.meta.glob('../views/**/*.vue')
const personalPage = {
  id: 10000,
  created_at: '',
  updated_at: '',
  deleted_at: null,
  domain: '',
  name: '我的',
  title: '',
  path: 'Personal',
  sort: '',
  status: 0,
  visible: 1,
  parent_id: 0,
  display: true
}

/**
 * 存储上一页路由地址
 * @param path
 */
export function setLastPath(path: string) {
  storage.setItem(storageKeys.lastPath, path)
}

/**
 * 获取上一页路由地址
 * @returns
 */
export function getLastPath() {
  return storage.getItem(storageKeys.lastPath)
}

/** 前置导航守卫控制权限 */
export const routerBeforeEach: NavigationGuardWithThis<undefined> = async (to, from) => {
  const store = useMainStore()
  store.$patch({ routerLoading: true })
  const isLogout = isLogoutCommond()
  if (isLogout) {
    return { path: '/Login' }
  }
  from.path && setLastPath(from.path)

  const isLogin = Cookies.get(storageKeys.token)
  let isFirstLoad = false
  if (!store.isRouteReady && isLogin) {
    isFirstLoad = true
    // 如果是刷新后或者第一次进入页面，则需要通过请求拿到权限数据
    await asyncRouteGetter()
  }

  removeAllPending()
  if (isLogin && strEquals(to.path, '/Login')) {
    // 登录状态下禁止进入登录页
    const last = getLastPath()
    return { path: last || '/' }
  } else if (!isLogin && !strEquals(to.path, '/Login')) {
    // 未登录则直接进入登录页
    return { path: '/Login' }
  }
  return !isFirstLoad ? true : { ...to, replace: true }
}

/** 通过请求获取路由表并插入 */
export async function asyncRouteGetter() {
  const store = useMainStore()
  const { initUserInfo } = useInitCurrentUserInfo()
  const { initCurrentUserAuths } = useCurrentUserAuths()
  await initUserInfo()
  await initCurrentUserAuths()
  const menus = cloneDeep(store.sourceMenu)
  menus.push(personalPage)
  processRoutingData(menus)
}

function processRoutingData(list: MenuListItem[]) {
  const store = useMainStore()

  const menuTree = generateMenuList(list)
  const routes: MenuItem[] = []
  generateRouteList(menuTree, routes)
  Object.entries(modules).forEach(([key, pageImport]) => {
    const target = routes.find(route => {
      const { path } = route
      const fileUrl = path + '.vue'

      return key.includes(fileUrl)
    })

    if (target) {
      router.addRoute({
        path: target.path,
        name: target.path,
        meta: { name: target.path.split('/').pop(), title: target.name },
        component: pageImport
      })
      if (target.path === '/Home') {
        router.addRoute({ path: '/', name: 'Home', redirect: '/Home' })
      }
    }
  })
  if (!router.hasRoute('Home')) {
    router.addRoute({
      path: '/',
      name: 'Home',
      redirect: `/${routes[0]?.path || 'Personal/PersonalInfomation'}`
    })
  }
  store.$patch({ isRouteReady: true, sourceMenu: list, menuList: menuTree })
}

export interface MenuItem extends MenuListItem {
  children?: MenuItem[]
}

/** 生成菜单列表 */
export function generateMenuList(list: MenuItem[]) {
  const menuTree: MenuItem[] = list.filter(first => {
    const children = list.filter(second => {
      return second.parent_id === first.id
    })
    if (children.length) {
      first.children = children
    }

    return first.parent_id === 0
  })

  return menuTree
}

/** 生成路由表 */
function generateRouteList(list: MenuItem[], resArr: MenuItem[], pPath?: string) {
  const sourceList = cloneDeep(list)

  sourceList.forEach(menu => {
    if (pPath) {
      menu.path = [...pPath.split('/'), menu.path].join('/')
      if (menu.path[0] !== '/') {
        menu.path = '/' + menu.path
      }
    } else {
      menu.path = '/' + menu.path
    }
    if (menu.children) {
      generateRouteList(menu.children, resArr, menu.path)
    }

    resArr.push(menu)
  })
}

function isLogoutCommond() {
  if (location.hash.includes('?logout=true')) {
    Cookies.remove(storageKeys.token)
    return true
  }
  return false
}
