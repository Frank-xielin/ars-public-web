export interface SystemOperationLogsParams extends Utils.SearchVO {
  start_time: string
  end_time: string
  key_word: string
}

export interface SystemOperationLogsItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string | null
  user_id: number
  module: string
  operation: string
  content: string
  operator: string
  ip: string
  city: string
  user_agent: string
  datetime: string
  status: number
  note: string
}

export interface SystemOperationLogsRes extends Utils.PageVO {
  list: SystemOperationLogsItem[]
}

export type ClusterOperationLogsParams = SystemOperationLogsParams

export interface ClusterOperationLogsItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string | null
  user_id: number
  module: string
  operation: string
  operation_device: string
  cluster: string
  operator: string
  datetime: string
  status: number
  note: string
}

export interface ClusterOperationLogsRes extends Utils.PageVO {
  list: ClusterOperationLogsItem[]
}
