import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { ApprovalListItem, ApprovalListParams } from '@/models/systemSettings/approvalProcess'
import { approvalListApi } from '@/services/systemSettings/approvalProcess'
import { message } from 'ant-design-vue'
import { Dayjs } from 'dayjs'
import { omit } from 'lodash-es'
import { ref } from 'vue'

interface SearchForm extends Utils.NoPager<ApprovalListParams> {
  dates?: [Dayjs, Dayjs]
}

export const columns: Utils.ColumnField<ApprovalListItem>[] = [
  { title: '类型', dataIndex: 'target_type' },
  { title: '名称', dataIndex: 'target' },
  { title: '集群', dataIndex: 'target' },
  { title: '目标主机', dataIndex: 'target' },
  { title: '提交人', dataIndex: 'submitor' },
  { title: '提交时间', dataIndex: 'target' },
  { title: '状态', dataIndex: 'state' },
  { title: '操作', dataIndex: 'id' }
]
/** 审批状态类型 */
export const approvalTypeList = [
  { label: '全部', value: '' },
  { label: '审核中', value: 1, color: 'blue' },
  { label: '审核失败', value: 2, color: 'red' },
  { label: '审核通过', value: 3, color: 'cyan' },
  { label: '已发布', value: 4, color: 'yellow' }
]
const datePartten = 'YYYY-MM-DD HH:mm:ss'
export const initialValues: SearchForm = {
  state: '',
  start_date: '',
  end_date: '',
  search: '',
  target_type: 'operation',
  only_participated: 1,
  dates: undefined
}

/** 获取当前用户的登录历史 */
export function useSearchCurrentLoginHistory() {
  const searchModel = ref<SearchForm>({ ...initialValues })
  const dataSource = ref<ApprovalListItem[]>([])

  const { pageVo, setPageFromData } = usePagination()
  const { loading, run } = useRequest(approvalListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  function handleSearch(vo?: Utils.SearchVO) {
    const values = searchModel.value
    values.start_date = values.dates?.[0].format(datePartten) || ''
    values.end_date = values.dates?.[1].format(datePartten) || ''
    try {
      const params = {
        ...omit(values, ['dates']),
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params)
    } catch (e) {}
  }

  return { searchModel, loading, dataSource, pageVo, handleSearch }
}

/**
 * 从响应体字符串中获取主机
 * @param bodyString
 * @returns
 */
export const getDeviceOfBody = (bodyString: string | null) => {
  if (!bodyString) {
    return ''
  }
  try {
    const obj: Utils.Dict = JSON.parse(bodyString)
    let devices: string[] = []
    Object.values(obj).some(value => {
      if (Array.isArray(value)) {
        devices = value
        return true
      }
      return false
    })
    return devices.join('，')
  } catch (e) {
    return '解析错误: 非法的json字符串'
  }
}
