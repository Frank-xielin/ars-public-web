import useRequest from '@/common/useRequest'
import {
  GetApprovalTempRes,
  UpdateApprovalTempParams
} from '@/models/systemSettings/approvalProcess/checkApprovalTemp'
import { CreateApprovalTempParams } from '@/models/systemSettings/approvalProcess/createApprovalTemp'
import {
  getApprovalTempApi,
  updateApprovalTempApi
} from '@/services/systemSettings/approvalProcess/checkApprovalTemp'
import { requestHandler } from '@/utils/formTools'
import { Form, message } from 'ant-design-vue'
import { onMounted, Ref, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { requireInput, requireSelect } from '../clusterInformation/addEditCluster'
import { approvalUserValidator, initialTempValues } from './createApprovalTemp'

const rulesObj = (
  formModel: Ref<CreateApprovalTempParams>
): Utils.RulesObject<CreateApprovalTempParams> => ({
  title: [requireInput('名称')],
  approver1_id: [requireSelect('审核人1')],
  approver2_id: [{ validator: (_, val) => approvalUserValidator(val, formModel, 1) }],
  approver3_id: [{ validator: (_, val) => approvalUserValidator(val, formModel, 2) }]
})

/**
 * 获取单个审批流模板的信息
 * @param manaul 是否需要取消自动触发请求
 */
export function useGetApprovalTempInfo(manaul?: boolean) {
  const route = useRoute()
  const router = useRouter()
  const isEdit = ref(false)
  const tempId = ref(0)
  const formModel = ref<UpdateApprovalTempParams>({ ...initialTempValues })
  const rules = ref<Utils.RulesObject<CreateApprovalTempParams>>({})
  const fullTempInfo = ref<GetApprovalTempRes | null>(null)
  const form = Form.useForm(formModel, rules)
  const { submitChange } = useUpdateApprovalTemp(form, formModel, tempId, () => {
    if (route.query.type === 'edit') {
      router.push('/SystemSettings/ApprovalProcess')
    } else {
      isEdit.value = false
      getApprovalTempInfo()
    }
  })

  async function getApprovalTempInfo(id?: number) {
    try {
      const reply = await getApprovalTempApi(id ?? tempId.value)
      const { code, data, msg } = reply
      if (code === 0) {
        if (data) {
          fullTempInfo.value = data
          formModel.value = {
            enabled: data.enabled,
            notifiers: data.notifiers.map(item => item.id),
            notify_channels: data.notify_channels.map(item => item.id),
            title: data.title,
            approver1_id: data.approver1_id || undefined,
            approver2_id: data.approver2_id || undefined,
            approver3_id: data.approver3_id || undefined,
            tag: data.tag
          }
        }
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  watch(isEdit, edit => {
    rules.value = edit ? rulesObj(formModel) : ({} as any)
  })

  onMounted(() => {
    if (manaul) {
      return
    }
    const { id, type } = route.query
    if (id && !isNaN(+id)) {
      tempId.value = +id
      isEdit.value = type === 'edit'
      getApprovalTempInfo()
    } else {
      message.warn('审批流id无效！')
      router.push('/SystemSettings/ApprovalProcess')
    }
  })

  return { formModel, fullTempInfo, isEdit, form, getApprovalTempInfo, submitChange }
}

export function useUpdateApprovalTemp(
  form: ReturnType<typeof Form.useForm>,
  formModel: Ref<UpdateApprovalTempParams>,
  id: Ref<number>,
  successFn: () => void
) {
  const { run: updateFetch } = useRequest(updateApprovalTempApi, {
    onSuccess: reply => {
      if (reply.code === 0) {
        successFn()
      }
      requestHandler('修改审批流信息成功')(reply)
    }
  })

  async function submitChange() {
    try {
      await form.validate()
      updateFetch(id.value, formModel.value)
    } catch (e) {}
  }

  return { submitChange }
}
