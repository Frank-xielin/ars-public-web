import { OverviewListAllParams, OverviewListItem } from '@/models/workbench/clusterOverview'
import { overviewListAllApi } from '@/services/workbench/clusterOverview'
import { message } from 'ant-design-vue'
import { ref } from 'vue'

export enum ErrorDesc {
  EMPTY = '无集群信息，请联系管理员',
  ERROR = '集群数据暂时无法访问，请联系管理员解决'
}

type MinerCountType = 'true' | 'false' | 'isFetching'

export function useGetAllClustersInfo() {
  const searchModel = ref<OverviewListAllParams>({ search: '' })
  const dataSource = ref<OverviewListItem[]>([])
  const isEmpty = ref<MinerCountType>('isFetching')
  const errorDescription = ref<ErrorDesc>(ErrorDesc.EMPTY)

  async function handleSearch() {
    isEmpty.value = 'isFetching'
    try {
      const reply = await overviewListAllApi(searchModel.value)
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data || []
        if (!dataSource.value.length) {
          errorDescription.value = ErrorDesc.EMPTY
          isEmpty.value = 'true'
        } else {
          isEmpty.value = 'false'
        }
      } else {
        errorDescription.value = ErrorDesc.ERROR
        isEmpty.value = 'true'
        message.error(msg)
      }
    } catch (e) {
      errorDescription.value = ErrorDesc.ERROR
      isEmpty.value = 'true'
    }
  }

  return { dataSource, isEmpty, errorDescription, searchModel, handleSearch }
}
