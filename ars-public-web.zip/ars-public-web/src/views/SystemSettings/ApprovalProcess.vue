<script lang="ts" setup>
import {
  columns,
  useDeleteApprovalTemp,
  useGetApprovalTempList
} from '@/composables/systemSettings/approvalProcess'
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import LinkOperationsModal from './ApprovalProcess/LinkOperationsModal.vue'

const linkOperationsShow = ref(false)
const approvalId = ref(0)

const router = useRouter()
const { dataSource, loading, approvalTempsFetch } = useGetApprovalTempList()
const { deleteTargetTemp } = useDeleteApprovalTemp(() => handleSearch())

function checkTargetTemp(id: number, type: 'check' | 'edit') {
  router.push({
    path: '/SystemSettings/ApprovalProcess/CheckApprovalTemp',
    query: { id, type }
  })
}
function linkOperationsById(id: number) {
  approvalId.value = id
  linkOperationsShow.value = true
}

function handleSearch() {
  approvalTempsFetch().catch()
}

handleSearch()
</script>

<template>
  <div class="approval-process page">
    <a-button
      class="add-btn"
      :disabled="!$auth(28, 'menu')"
      type="primary"
      shape="round"
      @click="$router.push('/SystemSettings/ApprovalProcess/CreateApprovalTemp')"
    >
      新建
    </a-button>

    <a-table
      class="table-box"
      v-bind="$tableConfigs(dataSource, loading)"
      row-key="id"
      :scroll="$scroller('calc(100vh - 350px)')"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ column: col, text, record }">
        <div v-if="col.title === '操作'">
          <a-button
            type="link"
            :disabled="!$auth(29, 'menu')"
            class="table-btn"
            @click="checkTargetTemp(text, 'check')"
          >
            查看
          </a-button>
          <a-button
            type="link"
            :disabled="!$auth(77)"
            class="table-btn"
            @click="checkTargetTemp(text, 'edit')"
          >
            编辑
          </a-button>
          <template v-if="record.tag !== 'task'">
            <a-button
              type="link"
              :disabled="!$auth(78)"
              class="table-btn"
              @click="deleteTargetTemp(text)"
            >
              删除
            </a-button>
            <a-button
              type="link"
              :disabled="!$auth(76)"
              class="table-btn"
              @click="linkOperationsById(text)"
            >
              关联操作
            </a-button>
          </template>
        </div>
        <custom-tooltip v-else>
          <span v-if="col.title.includes('审核人')">{{ text?.user_name }}</span>
          <span v-else-if="col.title === '启用'">{{ text ? '是' : '否' }}</span>
          <span v-else>{{ text }}</span>
        </custom-tooltip>
      </template>
    </a-table>

    <link-operations-modal
      v-model:visible="linkOperationsShow"
      :approval-id="approvalId"
      @search="handleSearch"
    />
  </div>
</template>

<style lang="less" scoped>
.add-btn {
  position: absolute;
  right: 50px;
}
.table-box {
  margin-top: 55px;
}
</style>
