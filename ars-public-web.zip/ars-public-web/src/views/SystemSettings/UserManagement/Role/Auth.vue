<script lang="ts" setup>
import { useChangeRolesAuthInfo } from '@/composables/systemSettings/userManagement/auth'
import { useRoleAllList } from '@/composables/systemSettings/userManagement/role'
import router from '@/router'
import { useWindowSize } from '@vueuse/core'
import { message } from 'ant-design-vue'
import { computed, ref } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const roleInfo = ref({ id: 0, name: '' })

const { height } = useWindowSize()
const {
  checkedKeys,
  expandedKeys,
  menuFuncList,
  initCheckedData,
  changeAuth,
  selectAllChildren,
  checkHandler
} = useChangeRolesAuthInfo(() => router.push('/SystemSettings/UserManagement/Role'))
const { dataSource: roleList, handleSearch: searchAllRoles } = useRoleAllList()

const isEdit = computed(() => route.query.type !== 'check' && roleInfo.value.id > 3)

function initRoleAuth() {
  const id = route.query.id
  if (id && !isNaN(+id)) {
    roleInfo.value.id = +id
    searchAllRoles().then(() => {
      roleInfo.value.name = roleList.value.find(item => item.id === roleInfo.value.id)?.name || ''
    })
    initCheckedData(roleInfo.value.id)
  } else {
    message.error('没有检测到正确的角色')
    router.push('/SystemSettings/UserManagement/Role')
  }
}
initRoleAuth()
</script>

<template>
  <div class="permissions page">
    <h2 class="role-title">{{ roleInfo.name }}</h2>

    <a-button v-if="isEdit" class="submit-btn" type="primary" @click="changeAuth(roleInfo.id)">
      保存
    </a-button>
    <div class="tree-content">
      <a-tree
        checkable
        check-strictly
        :disabled="!isEdit"
        :height="height - 250"
        :tree-data="menuFuncList"
        v-model:expanded-keys="expandedKeys"
        v-model:checked-keys="checkedKeys"
        @select="(_, e) => selectAllChildren(e)"
        @check="(_, e) => checkHandler(e)"
      />
    </div>
  </div>
</template>

<style scoped lang="less">
.role-title {
  font-size: 20px;
}
.submit-btn {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  width: 100px;
}
.tree-content {
  margin-top: 42px;
}
</style>
