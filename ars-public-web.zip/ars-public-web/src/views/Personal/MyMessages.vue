<script lang="ts" setup>
import { columns, useMessageList, useUpdateMsgReadState } from '@/composables/personal/myMessages'
import { MessageListItem } from '@/models/personal/myMessages'
import { ref } from 'vue'

const messageVisible = ref(false)
const messageRecord = ref<MessageListItem | null>(null)

const { loading, searchModel, dataSource, pageVo, handleSearch } = useMessageList()
const { readTargetMessages } = useUpdateMsgReadState(handleSearch)

/** 标记所有数据为已读 */
function readAllMsg() {
  const ids = dataSource.value.map(item => item.id)
  readTargetMessages(ids)
}
/** 查看指定消息的具体信息 */
async function checkMessageDetails(record: MessageListItem) {
  await readTargetMessages([record.id])
  messageRecord.value = record
  messageVisible.value = true
}

handleSearch()
</script>

<template>
  <div class="my-messages page">
    <a-form layout="inline">
      <a-form-item>
        <a-button type="primary" shape="round" :disabled="!dataSource.length" @click="readAllMsg()">
          全部标记为已读
        </a-button>
      </a-form-item>

      <a-form-item class="search-form-input-item" style="right: 210px">
        <a-range-picker
          separator="至"
          format="YYYY-MM-DD HH:mm:ss"
          v-model:value="searchModel.dates"
          @change="handleSearch()"
        />
      </a-form-item>
      <a-form-item class="search-form-input-item" style="right: 0">
        <custom-search-input
          placeholder="输入关键字进行搜索"
          v-model:value="searchModel.search"
          @search-func="handleSearch()"
        />
      </a-form-item>
    </a-form>

    <a-table
      v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
      class="table-box"
      :columns="$columnsSetter(columns)"
      :scroll="$scroller('calc(100vh - 330px)')"
    >
      <template #bodyCell="{ column: col, text, record }">
        <a
          v-if="col.title === '操作'"
          class="table-btn"
          :class="{ 'not-read': !record.has_been_read }"
          @click="checkMessageDetails(record)"
        >
          查看
        </a>
        <custom-tooltip v-else>
          <span :class="{ 'not-read': !record.has_been_read }">{{ text }}</span>
        </custom-tooltip>
      </template>
    </a-table>
    <a-modal
      v-model:visible="messageVisible"
      title="消息详情"
      @cancel="handleSearch(pageVo)"
      :footer="null"
    >
      <div class="modalContent">
        <p style="padding: 10px 0 10px 10px">{{ messageRecord?.content }}</p>
      </div>
    </a-modal>
  </div>
</template>

<style scoped lang="less">
.search-form-input-item {
  position: absolute;
}
.not-read {
  font-weight: bold;
}
.modalContent {
  width: inherit;
  height: 200px;
}
</style>
