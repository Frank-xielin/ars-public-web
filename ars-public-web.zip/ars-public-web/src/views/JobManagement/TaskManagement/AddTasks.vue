<script lang="ts" setup>
import { useCreateTasks } from '@/composables/jobManagement/taskManagement/addTasks'
import { useSubmitTask, useViewTask } from '@/composables/jobManagement/taskManagement/allTaskApi'
import { useClusterAllList } from '@/composables/systemSettings/clusterInformation'
import { useUserManager } from '@/composables/systemSettings/userManagement/user/userManageTab'
import { softwareList } from '@/composables/workbench/hostManagement/index'
import { ScriptListItem } from '@/models/jobManagement/publishScript'
import { DeviceListItem } from '@/models/workbench/hostManagement'
import { message } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { computed, ref, toRaw } from 'vue'
import { useRouter } from 'vue-router'
import ChooseDeviceModal from '../CommandExecution/ChooseDeviceModal.vue'
import SelectScriptToast from './TaskComponent/SelectScriptToast.vue'
import SubmitApprovalToast from './TaskComponent/SubmitApprovalToast.vue'

defineEmits<{ (event: 'submit'): void }>()

const router = useRouter()
const { taskId, approvalId } = useViewTask()
const { submitTask } = useSubmitTask(() => {
  submitVisible.value = false
  router.push('/JobManagement/taskManagement')
})
const { formModel, form, submitForm } = useCreateTasks(id => {
  taskId.value = id
})

const { dataSource: userList, handleSearch: searchUsers } = useUserManager()

// 选择集群
const { dataSource: clusters, searchAllClusters } = useClusterAllList()
const clusterList = computed(() =>
  clusters.value.map(cluster => {
    return { ...cluster, label: `${cluster.client_name}${cluster.miner}` }
  })
)
searchAllClusters()
searchUsers({ page: 1, page_size: 10000 })

// 没选集群的话提示选择目标集群
function chooseDevice() {
  if (!formModel.value.miner) {
    message.warn('请先选择目标集群')
    return
  }
  deviceShow.value = true
}

// 再选择主机
const deviceShow = ref(false)
const selectedCluster = ref<DeviceListItem[]>([])
function handleSelectDevice(rows: DeviceListItem[]) {
  selectedCluster.value = cloneDeep(rows)
  formModel.value.device_sn_list = selectedCluster.value.map(row => ({
    device_sn: row.device_sn,
    software_type: row.software_type
  }))
}

// 保存提交
const onSubmit = (submit_approve: boolean, auto_run = false) => {
  // 保存&提交审核的校验字段移动到addtasks.ts新建任务里了，
  // formModel.value.auto_submit = submit_approve // 提交审核的核心字段
  // formModel.value.timeout = +formModel.value.timeout
  console.log('submit!', toRaw(formModel.value))
  submitForm(submit_approve).then(reply => {
    if (reply?.code === 0) {
      submit_approve
        ? submitTask(taskId.value, auto_run)
        : router.push('/JobManagement/taskManagement')
    }
  })
}

// 选择脚本 ref="" vue里绑定dom节点唯一方法
const taskSelScriptShow = ref(false)
const selectTaskScp = ref<ScriptListItem[]>([])
function handleSelectTaskScp(rows: ScriptListItem[]) {
  selectTaskScp.value = cloneDeep(rows)
  formModel.value.script_id = selectTaskScp.value[0].id
  formModel.value.script_content = selectTaskScp.value[0].content
}

// 提交审核弹窗
const submitVisible = ref<boolean>(false)
</script>

<template>
  <div class="addTask page">
    <h2 class="page-title">添加任务</h2>
    <div class="operation-top">
      <a-button type="primary" @click="onSubmit(false)">保存</a-button>
      <a-button type="primary" @click="submitVisible = true" :disabled="!$auth(42)">
        保存&提交审批
      </a-button>
      <a-button @click="$router.push('/JobManagement/TaskManagement')">取消</a-button>
    </div>
    <a-form class="addTask-form" :label-col="{ span: 3 }">
      <a-form-item label="任务名称" v-bind="form.validateInfos.name">
        <a-input v-model:value="formModel.name" />
      </a-form-item>
      <a-form-item label="目标集群" v-bind="form.validateInfos.miner">
        <custom-select
          style="width: 49%; text-align: center"
          :data="clusterList"
          value-field="miner"
          v-model:value="formModel.miner"
        />
      </a-form-item>
      <a-form-item label="目标主机" class="targetDevice" v-bind="form.validateInfos.device_sn_list">
        <div class="targetDevice__deviceList">
          <span v-for="(item, index) in formModel.device_sn_list" :key="index">
            {{ item.device_sn }}({{
              softwareList.find(type => item.software_type === type.value)?.label
            }})
            <span v-if="index < formModel.device_sn_list.length - 1">,</span>
          </span>
        </div>
        <span class="targetDevice__number">
          数量：{{ formModel.device_sn_list ? formModel.device_sn_list.length : 0 }}
        </span>
        <a-button @click="chooseDevice">+选择主机</a-button>
      </a-form-item>
      <a-form-item label="选择脚本" v-bind="form.validateInfos.script_id">
        <a-input v-show="false" :value="formModel.script_id" />
        <div class="selectScp">
          <a-input class="script-name-input" disabled :value="selectTaskScp[0]?.script_name" />
          <a-button @click="taskSelScriptShow = true">选择</a-button>
        </div>
      </a-form-item>
      <a-form-item label="脚本内容" v-bind="form.validateInfos.script_content">
        <a-textarea style="height: 200px" readonly :value="formModel.script_content" />
      </a-form-item>
      <a-form-item label="脚本参数">
        <a-input
          placeholder="脚本执行时传入的参数，如/test.sh"
          v-model:value="formModel.script_params"
        />
      </a-form-item>
      <a-form-item class="timeOut" label="超时时长" v-bind="form.validateInfos.timeout">
        <a-input style="width: 55%; margin-right: 8px" v-model:value="formModel.timeout" />
        <span class="timeOut__s">S</span>
      </a-form-item>
      <a-form-item label="执行账号" v-bind="form.validateInfos.exec_user">
        <a-input style="width: 55%" :data="userList" v-model:value="formModel.exec_user" disabled />
      </a-form-item>
      <a-form-item label="备注" v-bind="form.validateInfos.note">
        <a-textarea placeholder="请输入任务描述或脚本说明" v-model:value="formModel.note" />
      </a-form-item>
    </a-form>
  </div>
  <choose-device-modal
    :cluster-id="formModel.miner"
    :selected-devices="selectedCluster"
    v-model:visible="deviceShow"
    select-type="checkbox"
    @select="handleSelectDevice"
  />
  <select-script-toast
    :script_id="formModel.script_id"
    :selectTaskScp="selectTaskScp"
    v-model:visible="taskSelScriptShow"
    @select="handleSelectTaskScp"
  />
  <submit-approval-toast
    v-model:visible="submitVisible"
    :approval-id="approvalId"
    @handleSelect="onSubmit(true, $event)"
  />
</template>

<style lang="less" scoped>
@import (reference) '@/assets/styles/index.less';

.targetDevice {
  &__deviceList {
    border: 1px solid #cbcbcb;
    width: 300px;
    height: 100px;
    display: flex;
    flex-direction: column;
    padding: 4px;
    overflow: hidden auto;
    margin-right: 8px;
    text-align: center;
    span {
      margin-bottom: 4px;
    }
  }
  &__number {
    margin-right: 8px !important;
  }
}
.addTask-form {
  width: 700px;
  margin: auto;
}
.page-title {
  font-size: 20px;
  padding: 0 20px 20px;
  border-bottom: @tableBorder;
}

.operation-top {
  display: flex;
  justify-content: center;
  margin: 45px 0 44px;
  > button {
    width: 150px;
    margin: 0 10px;
  }
}
:deep(.ant-form-item-control-input-content) {
  display: flex;
  align-items: flex-end;
}
.selectScp {
  display: flex !important;
  .script-name-input {
    margin-right: 8px;
  }
}
.timeOut {
  // padding-top: 20px;
  // display: flex;
  // position: absolute;
  &__s {
    position: relative;
    right: 32px;
    top: -2px;
  }
}
textarea::placeholder,
input::placeholder {
  color: #bcbcd0 !important;
}
</style>
