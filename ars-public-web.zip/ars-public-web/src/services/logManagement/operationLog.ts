import {
  ClusterOperationLogsParams,
  ClusterOperationLogsRes,
  SystemOperationLogsParams,
  SystemOperationLogsRes
} from '@/models/logManagement/operationLog'
import { request } from '@/utils/httpConfig'

/**
 * 操作日志（系统操作）
 * @param data
 * @returns
 */
export function systemOperationLogsApi(data: SystemOperationLogsParams) {
  return request<SystemOperationLogsRes>({
    url: 'v5/public/log/operation/get/list',
    method: 'GET',
    data
  })
}

/**
 * 操作日志（集群操作）
 * @param data
 * @returns
 */
export function clusterOperationLogsApi(data: ClusterOperationLogsParams) {
  return request<ClusterOperationLogsRes>({
    url: 'v5/public/log/cluster/get/list',
    method: 'GET',
    data
  })
}
