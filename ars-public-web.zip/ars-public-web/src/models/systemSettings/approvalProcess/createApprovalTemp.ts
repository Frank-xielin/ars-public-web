import { ApprovalTempListItem } from './'

export interface CreateApprovalTempParams {
  title: string
  notifiers: number[]
  approver1_id?: number
  approver2_id?: number
  approver3_id?: number
  enabled: boolean
  notify_channels: number[]
  tag: string
}

export type CreateApprovalTempRes = ApprovalTempListItem

export interface NotifyChannelListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string | null
  name: string
}

export type NotifyChannelListRes = NotifyChannelListItem[]
