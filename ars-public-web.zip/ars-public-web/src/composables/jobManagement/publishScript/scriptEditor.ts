import useRequest from '@/common/useRequest'
import {
  requireInput,
  requireSelect
} from '@/composables/systemSettings/clusterInformation/addEditCluster'
import { CreateScriptParams } from '@/models/jobManagement/publishScript'
import router from '@/router'
import { createScriptApi, updateScriptApi } from '@/services/jobManagement/publishScript'
import { requestHandler } from '@/utils/formTools'
import { Form, message } from 'ant-design-vue'
import yaml from 'js-yaml'
import { ref } from 'vue'
import { useRoute } from 'vue-router'

const initialValues: CreateScriptParams = {
  content: '',
  enabled: false,
  name: '',
  note: '',
  type_id: undefined,
  version: ''
}
const rulesObj: Utils.RulesObject<CreateScriptParams> = {
  type_id: [requireSelect('脚本类型')],
  name: [requireSelect('脚本')],
  version: [requireInput('版本号')],
  content: [requireInput('脚本内容')],
  note: [requireInput('脚本描述')]
}

/**
 * 编辑、新建脚本
 * @param successFn
 * @returns
 */
export function useEditScriptInfo() {
  const route = useRoute()
  const formModel = ref<CreateScriptParams>({ ...initialValues })
  const rules = ref(rulesObj)
  const form = Form.useForm(formModel, rules)

  const { run: createRun } = useRequest(createScriptApi, {
    onSuccess: reply => {
      if (reply.code === 0) {
        router.push('/JobManagement/PublishScript')
      }
      requestHandler('新建脚本成功')(reply)
    }
  })
  const { run: updateRun } = useRequest(updateScriptApi, {
    onSuccess: reply => {
      if (reply.code === 0 && route.query.type === 'edit') {
        router.push('/JobManagement/PublishScript')
      }
      requestHandler('编辑脚本成功')(reply)
    }
  })

  async function submitForm(id?: number) {
    try {
      await form.validate()
      const { type } = route.query

      if ((type === 'edit' || type === 'check') && id) {
        updateRun(id, formModel.value)
      } else {
        createRun(formModel.value)
      }
    } catch (e) {}
  }

  function selectLocalFile(e: Event) {
    const target = e.target as HTMLInputElement
    const file = target.files?.[0]
    if (!file || !fileInfoValidator(file)) {
      return
    }

    const reader = new FileReader()
    reader.onload = ev => {
      const res = ev.target?.result
      if (!res || res instanceof ArrayBuffer) {
        message.warn('无法解析文件内容！')
      } else if (yamlContentValidator(res)) {
        formModel.value.name = file.name
        formModel.value.content = res
      }
    }
    reader.readAsText(file, 'utf8')
  }

  return { formModel, form, selectLocalFile, submitForm }
}

/**
 * 检查脚本文件是否符合要求
 * @param file
 * @returns
 */
const fileInfoValidator = (file: File) => {
  if (!file.name.includes('.yaml')) {
    message.warn('清选择yaml文件！')
    return false
  } else if (file.size > 1024 * 1024 * 50) {
    message.warn('脚本文件过大！')
    return false
  }

  return true
}

/**
 * 检查脚本内容是否正确
 * @param content
 * @returns
 */
const yamlContentValidator = (content: string) => {
  try {
    const doc = yaml.load(content)
    yaml.dump(doc, { skipInvalid: false })
    return true
  } catch (e) {
    message.warn('脚本内容解析错误，请检查语法是否正确！')
    return false
  }
}
