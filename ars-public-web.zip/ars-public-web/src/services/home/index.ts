import { AssetsInfoRes } from '@/models/home'
import { request } from '@/utils/httpConfig'

/** 获取首页 - 总集群 */
export function clusterCountApi() {
  return request<number>({
    url: 'v5/public/home/get/miner/info',
    method: 'get',
    loading: true
  })
}

/** 获取首页 - 总设备 */
export function deviceCountApi() {
  return request<number>({
    url: 'v5/public/home/get/device/info',
    method: 'get',
    loading: true
  })
}

/** 获取首页 - 总资产和总算力 */
export function assetsInfoApi() {
  return request<AssetsInfoRes>({
    url: 'v5/public/home/get/fil/info',
    method: 'get',
    loading: true
  })
}
