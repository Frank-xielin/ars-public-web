import { App } from 'vue'

import { checkFuncAuth } from '../auth'
import { dateFormatter } from '../dateFormat'
import { columnConfig, columnsSetter, scroller, tableConfigs, tableSelection } from '../formTools'

/**
 * 注册 Vue 全局功能函数
 * @param app vueApp 实例
 */
export function functionRegistration(app: App<Element>) {
  app.config.globalProperties.$tableConfigs = tableConfigs
  app.config.globalProperties.$tableSelection = tableSelection
  app.config.globalProperties.$columnConfig = columnConfig
  app.config.globalProperties.$auth = checkFuncAuth
  app.config.globalProperties.$dateFormatter = dateFormatter
  app.config.globalProperties.$scroller = scroller
  app.config.globalProperties.$columnsSetter = columnsSetter
}
