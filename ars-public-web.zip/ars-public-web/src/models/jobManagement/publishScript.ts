export interface CreateScriptParams {
  type_id: number | undefined
  name: string
  content: string
  note: string
  enabled: boolean
  version: string
}

export type UpdateScriptParams = CreateScriptParams

export interface ScriptListParams extends Utils.SearchVO {
  type_id: number | undefined
  name: string
  enabled: number | ''
}

export interface ScriptListItem {
  id: number
  created_at: string
  updated_at: string
  creator: string
  enabled: boolean
  updater: string
  script_name: string
  script_type: string
  script_type_id: number
  version: string
  content: string
  note: string
}

export interface ScriptListRes extends Utils.PageVO {
  list: ScriptListItem[]
}

export type GetScriptInfoRes = ScriptListItem

export interface ScriptTypeListItem {
  id: number
  name: string
  created_at: string
  updated_at: string
}

export type ScriptTypeListRes = ScriptTypeListItem[]
