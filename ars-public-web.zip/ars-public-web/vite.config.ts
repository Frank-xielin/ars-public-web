/// <reference types="vitest" />

import vue from '@vitejs/plugin-vue'
import vueJsx from '@vitejs/plugin-vue-jsx'
import path from 'path'
import { AntDesignVueResolver } from 'unplugin-vue-components/resolvers'
import Components from 'unplugin-vue-components/vite'
import { defineConfig } from 'vite'
import viteCompression from 'vite-plugin-compression'
import modifyVars from './configs/modifyVars.json'

const url = 'https://devops.arsyun.com:21000'
// const url = 'http://192.168.12.176:40000/'
const isProduction = process.env.NODE_ENV === 'production'

// https://vitejs.dev/config/
export default defineConfig({
  base: isProduction ? './' : '',
  css: {
    preprocessorOptions: {
      less: {
        modifyVars,
        javascriptEnabled: true
      }
    }
  },
  server: {
    open: true,
    proxy: {
      '/api': {
        target: url,
        changeOrigin: true
      },
      '/sky/api': {
        target: 'http://192.168.12.106:40000',
        rewrite: str => str.replace('/sky', ''),
        changeOrigin: true
      },
      '/garden/api': {
        target: 'http://192.168.12.176:40000',
        rewrite: str => str.replace('/garden', ''),
        changeOrigin: true
      }
    }
  },
  esbuild: {
    jsxFactory: 'h',
    jsxFragment: 'Fragment'
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  },
  build: {
    outDir: 'build',
    brotliSize: false
  },
  plugins: [
    vue(),
    vueJsx(),
    Components({
      dirs: ['src/components'],
      resolvers: [AntDesignVueResolver({ importStyle: false, resolveIcons: true })]
    }),
    viteCompression()
  ],
  test: {
    globals: true,
    deps: {
      inline: ['ant-design-vue']
    }
  }
})
