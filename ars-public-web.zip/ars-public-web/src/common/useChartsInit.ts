import 'zrender/lib/svg/svg'

import { EChartsCoreOption, EChartsType, init } from 'echarts'
import { debounce } from 'lodash-es'
import { Ref, ref, watch } from 'vue'

import { useEventListener } from '@vueuse/core'

type RenderType = 'canvas' | 'svg'
type Theme = 'default' | 'dark' | 'light'

/**
 * 初始化一个 echarts 对象
 * @param options
 * @param renderer 渲染方式，默认为 svg，如果涉及数据较多较复杂，请改为 canvas
 * @param theme 图表主题
 */
const useChartsInit = (
  options: Ref<EChartsCoreOption>,
  renderer: RenderType = 'svg',
  theme: Theme = 'default'
) => {
  const chartsEl = ref<HTMLDivElement>()
  const charts = ref<EChartsType>()

  const initCharts = () => {
    if (!chartsEl.value) return
    if (!charts.value?.setOption) {
      charts.value = init(chartsEl.value, theme, { renderer })
    }
    charts.value.setOption(options.value)
  }

  watch(
    options,
    () => {
      initCharts()
    },
    { deep: true }
  )

  const resizeCharts = () => {
    initCharts()
    setTimeout(() => {
      charts.value?.resize()
    }, 200)
  }
  useEventListener('resize', debounce(resizeCharts, 200))

  return { charts, chartsEl }
}

export default useChartsInit
