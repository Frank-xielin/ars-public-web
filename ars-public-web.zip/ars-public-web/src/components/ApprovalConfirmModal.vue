<script lang="ts" setup>
import { useMainStore } from '@/store'
import { message } from 'ant-design-vue'
import { computed, ref, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  objects: string[]
  funcId: number
  operation: string
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'submit', reason: string): void
}>()

const store = useMainStore()
const reason = ref('')
const needApproval = computed(() => store.approvalFuncIds.includes(props.funcId))
function onSubmit() {
  if (needApproval.value && !reason.value) {
    message.warn('请填写原因')
    return
  }
  emit('submit', reason.value)
}

watch(
  () => props.visible,
  visible => {
    if (visible) {
      reason.value = ''
    }
  }
)
</script>

<template>
  <a-modal
    :title="needApproval ? '提示' : operation"
    :visible="visible"
    ok-text="是"
    cancel-text="否"
    @cancel="$emit('update:visible', false)"
    @ok="onSubmit"
  >
    <a-form v-if="needApproval" class="approval-form" :label-col="{ span: 3 }">
      <a-form-item label="操作">{{ operation }}</a-form-item>
      <a-form-item label="对象">{{ objects.join('、') }}</a-form-item>
      <a-form-item label="原因">
        <a-textarea placeholder="请输入操作原由" v-model:value="reason" />
      </a-form-item>
      <a-form-item>
        <span class="tips">该操作需要走审批流程，审批通过后方可执行，是否提交审批</span>
      </a-form-item>
    </a-form>
    <p v-else class="confirm-text">确定对选定的主机执行该操作？</p>
  </a-modal>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.approval-form {
  .tips {
    font-size: 14px;
    font-weight: bold;
    color: @textColor_first;
  }
}
.confirm-text {
  text-align: center;
  margin: 20px 0;
}
</style>
