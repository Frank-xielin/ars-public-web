import {
  CreateTemplateParams,
  TemplateInfoRes,
  TemplateListParams,
  TemplateListRes,
  TemplateTypeAllRes,
  UpdateTemplateParams
} from '@/models/jobManagement/commonTemplate'
import { request } from '@/utils/httpConfig'

/** 公共模板类型获取-所有 */
export function templateTypeAllApi() {
  return request<TemplateTypeAllRes>({
    url: 'v5/public/public_template_type/get/all',
    method: 'get'
  })
}

/**
 * 公共模板类型创建-单个
 * @param name 模板类型名称
 * @returns
 */
export function createTemplateTypeApi(name: string) {
  return request({
    url: 'v5/public/public_template_type/create/one',
    method: 'post',
    data: { name },
    loading: true
  })
}

/**
 * 公共模板类型更新-单个
 * @param id 目标模板类型的 id
 * @param name 新的模板名称
 * @returns
 */
export function updateTemplateTypeApi(id: number, name: string) {
  return request({
    url: `v5/public/public_template_type/update/id/${id}`,
    method: 'put',
    data: { name },
    loading: true
  })
}

/**
 * 公共模板类型删除-单个
 * @param id 目标模板类型的 id
 * @returns
 */
export function deleteTemplateTypeApi(id: number) {
  return request({
    url: `v5/public/public_template_type/delete/id/${id}`,
    method: 'delete',
    loading: true
  })
}

/**
 * 公共模板获取 - 分页
 * @param vo 分页信息
 * @returns
 */
export function templateListApi(data: TemplateListParams) {
  return request<TemplateListRes>({
    url: 'v5/public/public_template/get/list',
    method: 'get',
    data
  })
}

/**
 * 公共模板获取 - 单个
 * @param id 目标模板的 id
 * @returns
 */
export function templateInfoApi(id: number) {
  return request<TemplateInfoRes>({
    url: `v5/public/public_template/get/id/${id}`,
    method: 'get',
    loading: true
  })
}

/**
 * 公共模板创建 - 单个
 * @param data
 * @returns
 */
export function createTemplateApi(data: CreateTemplateParams) {
  return request({
    url: 'v5/public/public_template/create/one',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 公共模板修改 - 单个
 * @param id 目标模板的 id
 * @param data
 * @returns
 */
export function updateTemplateApi(id: number, data: UpdateTemplateParams) {
  return request({
    url: `v5/public/public_template/update/id/${id}`,
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 公共模板删除 - 单个
 * @param id 目标模板的 id
 * @returns
 */
export function deleteTemplateApi(id: number) {
  return request({
    url: `v5/public/public_template/delete/id/${id}`,
    method: 'delete',
    loading: true
  })
}

/**
 * 公共模板启用 - 单个
 * @param id 目标模板的 id
 * @param enable 启用/停止
 * @returns
 */
export function enableTemplateApi(id: number, enable: boolean) {
  return request({
    url: `v5/public/public_template/enable/id/${id}`,
    method: 'patch',
    data: { enable },
    loading: true
  })
}
