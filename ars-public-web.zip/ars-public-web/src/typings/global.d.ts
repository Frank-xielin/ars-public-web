// eslint-disable-next-line @typescript-eslint/no-unused-vars

declare module '@vue/runtime-core' {
  interface ComponentCustomProperties {
    $tableConfigs: typeof import('@/utils/formTools').tableConfigs
    $tableSelection: typeof import('@/utils/formTools').tableSelection
    $columnConfig: typeof import('@/utils/formTools').columnConfig
    $scroller: typeof import('@/utils/formTools').scroller
    $columnsSetter: typeof import('@/utils/formTools').columnsSetter
    $dateFormatter: typeof import('@/utils/dateFormat').dateFormatter
    $auth: typeof import('@/utils/auth').checkFuncAuth
  }

  interface GlobalComponents {
    IconFont: typeof import('@/components/Icons')['default']
    RouterView: typeof import('vue-router')['RouterView']
    RouterLink: typeof import('vue-router')['RouterLink']
    CustomSearchInput: typeof import('@/components/CustomSearchInput.vue')['default']
    CustomSelect: typeof import('@/components/CustomSelect.vue')['default']
    CustomTooltip: typeof import('@/components/CustomTooltip.vue')['default']
    FormRender: typeof import('@/components/FormRender.vue')['default']
    HeaderWrapper: typeof import('@/components/HeaderWrapper.vue')['default']
    IconButton: typeof import('@/components/IconButton.vue')['default']
    Layout: typeof import('@/components/Layout.vue')['default']
    Loading: typeof import('@/components/Loading.vue')['default']
    LoadingImage: typeof import('@/components/LoadingImage.vue')['default']
    SubMenu: typeof import('@/components/SubMenu.vue')['default']
  }
}

export {}
