<script lang="ts" setup>
import { useClusterAllList } from '@/composables/systemSettings/clusterInformation'
import {
  errorLevelList,
  errorTypeList,
  ModalType,
  processStateList
} from '@/composables/workbench/errorRecord'
import { useChangeBrokenRecord } from '@/composables/workbench/errorRecord/addOrEditRecord'
import { BrokenRecordListItem } from '@/models/workbench/errorRecord'
import dayjs from 'dayjs'
import { toRefs, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  modalType: ModalType
  recordDetail?: BrokenRecordListItem | null
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()
const { modalType } = toRefs(props)

const { formModel, form, submitForm } = useChangeBrokenRecord(modalType, () => {
  emit('update:visible', false)
  emit('search')
})
const { dataSource: clusterList, searchAllClusters } = useClusterAllList()

watch(
  () => props.visible,
  async val => {
    if (val) {
      const { modalType, recordDetail } = props
      await searchAllClusters()
      if (modalType === '编辑' && recordDetail) {
        formModel.value = {
          ...recordDetail.broken,
          record_time: dayjs(recordDetail.broken.record_time)
        }
      } else {
        formModel.value.miner_id = clusterList.value[0]?.miner
        formModel.value.fault_grade = errorLevelList[2].value
        formModel.value.fault_sort = errorTypeList[2].value
        formModel.value.processing_status = processStateList[2].value
      }
    } else {
      form.resetFields()
    }
  }
)
</script>

<template>
  <a-modal
    :visible="visible"
    :title="`${modalType}记录`"
    @ok="submitForm(recordDetail?.broken.id)"
    @cancel="$emit('update:visible', false)"
    width="757px"
  >
    <a-form class="edit-form" :label-col="{ span: 4 }" @submit="submitForm">
      <a-form-item label="日期" v-bind="form.validateInfos.errorDate">
        <a-date-picker
          style="width: 100%"
          v-model:value="formModel.record_time"
          format="YYYY-MM-DD HH:mm:ss"
          placeholder="选择故障发生日期"
          :allow-clear="false"
        />
      </a-form-item>
      <a-form-item label="集群" v-bind="form.validateInfos.miner">
        <custom-select
          :data="clusterList"
          value-field="miner"
          label-field="miner"
          v-model:value="formModel.miner_id"
        />
      </a-form-item>
      <a-form-item label="故障描述" v-bind="form.validateInfos.fault_description">
        <a-textarea v-model:value="formModel.fault_description" />
      </a-form-item>
      <a-form-item label="故障原因" v-bind="form.validateInfos.fault_reason">
        <a-textarea v-model:value="formModel.fault_reason" />
      </a-form-item>
      <a-form-item label="故障分类" v-bind="form.validateInfos.fault_sort">
        <custom-select
          :data="errorTypeList.filter(e => ![-1, -2].includes(e.value))"
          v-model:value="formModel.fault_sort"
        />
      </a-form-item>
      <a-form-item label="故障等级" v-bind="form.validateInfos.fault_grade">
        <custom-select
          :data="errorLevelList.filter(e => ![-1, -2].includes(e.value))"
          v-model:value="formModel.fault_grade"
        />
      </a-form-item>
      <a-form-item label="处理状态" v-bind="form.validateInfos.processing_status">
        <custom-select
          :data="processStateList.filter(e => ![-1, -2].includes(e.value))"
          v-model:value="formModel.processing_status"
        />
      </a-form-item>
    </a-form>
  </a-modal>
</template>

<style scoped lang="less">
.edit-form {
  width: 577px;
  margin: 0 auto;
}
</style>
