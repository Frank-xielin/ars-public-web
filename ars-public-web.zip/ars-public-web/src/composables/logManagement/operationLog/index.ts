import {
  ClusterOperationLogsItem,
  SystemOperationLogsItem
} from '@/models/logManagement/operationLog'

export const systemCols: Utils.ColumnField<SystemOperationLogsItem>[] = [
  { title: '时间', dataIndex: 'datetime' },
  { title: '模块', dataIndex: 'module' },
  { title: '操作', dataIndex: 'operation' },
  { title: '内容', dataIndex: 'content' },
  { title: '操作人', dataIndex: 'operator' }
]

export const clusterCols: Utils.ColumnField<ClusterOperationLogsItem>[] = [
  { title: '时间', dataIndex: 'datetime' },
  { title: '模块', dataIndex: 'module' },
  { title: '操作', dataIndex: 'operation' },
  { title: '操作主机', dataIndex: 'operation_device' },
  { title: '所在集群', dataIndex: 'cluster' },
  { title: '操作人', dataIndex: 'operator' }
]
