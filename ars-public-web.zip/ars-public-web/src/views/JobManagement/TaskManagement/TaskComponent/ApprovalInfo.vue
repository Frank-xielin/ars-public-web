<script lang="ts" setup>
import { ApprovalToastItem } from '@/models/home/approvalToast'

// 父组件传值
const props = defineProps<{
  submitInfo: any[] | undefined
  submitter: string
}>()
const columns: Utils.ColumnField<ApprovalToastItem>[] = [
  { title: '时间', dataIndex: 'updated_at' },
  { title: '内容', dataIndex: 'title' },
  { title: '提交人', dataIndex: 'approver' },
  { title: '审核人', dataIndex: 'approver' },
  { title: '审核状态', dataIndex: 'state' },
  { title: '评论', dataIndex: 'note' }
  // { title: '整体状态', dataIndex: 'comment' }
]
const appaovalStep = [
  {
    text: '审核中',
    id: 0
  },
  {
    text: '已通过',
    id: 1
  },
  {
    text: '已驳回',
    id: 2
  },
  {
    text: '已发布',
    id: 3
  }
]
</script>

<template>
  <div class="approvalInfo">
    <h3 class="big__title">审批信息</h3>
    <a-table
      class="approvalInfo__content"
      v-bind="$tableConfigs(submitInfo)"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ column, text }">
        <span v-if="column.title === '审核状态'">
          {{ appaovalStep.find(item => item.id === text)?.text }}
        </span>
        <span v-else-if="column.title === '审核人'">{{ text.user_name }}</span>
        <span v-else-if="column.title === '提交人'">{{ submitter }}</span>
      </template>
    </a-table>
  </div>
</template>

<style lang="less" scoped>
@import (reference) '@/assets/styles/index.less';
.approvalInfo {
  padding: 17px 36px 48px 36px !important;
  margin: 20px 0 20px 0;
  background-color: #fff;
  &__content {
    padding-top: 24px;
  }
}
.big__title {
  font-size: 14px;
  font-weight: bold;
  line-height: 19px;
  border-bottom: 1px solid #ebf1f5;
  padding-bottom: 12px;
}
* {
  color: @textColor_first !important;
  font-size: 14px;
}
</style>
