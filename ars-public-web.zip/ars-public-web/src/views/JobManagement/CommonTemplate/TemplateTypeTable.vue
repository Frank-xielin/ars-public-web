<script lang="ts" setup>
import {
  columns,
  useTemplateTypeAllList,
  useUpdateTemplateType
} from '@/composables/jobManagement/commonTemplate/templateTypeTable'
import { TemplateTypeItem } from '@/models/jobManagement/commonTemplate'
import { ref, unref, watch } from 'vue'

const props = defineProps<{ visible: boolean }>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'change'): void
}>()

const isChanged = ref(false)
const { dataSource, loading, run } = useTemplateTypeAllList()
const { formModel, submitEdit, deleteType, cancelEdit } = useUpdateTemplateType(() => {
  isChanged.value = true
  searchTypes()
})

function isAvailableRow(rowId: number) {
  const { id } = unref(formModel)
  return !id || id !== rowId
}
function selectToEdit(record: TemplateTypeItem) {
  formModel.value = {
    id: record.id,
    name: record.name
  }
}
function searchTypes() {
  run().catch()
}

watch(
  () => props.visible,
  visible => {
    if (visible) {
      searchTypes()
      isChanged.value = false
    } else {
      dataSource.value.length = 0
      if (isChanged.value) {
        emit('change')
      }
    }
  }
)
</script>

<template>
  <a-modal
    title="管理模板类型"
    :visible="visible"
    :width="650"
    :footer="null"
    @cancel="$emit('update:visible', false)"
  >
    <a-table
      v-bind="$tableConfigs(dataSource, loading)"
      :scroll="$scroller(400)"
      :columns="$columnsSetter(columns)"
      style="padding-bottom: 20px"
      row-key="id"
    >
      <template #bodyCell="{ column, record, text }">
        <template v-if="column.title === '操作'">
          <a-button type="link" class="table-btn" @click="selectToEdit(record)">编辑</a-button>
          <a-button
            type="link"
            class="table-btn"
            :disabled="!isAvailableRow(text)"
            @click="deleteType(text)"
          >
            删除
          </a-button>
        </template>
        <template v-else>
          <span v-if="formModel.id !== record.id">{{ text }}</span>
          <a-input v-else v-model:value="formModel.name">
            <template #suffix>
              <a @click="submitEdit">保存</a>
              <a style="margin-left: 10px" @click="cancelEdit()">取消</a>
            </template>
          </a-input>
        </template>
      </template>
    </a-table>
  </a-modal>
</template>

<style scoped lang="less"></style>
