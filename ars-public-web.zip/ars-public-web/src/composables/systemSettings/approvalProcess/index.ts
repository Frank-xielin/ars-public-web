import useRequest from '@/common/useRequest'
import { ApprovalTempListItem } from '@/models/systemSettings/approvalProcess'
import {
  approvalTempAllListApi,
  deleteApprovalTempApi
} from '@/services/systemSettings/approvalProcess'
import { message, Modal } from 'ant-design-vue'
import { InjectionKey, provide, readonly, Ref, ref } from 'vue'

export const columns: Utils.ColumnField<ApprovalTempListItem>[] = [
  { title: '名称', dataIndex: 'title' },
  { title: '审核人1', dataIndex: 'approver1' },
  { title: '审核人2', dataIndex: 'approver2' },
  { title: '审核人3', dataIndex: 'approver3' },
  { title: '启用', dataIndex: 'enabled' },
  { title: '操作', dataIndex: 'id', width: 170 }
]
export const BindedOperations: InjectionKey<Readonly<Ref<number[]>>> = Symbol('已关联的操作')

/** 获取所有的审批流模板 */
export function useGetApprovalTempList() {
  const dataSource = ref<ApprovalTempListItem[]>([])
  const bindedKeys = ref<number[]>([])

  provide(BindedOperations, readonly(bindedKeys))

  const { loading, run: approvalTempsFetch } = useRequest(approvalTempAllListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data || []
        filterUnavailableFuncs()
      } else {
        message.error(msg)
      }
    }
  })

  function filterUnavailableFuncs() {
    const keys: number[] = []
    dataSource.value.forEach(item => {
      keys.push(...item.func_apis.map(func => func.id))
    })
    bindedKeys.value = [...new Set(keys)]
  }

  return { dataSource, loading, bindedKeys, approvalTempsFetch }
}

/** 删除单条审批流模板 */
export function useDeleteApprovalTemp(successFn: () => void) {
  function deleteTargetTemp(id: number) {
    Modal.confirm({
      content: '是否删除该审批流模板',
      async onOk() {
        try {
          const reply = await deleteApprovalTempApi(id)
          if (reply.code === 0) {
            message.success('删除成功')
            successFn()
          } else {
            message.error(reply.msg)
          }
        } catch (e) {}
      }
    })
  }

  return { deleteTargetTemp }
}
