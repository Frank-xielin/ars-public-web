<script lang="ts" setup>
import { useTemplateList } from '@/composables/jobManagement/commonTemplate'
import { useTemplateTypeAllList } from '@/composables/jobManagement/commonTemplate/templateTypeTable'
import { TemplateListItem } from '@/models/jobManagement/commonTemplate'
import { message } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { computed, ref, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  selectedTemps: TemplateListItem[]
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'select', val: TemplateListItem[]): void
}>()

const columns: Utils.ColumnField<TemplateListItem>[] = [
  { title: '模板类型', dataIndex: 'template_type' },
  { title: '模板名称', dataIndex: 'template_name' },
  { title: '模板内容', dataIndex: 'content' },
  { title: '描述', dataIndex: 'note' }
]
const selectedRows = ref<TemplateListItem[]>([])
const { dataSource: typeList, run } = useTemplateTypeAllList()
const { dataSource, form, loading, pageVo, searchModel, handleSearch } = useTemplateList()
const typeSelection = computed(() => {
  return [{ id: 0, name: '全部' }, ...typeList.value]
})

function selectionHandler(_: any, rows: TemplateListItem[]) {
  selectedRows.value = rows
}
function onSubmit() {
  if (!selectedRows.value.length) {
    message.warn('至少选择一条数据！')
    return
  }
  emit('select', selectedRows.value)
  emit('update:visible', false)
}
function onSearch(vo?: Utils.SearchVO) {
  handleSearch(vo)
  run().catch()
}

watch(
  () => props.visible,
  visible => {
    if (visible) {
      searchModel.value.enabled = true
      selectedRows.value = cloneDeep(props.selectedTemps)
      onSearch()
    } else {
      form.resetFields()
      dataSource.value.length = 0
      selectedRows.value.length = 0
    }
  }
)
</script>

<template>
  <a-modal
    title="选择模板"
    :width="1000"
    :visible="visible"
    :footer="null"
    @cancel="$emit('update:visible', false)"
  >
    <a-form class="template-search-form" layout="inline">
      <a-form-item label="模板类型">
        <custom-select
          :data="typeSelection"
          style="width: 150px"
          value-field="id"
          label-field="name"
          v-model:value="searchModel.type_id"
          @change="onSearch()"
        />
      </a-form-item>
      <a-form-item class="search-input-item">
        <custom-search-input
          placeholder="模板名称"
          v-model:value="searchModel.content"
          @search-func="onSearch()"
        />
      </a-form-item>
    </a-form>

    <a-table
      v-bind="$tableConfigs(dataSource, loading, pageVo, onSearch)"
      :columns="$columnsSetter(columns)"
      row-key="id"
      :row-selection="
        $tableSelection({
          type: 'radio',
          selectedRowKeys: selectedRows.map(row => row.id),
          onChange: selectionHandler
        })
      "
    />
    <footer class="footer-operation">
      <a-button @click="$emit('update:visible', false)">取消</a-button>
      <a-button type="primary" @click="onSubmit">确认</a-button>
    </footer>
  </a-modal>
</template>

<style scoped lang="less">
.template-search-form {
  position: relative;
  margin-bottom: 20px;
  .search-input-item {
    position: absolute;
    right: 0;
  }
}
.footer-operation {
  display: flex;
  justify-content: flex-end;
  padding: 20px 0;
  button {
    margin-left: 20px;
  }
}
</style>
