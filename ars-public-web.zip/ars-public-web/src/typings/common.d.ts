/** 公共类型集 */
declare namespace Utils {
  type ColumnType<T> = import('ant-design-vue/lib/table').ColumnType<T>

  type Key = string | number
  type Nil = null | undefined

  /** 字典类型 */
  type Dict<T = any> = Record<string, T>
  type Table<T = unknown> = Dict<T | undefined>

  /** 分页器 */
  interface PageVO {
    page: number
    page_size: number
    total: number
  }

  type SearchVO = {
    page: number
    page_size: number
  }

  /** 响应体 */
  interface Result<T = null> {
    code: number // 0 为成功，否则为失败
    msg: string // 错误信息
    data: T | null
  }

  interface ColumnField<T = string> extends ColumnType<T extends object ? T : any> {
    title: string
    dataIndex: T extends string ? T : keyof T
  }

  type NoPager<T extends SearchVO> = Omit<T, keyof SearchVO>

  type RulesObject<T = string> = {
    [key in T extends string ? T : keyof T]?: import('ant-design-vue/lib/form/interface').Rule[]
  }

  type Prop<T> = T extends object
    ? import('vue').DeepReadonly<import('vue').Ref<T>>
    : Readonly<import('vue').Ref<T>>
}
