import { DeviceListOfRoomItem } from '@/models/workbench/publicCalculate'

export const columns: Utils.ColumnField<DeviceListOfRoomItem>[] = [
  { title: '集群SN', dataIndex: 'device_sn', width: 120 },
  { title: '软件角色', dataIndex: 'software_type', width: 100 },
  { title: 'nvme总数', dataIndex: 'disk_all_count', width: 100 },
  { title: 'nvme已挂载', dataIndex: 'disk_mount_count', width: 100 },
  { title: 'nvme已使用', dataIndex: 'disk_use_count', width: 100 },
  { title: '所在集群', dataIndex: 'miner', width: 100 },
  { title: '资产归属', dataIndex: 'miner_client_name', width: 100 },
  { title: '当前任务', dataIndex: 'task_count', width: 100 },
  { title: 'IP', dataIndex: 'ips', width: 100 },
  { title: '是否故障', dataIndex: 'machine_status', width: 100 },
  { title: '服务状态', dataIndex: 'ops_server_status', width: 100 },
  { title: 'lotus状态', dataIndex: 'lotus_server_status', width: 100 },
  { title: '操作', dataIndex: 'device_sn', width: 50 }
]
