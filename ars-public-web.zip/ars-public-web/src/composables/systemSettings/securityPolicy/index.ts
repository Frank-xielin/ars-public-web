import { UpdatePwTacticParams } from '@/models/systemSettings/securityPolicy'
import { getPwTacticApi, updatePwTacticApi } from '@/services/systemSettings/securityPolicy'
import { Form, message } from 'ant-design-vue'
import { ref } from 'vue'
import { requireInput, requireSelect } from '../clusterInformation/addEditCluster'

export const lockTimes = [
  { label: '1分钟', value: 1 },
  { label: '10分钟', value: 10 },
  { label: '1小时', value: 60 },
  { label: '1天', value: 1440 },
  { label: '1年', value: 52_5600 }
]
export const expiredList = [
  { label: '30天', value: 30 },
  { label: '90天', value: 90 },
  { label: '180天', value: 180 }
]
export const rootExpiredList = [
  { label: '30天', value: 30 },
  { label: '60天', value: 60 },
  { label: '90天', value: 90 }
]
export const complicacyList = [{ label: '必须包含字母、数字、特殊字符', value: 1 }]

interface UpdateTacticForm extends UpdatePwTacticParams {
  complicacy: number
}

const rulesObj: Utils.RulesObject<UpdateTacticForm> = {
  passwd_length: [requireSelect('密码长度')],
  passwd_expired: [requireSelect('密码有效期')],
  complicacy: [requireSelect('密码复杂性')],
  passwd_err_try_cnt: [requireInput('无效登录次数')],
  first_login_err_lock: [requireSelect('密码长度')],
  second_login_err_lock: [requireSelect('密码长度')],
  third_login_err_lock: [requireSelect('密码长度')],
  root_passwd_validity: [requireSelect('root密码有效期')]
}

export function usePwTacticManager() {
  const formModel = ref<UpdateTacticForm>({
    passwd_length: 0,
    passwd_expired: 0,
    complicacy: 1,
    passwd_err_try_cnt: 0,
    first_login_err_lock: 0,
    second_login_err_lock: 0,
    third_login_err_lock: 0,
    root_passwd_validity: 30
  })
  const rules = ref(rulesObj)
  const form = Form.useForm(formModel, rules)

  /** 获取密码策略 */
  async function getPwTactic() {
    try {
      const reply = await getPwTacticApi()
      const { code, data, msg } = reply
      if (code === 0) {
        data && (formModel.value = { ...formModel.value, ...data })
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  /** 修改密码策略 */
  async function updateTactic() {
    try {
      await form.validate()
      const reply = await updatePwTacticApi(formModel.value)
      if (reply.code === 0) {
        message.success('修改密码策略成功')
        getPwTactic()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { formModel, form, getPwTactic, updateTactic }
}
