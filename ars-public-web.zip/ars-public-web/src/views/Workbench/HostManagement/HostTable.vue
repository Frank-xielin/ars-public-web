<script lang="tsx" setup>
import { softwareList } from '@/composables/workbench/hostManagement'
import {
  columns,
  machineErrorList,
  useUpdateMachinesStatus
} from '@/composables/workbench/hostManagement/hostTable'
import { DeviceListItem } from '@/models/workbench/hostManagement'
import { pagerConfigs } from '@/utils/formTools'
import { ref, watch } from 'vue'
import HostDetailModal from './HostDetailModal.vue'

const props = defineProps<{
  dataSource: DeviceListItem[]
  loading: boolean
  pageVo: Utils.PageVO
  selectedRows: DeviceListItem[]
  statistics: { online: number; offline: number }
}>()
const emit = defineEmits<{
  (event: 'update:selectedRows', val: DeviceListItem[]): void
  (event: 'search', vo?: Utils.SearchVO): void
}>()

const selectMachine = ref<DeviceListItem | null>(null)
const hostDetailShow = ref<{ record?: DeviceListItem; visible: boolean }>({
  record: undefined,
  visible: false
})

const { changeMachinesStatus } = useUpdateMachinesStatus(() => {
  emit('search')
})

function selectionHandle(_: Utils.Key[], keys: DeviceListItem[]) {
  emit('update:selectedRows', keys)
}
function checkHostDetail(row: DeviceListItem) {
  hostDetailShow.value = { visible: true, record: row }
}

watch(
  () => props.loading,
  nValue => {
    nValue && (selectMachine.value = null)
  }
)
</script>

<template>
  <a-table
    v-bind="$tableConfigs(dataSource, loading)"
    class="table-box"
    row-key="device_sn"
    :scroll="{ ...$scroller('calc(100vh - 370px)'), x: 'main-content' }"
    :columns="$columnsSetter(columns)"
    :row-selection="
      $tableSelection({
        fixed: true,
        selectedRowKeys: selectedRows.map(row => row.device_sn),
        onChange: selectionHandle,
        getCheckboxProps: record => ({ disabled: record.is_approved })
      })
    "
  >
    <template #bodyCell="{ column: col, text, record }">
      <icon-button v-if="col.title === '详情'" title="详情" @click="checkHostDetail(record)">
        <icon-font type="iconcontent_list_icon_arrow1" />
      </icon-button>
      <span
        v-else-if="['服务状态', 'lotus状态'].includes(col.title)"
        class="dot"
        :class="text === 1 ? 'online' : 'offline'"
      ></span>
      <template v-else-if="col.title === '是否故障'">
        <div
          v-if="selectMachine?.device_sn !== record.device_sn"
          class="fault-machine"
          :class="{ 'error-text': text === 2 }"
        >
          <span>{{ machineErrorList.find(item => item.value === text)?.label }}</span>
          <icon-font type="icon-icon_edit" class="edit-icon-btn" @click="selectMachine = record" />
        </div>
        <custom-select
          v-else
          :data="machineErrorList"
          :value="selectMachine?.machine_status"
          @change="changeMachinesStatus(+($event ?? 1), selectMachine ? [selectMachine] : [])"
        />
      </template>
      <span v-else-if="col.title === '主机SN'">
        <custom-tooltip title="审批中">
          <icon-font v-if="record.is_approved" type="icon-suoding" style="cursor: default" />
        </custom-tooltip>
        <custom-tooltip>{{ text }}</custom-tooltip>
      </span>
      <custom-tooltip v-else>
        <span v-if="col.title === '软件角色'">
          {{ softwareList.find(item => item.value === text)?.label }}
        </span>
        <span v-else>{{ text }}</span>
      </custom-tooltip>
    </template>
  </a-table>
  <div class="total-show">
    <span>总数 : {{ pageVo.total }}</span>
    <span>在线 : {{ statistics.online }}</span>
    <span>离线 : {{ statistics.offline }}</span>
  </div>
  <a-pagination
    v-bind="{ ...pagerConfigs(pageVo), size: 'small', showTotal: null }"
    class="footer-pager"
    @change="(p, s) => $emit('search', { page: p, page_size: s })"
  />
  <host-detail-modal v-model:visible="hostDetailShow.visible" :record="hostDetailShow.record" />
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.table-box {
  .fault-machine {
    position: relative;
    .edit-icon-btn {
      display: none;
      position: absolute;
      left: calc(50% + 10px);
      top: 2px;
      font-size: 15px;
      cursor: pointer;
    }
    &:hover {
      .edit-icon-btn {
        display: block;
      }
    }
  }
}
.dot {
  display: inline-block;
  height: 15px;
  width: 15px;
  border-radius: 15px;
  &.online {
    background: @ueColor_third;
  }
  &.offline {
    background: @errorColor;
  }
}
.total-show {
  position: absolute;
  bottom: 20px;
  font-size: 14px;
  > span:not(span:last-of-type) {
    margin-right: 43px;
  }
}
.footer-pager {
  position: absolute;
  bottom: 20px;
  right: 20px;
}
</style>
