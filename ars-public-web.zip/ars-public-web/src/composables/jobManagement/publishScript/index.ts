import { usePagination } from '@/common/usePagination'
import { ScriptListItem, ScriptListParams } from '@/models/jobManagement/publishScript'
import {
  deleteScriptApi,
  enableScriptApi,
  scriptListAllApi
} from '@/services/jobManagement/publishScript'
import { message, Modal } from 'ant-design-vue'
import { ref } from 'vue'

export const columns: Utils.ColumnField<ScriptListItem>[] = [
  { title: '脚本名称', dataIndex: 'script_name' },
  { title: '脚本类型', dataIndex: 'script_type' },
  { title: '版本号', dataIndex: 'version' },
  { title: '脚本描述', dataIndex: 'note' },
  { title: '创建人', dataIndex: 'creator' },
  { title: '创建时间', dataIndex: 'created_at' },
  { title: '启用', dataIndex: 'enabled' },
  { title: '操作', dataIndex: 'id', width: 160 }
]

/** 获取所有脚本 */
export function useScriptAllList() {
  const searchModel = ref<Utils.NoPager<ScriptListParams>>({
    type_id: undefined,
    name: '',
    enabled: ''
  })
  const dataSource = ref<ScriptListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()

  async function searchScriptList(vo?: Utils.SearchVO) {
    try {
      const params: ScriptListParams = {
        ...searchModel.value,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      const reply = await scriptListAllApi(params)
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { searchModel, pageVo, dataSource, searchScriptList }
}

/**
 * 删除目标脚本
 * @param successFn
 * @returns
 */
export function useDeleteScript(successFn: () => void) {
  function deleteScript(id: number) {
    Modal.confirm({
      content: '是否删除指定脚本',
      async onOk() {
        try {
          const reply = await deleteScriptApi(id)
          if (reply.code === 0) {
            message.success('删除成功')
            successFn()
          } else {
            message.error(reply.msg)
          }
        } catch (e) {}
      }
    })
  }

  return { deleteScript }
}

/**
 * 启用目标脚本
 * @param successFn
 * @returns
 */
export function useEnableScript(successFn: () => void) {
  function enableScript(id: number, enable: boolean) {
    Modal.confirm({
      content: `是否${enable ? '启用' : '停用'}指定脚本`,
      async onOk() {
        try {
          const reply = await enableScriptApi(id, enable)
          if (reply.code === 0) {
            message.success(`${enable ? '启用' : '停用'}成功`)
            successFn()
          } else {
            message.error(reply.msg)
          }
        } catch (e) {}
      }
    })
  }

  return { enableScript }
}
