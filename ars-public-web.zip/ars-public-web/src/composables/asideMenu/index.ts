import router from '@/router'
import { useMainStore } from '@/store'
import { strEquals } from '@/utils/dataJudgement'
import { MenuItem } from '@/utils/routerController'
import { MenuInfo } from 'ant-design-vue/lib/menu/src/interface'
import { ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

export type BreadItem = Pick<MenuItem, 'name' | 'path'>

export function useAsideMenuList() {
  const route = useRoute()
  const router = useRouter()
  const selectedKey = ref<string[]>([])
  const openKeys = ref<string[]>([])
  const isClick = ref(false)

  useUpdateBreadcrumb()

  async function changeMenu(e: MenuInfo) {
    isClick.value = true
    const key = e.key as string
    const currentPath = route.path.split('/').pop()
    if (strEquals(key, currentPath ?? 'null')) {
      return
    }
    if (e.keyPath) {
      const path = e.keyPath.join('/')
      await router.push('/' + path)
      isClick.value = false
    }
  }

  async function initActiveMenu() {
    if (isClick.value) {
      return
    }
    await router.isReady()
    const pathList = route.path.substring(1).split('/')
    if (pathList.length >= 1) {
      pathList.length > 1 && (openKeys.value = pathList.slice(0, pathList.length - 1))
      selectedKey.value = [pathList.pop() ?? '']
    }
  }

  watch(
    () => route.path,
    () => initActiveMenu(),
    { immediate: true }
  )

  return { selectedKey, openKeys, changeMenu }
}

/** 更新面包屑 */
export function useUpdateBreadcrumb() {
  const route = useRoute()
  const store = useMainStore()

  async function updateBreadByMenu(menuList: MenuItem[]) {
    const nPath = route.path
    const pathList = nPath.substring(1).split('/')
    const routeList = router.getRoutes()
    const resultMenus: BreadItem[] = []
    pathList.forEach(url => {
      const target = menuList.find(menu => strEquals(menu.path, url))
      if (target) {
        resultMenus.push({
          path: target.path,
          name: target.name
        })
      } else {
        const targetRoute = routeList.find(view =>
          strEquals((view.meta.name as string | undefined) || '', url)
        )
        if (targetRoute) {
          const name = (targetRoute.meta.title as string | undefined) || ''
          resultMenus.push({
            path: targetRoute.path,
            name
          })
        }
      }
    })
    store.$patch({ breadList: resultMenus })
  }

  watch(
    () => route.path,
    () => updateBreadByMenu(store.sourceMenu)
  )
}
