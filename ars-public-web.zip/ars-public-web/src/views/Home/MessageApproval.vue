<script lang="ts" setup>
import { columns, useMessageList, useUpdateMsgReadState } from '@/composables/personal/myMessages'
import { MessageListItem } from '@/models/personal/myMessages'
import { ref } from 'vue'

const emit = defineEmits<{
  (event: 'handlePorSnumber', val: number): void
}>()
const { dataSource, handleSearch, loading, searchModel } = useMessageList(num =>
  emit('handlePorSnumber', num)
)

// 拿到所有未读的消息
searchModel.value.is_read = false

// // 操作审批弹窗
// const visible = ref<boolean>(false)
// const columnToast = ref<any>({})
// const textToast = ref<any>({})
// const recordToast = ref<any>({})
// const handleShow = (column: any, text: any, record: any) => {
// columnToast.value = column
// textToast.value = record
// recordToast.value = record
// visible.value = true
// }
// const handleOk = () => {
//   visible.value = false
// }

/** 标记当前查看的数据为已读 */
const { readTargetMessages } = useUpdateMsgReadState(handleSearch)

/** 消息弹窗 */
const messageVisible = ref<boolean>(false)

const messageRecord = ref<MessageListItem | null>(null)
function passMessageValue(record: MessageListItem) {
  messageRecord.value = record
  messageVisible.value = true
  readTargetMessages([record.id])
}

/* // const visible = ref<boolean>(false)
// const handleShow = () => {
//   visible.value = true
// }
// provide('visible', readonly(visible))
// provide('handleOk', () => {
//   visible.value = false
//   console.log('搜索')
// })
// provide('handleClose', () => {
//   visible.value = false
// }) */
handleSearch({ page: 1, page_size: 10 })
</script>

<template>
  <div id="components-table-demo-size">
    <a-table
      v-bind="$tableConfigs(dataSource, loading)"
      :columns="$columnsSetter(columns)"
      class="approvalTable"
    >
      <template #bodyCell="{ column, text, record }">
        <!-- 以下是显示除去状态外需要封装悬浮的内容 -->
        <custom-tooltip>
          <a-button
            v-if="column.title === '操作'"
            type="link"
            class="table-btn"
            @click="passMessageValue(record)"
          >
            查看
          </a-button>
          <span v-else-if="column.title === '内容'">
            {{ `${record.title}！${record.content}` }}
          </span>
          <span v-else>{{ text }}</span>
        </custom-tooltip>
      </template>
    </a-table>
    <a-modal v-model:visible="messageVisible" title="消息详情" :footer="null">
      <div class="modalContent">
        <p style="padding: 10px 0 10px 10px">
          {{ `${messageRecord?.title}！${messageRecord?.content}` }}
        </p>
      </div>
    </a-modal>
  </div>
  <!-- <ApprovalToast
    v-model:visible="visible"
    @handle-ok="handleOk"
    :columnToast="columnToast"
    :textToast="textToast"
    :recordToast="recordToast"
  /> -->
</template>

<style lang="less" scoped>
@import (reference) '@/assets/styles/index.less';
.more {
  color: @textColor_first;
  font-size: 12px;
  text-decoration: underline;
}
.modalContent {
  width: inherit;
  height: 200px;
}
</style>
