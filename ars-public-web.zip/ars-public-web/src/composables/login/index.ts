import { routes } from '@/router'
import { logoutApi } from '@/services/login'
import { useMainStore } from '@/store'
import { clearAccountInfo } from '@/utils/auth'
import { message } from 'ant-design-vue'
import { InjectionKey, onMounted, provide, readonly, Ref, ref } from 'vue'
import { useRouter } from 'vue-router'

/** 注销登录 */
export function useLogout(successFn?: () => void) {
  async function logout() {
    try {
      const reply = await logoutApi()
      if (reply.code === 0) {
        message.success('已退出登录')
        clearAccountInfo()
        successFn?.()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { logout }
}

interface UserInfo {
  phone: string
  origin_password: string
}

export const LoginUserKey: InjectionKey<Readonly<Ref<UserInfo>>> = Symbol('当前登录帐号')
export const ChangeUserFnKey: InjectionKey<(key: keyof UserInfo, value: string) => void> =
  Symbol('改变登录人信息')
/** 暂时存放登录人信息 */
export function useLoginUserInfo() {
  const userInfo = ref<UserInfo>({
    phone: '',
    origin_password: ''
  })

  const changeInfo = (key: keyof UserInfo, value: string) => {
    userInfo.value[key] = value
  }

  provide(LoginUserKey, readonly(userInfo))
  provide(ChangeUserFnKey, changeInfo)
}

/** 进入登录页后初始化所有配置 */
export const useInitSystemConfigs = () => {
  const store = useMainStore()
  const router = useRouter()

  onMounted(() => {
    // 删除上一个用户的路由表，防止权限泄露
    router.getRoutes().forEach(r => {
      r.name && router.removeRoute(r.name)
    })
    routes.forEach(r => r.name && router.addRoute(r))

    store.$patch({
      isRouteReady: false,
      funcAuthList: [],
      menuList: [],
      userInfo: null,
      sourceMenu: [],
      approvalFuncIds: []
    })
  })
}
