import useRequest from '@/common/useRequest'
import { TemplateTypeItem } from '@/models/jobManagement/commonTemplate'
import {
  deleteTemplateTypeApi,
  templateTypeAllApi,
  updateTemplateTypeApi
} from '@/services/jobManagement/commonTemplate'
import { message } from 'ant-design-vue'
import { ref, unref } from 'vue'

export const columns: Utils.ColumnField<TemplateTypeItem>[] = [
  { title: '模板类型名称', dataIndex: 'name' },
  { title: '操作', dataIndex: 'id' }
]

/** 获取模板类型列表 */
export function useTemplateTypeAllList() {
  const dataSource = ref<TemplateTypeItem[]>([])

  const { loading, run } = useRequest(templateTypeAllApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data || []
      } else {
        message.error(msg)
      }
    }
  })

  return { dataSource, loading, run }
}

const initialValues = {
  id: NaN,
  name: ''
}

/** 编辑模板类型信息 */
export function useUpdateTemplateType(successFn: () => void) {
  const formModel = ref({ ...initialValues })

  async function submitEdit() {
    const { id, name } = unref(formModel)
    if (!name) {
      message.warn('请输入类型名称')
      return
    }
    try {
      const reply = await updateTemplateTypeApi(id, name)
      if (reply.code === 0) {
        message.success('编辑成功')
        cancelEdit()
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  async function deleteType(targetId: number) {
    try {
      const reply = await deleteTemplateTypeApi(targetId)
      if (reply.code === 0) {
        message.success('删除成功')
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  function cancelEdit() {
    formModel.value = { ...initialValues }
  }

  return { formModel, submitEdit, deleteType, cancelEdit }
}
