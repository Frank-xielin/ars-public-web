<script lang="ts" setup>
import { FormRenderOptions } from '@/models/formRender'
import { FormProps } from 'ant-design-vue'
import { isBoolean } from 'lodash-es'
import { withDefaults } from 'vue'
import { useFormRender } from '../composables/formRender'

export interface FormRenderExpose {
  onSearch: (vo?: Utils.SearchVO) => void
}

const props = withDefaults(
  defineProps<{
    layout?: FormProps['layout']
    op: FormRenderOptions<any, any>
  }>(),
  {
    layout: 'inline'
  }
)
const dateParttern = 'YYYY-MM-DD HH:mm:ss'
const timeParttern = 'HH:mm:ss'

const { formModel, loading, pageVo, dataSource, handleSearch, handleChange, handleReset } =
  useFormRender(props.op)

defineExpose({
  onSearch: handleSearch
})
</script>

<template>
  <div class="form-render">
    <a-form class="form-render-searcher" :layout="layout">
      <slot name="preItem"></slot>
      <a-form-item
        v-for="(formItem, i) of op.queryParams"
        :key="i"
        :label="formItem.formLabel"
        :style="formItem.itemStyle"
      >
        <custom-select
          v-if="formItem.type === 'select'"
          v-bind="formItem.selectOptions"
          v-model:value="formModel[formItem.label]"
          :placeholder="formItem.placeholder"
          :data="formItem.selectOptions?.data || []"
          :value-field="formItem.selectOptions?.valueField"
          :label-field="formItem.selectOptions?.labelField"
          :style="formItem.style"
          @change="(...args) => handleChange(formItem)(...args)"
        />
        <a-input
          v-else-if="formItem.type === 'input'"
          v-model:value="formModel[formItem.label]"
          :placeholder="formItem.placeholder"
          :style="formItem.style"
          @change="(...args: any[]) => handleChange(formItem)(...args)"
        />
        <custom-search-input
          v-else-if="formItem.type === 'search'"
          v-model:value="formModel[formItem.label]"
          :placeholder="formItem.placeholder"
          :style="formItem.style"
          @change="(...args: any[]) => handleChange(formItem)(...args)"
          @search-func="handleSearch()"
        />
        <template v-else-if="formItem.type === 'date-picker'">
          <a-range-picker
            v-if="formItem.range"
            :format="formItem.format || dateParttern"
            separator="至"
            v-model:value="formModel[formItem.label]"
            :style="formItem.style"
            @change="(...args: any[]) => handleChange(formItem)(...args)"
          />
          <a-date-picker
            v-else
            :format="formItem.format || dateParttern"
            v-model:value="formModel[formItem.label]"
            :style="formItem.style"
            @change="(...args: any[]) => handleChange(formItem)(...args)"
          />
        </template>
        <template v-else-if="formItem.type === 'time-picker'">
          <a-time-range-picker
            v-if="formItem.range"
            :format="formItem.format || timeParttern"
            separator="至"
            v-model:value="formModel[formItem.label]"
            :style="formItem.style"
            @change="(...args: any[]) => handleChange(formItem)(...args)"
          />
          <a-time-picker
            v-else
            :format="formItem.format || timeParttern"
            v-model:value="formModel[formItem.label]"
            :style="formItem.style"
            @change="(...args: any[]) => handleChange(formItem)(...args)"
          />
        </template>
      </a-form-item>

      <a-form-item v-if="op.reset" :style="!isBoolean(op.reset) ? op.reset?.itemStyle : null">
        <a-button @click="handleReset">
          {{ !isBoolean(op.reset) && op.reset.text ? op.reset.text : '清空' }}
        </a-button>
      </a-form-item>
      <slot name="lastItem"></slot>
    </a-form>

    <a-table
      class="table-box"
      v-bind="{
        ...$tableConfigs(dataSource, loading, op.pager ? pageVo : undefined, handleSearch),
        ...op.tableConfigs.tableProps
      }"
      :columns="$columnsSetter(op.tableConfigs.columns)"
    >
      <template v-if="$slots.tableRender" #bodyCell="bodyObject">
        <slot name="tableRender" v-bind="bodyObject"></slot>
      </template>
    </a-table>
  </div>
</template>

<style lang="less">
.form-render-searcher {
  position: relative;
}
</style>
