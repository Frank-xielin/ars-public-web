import { message } from 'ant-design-vue'
import { ref } from 'vue'

/** 文件选择 */
export function useUploadInput() {
  const inputRef = ref<HTMLInputElement>()
  const fileInfo = ref({
    fileName: '',
    fileData: null as FormData | null
  })

  function getFile(ev: Event) {
    const target = ev.target as HTMLInputElement
    if (!target.files || !target.files[0]) {
      return
    }
    const file = target.files[0]
    if (!file.name.includes('.csv')) {
      message.warn('请选择csv文件')
      return
    }
    const formData = new FormData()
    formData.append('csv', file)
    fileInfo.value = {
      fileName: file.name,
      fileData: formData
    }
  }

  function cleanFileInfo() {
    fileInfo.value = {
      fileData: null,
      fileName: ''
    }
  }

  return { inputRef, fileInfo, getFile, cleanFileInfo }
}
