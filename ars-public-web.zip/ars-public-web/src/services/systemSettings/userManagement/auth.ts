import Cookies from 'js-cookie'

import {
  AvailablePermissionsRes,
  MenuFuncListRes,
  PermissionsByRoleRes,
  UpdateAuthOfRoleParams
} from '@/models/systemSettings/userManagement/auth'
import { request } from '@/utils/httpConfig'
import { storageKeys } from '@/utils/storage/storageList'

/** 菜单功能列表 - 全部 */
export function menuFuncListApi() {
  return request<MenuFuncListRes>({
    url: 'v5/public/auth/menu_function/get/all',
    method: 'GET'
  })
}

/** 通过当前用户获取菜单和功能的id 列表 */
export function availablePermissionsApi() {
  return request<AvailablePermissionsRes>({
    url: 'v5/public/auth/menu_function/get/all/ids',
    method: 'GET',
    loading: true
  })
}

/**
 * 通过角色id获取所有菜单和功能列表
 * @param id 角色 id
 * @returns
 */
export function permissionsByRoleApi(id: number) {
  return request<PermissionsByRoleRes>({
    url: `v5/public/menu_function/get/all/role_id/${id}`,
    method: 'GET',
    loading: true
  })
}

/**
 * 通过角色id设置所有菜单和功能列表
 * @param id 角色 id
 * @param data
 * @returns
 */
export function updateAuthOfRoleApi(id: number, data: UpdateAuthOfRoleParams) {
  return request({
    url: `v5/public/menu_function/update/role_id/${id}`,
    method: 'PUT',
    data,
    loading: true
  })
}

/** 检测 token 是否失效 */
export function tokenValidityApi() {
  const token = Cookies.get(storageKeys.token)
  return request({
    url: 'v5/public/auth/token/check',
    method: 'get',
    headers: { 'X-Csrf-Token': 'Bearer ' + token }
  })
}
