import useRequest from '@/common/useRequest'
import { DeviceListItem, ShutdownDevicesParams } from '@/models/workbench/hostManagement'
import { rebootDevicesApi, shutdownDevicesApi } from '@/services/workbench/hostManagement'
import { requestHandler } from '@/utils/formTools'
import { Ref, ref } from 'vue'
import { ApprovalInfo } from './'

export type DeviceOperation = '关机' | '重启'

export function useShutdownRebootDevices(successFn: () => void) {
  const shutdownForm = ref<ShutdownDevicesParams>({
    sns: [],
    miner_id: '',
    message: ''
  })

  const { run: shutdownFetch } = useRequest(shutdownDevicesApi, {
    onSuccess: reply => {
      requestHandler('操作成功')(reply)
      successFn()
    }
  })
  const { run: rebootFetch } = useRequest(rebootDevicesApi, {
    onSuccess: reply => {
      requestHandler('操作成功')(reply)
      successFn()
    }
  })

  async function submitApplication(type: DeviceOperation) {
    const isShutdown = type === '关机'
    try {
      const reply = isShutdown
        ? await shutdownFetch(shutdownForm.value)
        : await rebootFetch(shutdownForm.value)
      if (reply.code === 0) {
        shutdownForm.value = { sns: [], message: '', miner_id: '' }
      }
    } catch (e) {}
  }

  return { shutdownForm, submitApplication }
}

/**
 * 关机/重启机器弹窗
 * @param selected 已选择的机器
 * @returns
 */
export function useShutdownRebootModal(
  minerId: Ref<string>,
  selected: Ref<DeviceListItem[]>,
  approvalInfo: Ref<ApprovalInfo>,
  successFn: () => void
) {
  const operationType = ref<DeviceOperation>('关机')
  const shutdownShow = ref(false)
  const { shutdownForm, submitApplication } = useShutdownRebootDevices(() => {
    approvalInfo.value.visible = false
    successFn()
  })

  function rebootOrShutdownModal(type: DeviceOperation) {
    approvalInfo.value = {
      operation: type,
      func: type === '关机' ? 28 : 23,
      visible: true,
      submit: msg => {
        shutdownForm.value = {
          message: msg,
          miner_id: minerId.value,
          sns: selected.value.map(item => item.device_sn)
        }
        submitApplication(type)
      }
    }
  }

  return { operationType, shutdownShow, rebootOrShutdownModal }
}
