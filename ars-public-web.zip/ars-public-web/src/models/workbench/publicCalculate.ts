export interface DeviceListOfRoomParams extends Utils.SearchVO {
  machine_room_id: number
  lotus_server_status: number
  sn_ip: string
  machine_status: number
  ops_server_status: number
}

export interface DeviceListOfRoomItem {
  id: number
  ips: string
  device_sn: string
  /** 软件用途，0(unset)、1(node)、2(miner)、3(miner-back)、4(seal)、5(storage)、6(window/winning) */
  software_type: number
  product_model: string
  miner_client_name: string
  miner: string
  device_client_name: string
  /** 运维服务状态，0（未工作）、1（在线）、2（离线） */
  ops_server_status: number
  /** 机器状态，1（正常）、2（故障） */
  machine_status: number
  /** 服务状态，0（未工作）、1（在线）、2（离线） */
  lotus_server_status: number
  disk_use_count: number
  disk_all_count: number
  disk_mount_count: number
  task_count: number
  is_can_schedule: boolean
}

export interface DeviceListOfRoomRes extends Utils.PageVO {
  list: DeviceListOfRoomItem[]
}

export interface CalculateScheduleParams {
  sns: string[]
  purpose_cluster: string
}

export interface ClustersOfRoomItem {
  miner_id: string
  client_name: string
}

export type ClustersOfRoomRes = ClustersOfRoomItem[]
