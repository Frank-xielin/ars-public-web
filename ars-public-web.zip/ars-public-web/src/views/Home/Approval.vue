<script lang="ts" setup>
import {
  analysisHttpbody,
  usePendingApproval,
  useSubmitApproval
} from '@/composables/home/approval'
import { useAprovalToastEffect } from '@/composables/home/approvalToast'
import { useApprovalInfo } from '@/composables/jobManagement/taskManagement/allTaskApi'
import { useMainStore } from '@/store'
import { computed, unref, watch } from 'vue'
import { useRouter } from 'vue-router'
// 真数据
import { colors, columns } from '../../composables/home/approval'

const props = defineProps<{
  type: string
}>()
const emit = defineEmits<{
  (event: 'handlePorSnumber', val: number): void
}>()
const searCher = computed(() => {
  // 某一次请求数据的响应式，不代表会根据时间自动响应
  if (props.type === '1') {
    const { dataSource, loading, handleSearch } = usePendingApproval(num =>
      emit('handlePorSnumber', num)
    )
    return { dataSource, loading, handleSearch }
  } else {
    const { dataSource, loading, handleSearch } = useSubmitApproval(num => {
      emit('handlePorSnumber', num)
    })
    return { dataSource, loading, handleSearch }
  }
})
const { dataSource, loading, handleSearch } = unref(searCher) // .value之后才符合常规解构 unref函数去掉第一层响应式value，相当于searcher.value
// console.log(props.type) 检查是否加载几个组件
handleSearch({ page: 1, page_size: 10 }) // 初始化搜索数据

// function analysisHttpbody(data: string) {
//   const obj: any = JSON.parse(data || '')
//   console.log(obj, '-------')
//   return obj
// }

const { visible, handleShow, recordToast, isAgreeOperate } = useAprovalToastEffect(() =>
  handleSearch({ page: 1, page_size: 10 })
)

// 去任务审批
const router = useRouter()
function toTaskApproval(id: number) {
  router.push({
    path: '/JobManagement/TaskManagement/ViewTask',
    query: { id }
  })
}

// 拿到当前处理人
const { approveInfo, getApprovalInfo } = useApprovalInfo()

const store = useMainStore()
function isActorUser() {
  return store.userInfo?.id === approveInfo.value?.current_node.approver_id
}
watch(
  () => recordToast.value?.id,
  id => {
    if (id) {
      getApprovalInfo(id)
    }
  }
)

/* // const visible = ref<boolean>(false)
// const handleShow = () => {
//   visible.value = true
// }
// provide('visible', readonly(visible))
// provide('handleOk', () => {
//   visible.value = false
//   console.log('搜索')
// })
// provide('handleClose', () => {
//   visible.value = false
// }) */
</script>

<template>
  <!-- <div :class="item.type == '操作审批' ? 'task' : 'hide'">{{ item.kj }}</div> -->
  <!-- 判断css二选一 -->
  <div id="components-table-demo-size">
    <a-table
      v-bind="$tableConfigs(dataSource, loading)"
      :columns="$columnsSetter(columns)"
      class="approvalTable"
    >
      <template #bodyCell="{ column, text, record }">
        <template v-if="column.title === '状态'">
          <a-tag :color="colors.find(item => item.id === text)?.color">
            {{ colors.find(item => item.id === text)?.text }}
          </a-tag>
        </template>
        <!-- 以下是显示除去状态外需要封装悬浮的内容 -->
        <custom-tooltip v-else>
          <a-button
            v-if="column.title === '操作'"
            type="link"
            class="table-btn"
            @click="
              record.target_type === 'task' ? toTaskApproval(record.target_id) : handleShow(record)
            "
          >
            <!-- colors.find(item => item.id === record.state)?.words -->
            {{ isActorUser() ? '去审核' : '查看' }}
          </a-button>
          <span v-else-if="column.title === '内容'">{{ text?.name }}</span>
          <span v-else-if="column.title === '集群'">
            {{
              record.target_type === 'task'
                ? text?.miner?.miner
                : analysisHttpbody(text?.http_body)?.miner_id
            }}
          </span>
          <span v-else-if="column.title === '原因'">
            {{
              record.target_type === 'task'
                ? text?.note
                : analysisHttpbody(text?.http_body)?.message
            }}
          </span>
          <span v-else-if="column.title === '提交人'">{{ record.submitor.user_name }}</span>
          <span v-else-if="column.title === '类型'">
            {{ text === 'task' ? '任务审批' : '操作审批' }}
          </span>
          <span v-else>{{ text }}</span>
        </custom-tooltip>
      </template>
    </a-table>
  </div>
  <ApprovalToast
    v-model:visible="visible"
    :recordToast="recordToast"
    @isAgreeOperate="isAgreeOperate"
  />
</template>

<style lang="less" scoped>
.wrapper {
  display: flex;
  .task {
    margin-right: 10px;
  }
  .taskApproval {
    font-weight: bold;
  }
}
</style>
