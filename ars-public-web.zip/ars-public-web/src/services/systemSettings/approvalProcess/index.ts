import {
  ApprovalListParams,
  ApprovalListRes,
  ApprovalTempAllListRes,
  BindOpsByApprovalParams
} from '@/models/systemSettings/approvalProcess'
import { request } from '@/utils/httpConfig'

/** 审批流模板获取 - 所有 */
export function approvalTempAllListApi() {
  return request<ApprovalTempAllListRes>({
    url: 'v5/public/approval_template/get/all',
    method: 'GET'
  })
}

/**
 * 审批流模板删除 - 单个
 * @param id 目标审批流模板的 id
 * @returns
 */
export function deleteApprovalTempApi(id: number) {
  return request({
    url: `v5/public/approval_template/delete/id/${id}`,
    method: 'delete',
    loading: true
  })
}

/**
 * 审批流模板关联操作 - 单个
 * @param id 目标审批流模板的 id
 * @param data 关联数据
 * @returns
 */
export function bindOpsByApprovalApi(id: number, data: BindOpsByApprovalParams) {
  return request({
    url: `v5/public/approval_template/bind/id/${id}`,
    method: 'patch',
    data,
    loading: true
  })
}

/**
 * 审批流列表 - 分页
 * @param data 过滤条件
 * @returns
 */
export function approvalListApi(data: ApprovalListParams) {
  return request<ApprovalListRes>({
    url: 'v5/public/approval/get/list',
    method: 'get',
    data
  })
}
