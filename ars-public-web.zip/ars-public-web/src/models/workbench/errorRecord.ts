import { ClientListItem } from '../systemSettings/clientInformation'
import { UserInfoByIdRes } from '../systemSettings/userManagement/user'

export interface BrokenRecordListParams extends Utils.SearchVO {
  /** 故障分类 */
  fault_sort: number
  /** 故障等级 */
  fault_grade: number
  /** 处理状态 */
  processing_status: number
  start_time: string
  end_time: string
  /** 搜索（集群ID\客户） */
  search: string
}

export interface BrokenRecordListItem {
  broken: {
    id: number
    created_at: string
    updated_at: string
    deleted_at: string | null
    record_time: string
    miner_id: string
    fault_description: string
    fault_reason: string
    fault_sort: number
    fault_grade: number
    processing_status: number
  }
  clients: ClientListItem
  users: UserInfoByIdRes
}

export interface BrokenRecordListRes extends Utils.PageVO {
  list: BrokenRecordListItem[]
}

export interface CreateBrokenRecordParams {
  /** 记录时间 */
  record_time: string
  /** 集群 id */
  miner_id: string
  /** 故障描述 */
  fault_description: string
  /** 故障原因 */
  fault_reason: string
  /** 故障类型;0：其他，1：硬件问题，2：软件问题，3：同步问题，4：运维失误 */
  fault_sort: number
  /** 故障等级;1：高，2：中，3：低 */
  fault_grade: number
  /** 处理状态;1：未处理，2：进行中，3：已完成 */
  processing_status: number
}

export type UpdateBrokenRecordParams = CreateBrokenRecordParams
