import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { LoginLogListItem, LoginLogListParams } from '@/models/logManagement/loginLog'
import { loginLogListApi } from '@/services/logManagement/loginLog'
import { message } from 'ant-design-vue'
import { Dayjs } from 'dayjs'
import { omit } from 'lodash-es'
import { ref } from 'vue'

export const loginStatusList = [
  { label: '全部', value: -1 },
  { label: '异常', value: 1 },
  { label: '正常', value: 0 }
]

export const columns: Utils.ColumnField<LoginLogListItem>[] = [
  { title: '登录时间', dataIndex: 'datetime' },
  { title: '用户名', dataIndex: 'user_id' },
  { title: '手机号', dataIndex: 'phone' },
  { title: '位置', dataIndex: 'city' },
  { title: 'IP地址', dataIndex: 'ip' },
  { title: '浏览器', dataIndex: 'user_agent' },
  { title: '登录结果', dataIndex: 'status' },
  { title: '状态', dataIndex: 'is_abnormal' }
]

interface SearchForm extends Utils.NoPager<LoginLogListParams> {
  dates?: [Dayjs, Dayjs]
}

/** 当前用户的登录日志 */
export function useLoginLogs() {
  // 初始化
  const searchModel = ref<SearchForm>({
    start_time: '',
    end_time: '',
    is_abnormal: -1,
    dates: undefined
  })
  const dataSource = ref<LoginLogListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()

  const { run: logsFetch, loading } = useRequest(loginLogListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  async function handleSearch(vo?: Utils.SearchVO) {
    try {
      const formatStr = 'YYYY-MM-DD HH:mm:ss'
      const { dates } = searchModel.value
      searchModel.value.start_time = dates?.[0].format(formatStr) || ''
      searchModel.value.end_time = dates?.[1].format(formatStr) || ''
      const params: LoginLogListParams = {
        ...omit(searchModel.value, ['dates']),
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      logsFetch(params)
    } catch (e) {}
  }

  return { pageVo, dataSource, searchModel, loading, handleSearch }
}
