import useRequest from '@/common/useRequest'
import { ModalType } from '@/composables/workbench/errorRecord'
import { CreateClusterParams } from '@/models/systemSettings/clusterInformation'
import { createClusterApi, updateClusterApi } from '@/services/systemSettings/clusterInformation'
import { requestHandler, requireChecker } from '@/utils/formTools'
import { Form } from 'ant-design-vue'
import { ref } from 'vue'

export const sectorSizeList = [
  { label: '32G', value: 34359738368 },
  { label: '64G', value: 68719476736 }
]
const initialInfo: CreateClusterParams = {
  cluster_id: '',
  owned_customer: 0,
  machine_room: 0,
  domain: '',
  sector_size: 34359738368,
  note: ''
}
export const requireInput = requireChecker('请输入')
export const requireSelect = requireChecker('请选择')

/**
 * 编辑集群信息
 * @param successFn
 * @returns
 */
export function useChangeCluster(type: Utils.Prop<ModalType>, successFn: () => void) {
  const formModel = ref<CreateClusterParams>({ ...initialInfo })
  const rules = ref<Utils.RulesObject<CreateClusterParams>>({
    cluster_id: [requireInput('集群ID')],
    owned_customer: [requireSelect('所属客户')],
    machine_room: [requireSelect('所在机房')],
    domain: [requireInput('域名')],
    sector_size: [requireSelect('扇区大小')]
  })
  const form = Form.useForm(formModel, rules)

  const { run: createFetch } = useRequest(createClusterApi, {
    onSuccess: reply => {
      requestHandler('新建集群成功')(reply)
      reply.code === 0 && successFn()
    }
  })
  const { run: updateFetch } = useRequest(updateClusterApi, {
    onSuccess: reply => {
      requestHandler('编辑集群成功')(reply)
      reply.code === 0 && successFn()
    }
  })

  async function onSubmit(id?: number) {
    try {
      await form.validate()
      if (id && type.value === '编辑') {
        updateFetch(id, formModel.value)
      } else {
        createFetch(formModel.value)
      }
    } catch (e) {}
  }

  return { formModel, form, onSubmit }
}
