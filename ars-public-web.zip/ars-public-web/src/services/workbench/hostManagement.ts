import {
  BatchCreateDevicesParams,
  BatchRemoveFaultMachinesParams,
  BatchUpdateMachinesStatParams,
  DeviceListParams,
  DeviceListRes,
  DeviceOperationListParams,
  DeviceOperationListRes,
  RebootDevicesParams,
  RestartLotusParams,
  ShutdownDevicesParams,
  StartLotusParams,
  StopLotusParams,
  UsersClusterListRes
} from '@/models/workbench/hostManagement'
import { request } from '@/utils/httpConfig'

/** 主机用户管理集群列表 */
export function usersClusterListApi() {
  return request<UsersClusterListRes>({
    url: 'v5/public/device/user_miner/get/all',
    method: 'GET',
    loading: true
  })
}

/**
 * 添加主机 - 批量
 * @param data
 * @returns
 */
export function batchCreateDevicesApi(data: BatchCreateDevicesParams) {
  return request({
    url: 'v5/public/device/create/batch',
    method: 'POST',
    data,
    loading: true
  })
}

/**
 * 主机导入 - 批量
 * @param data
 * @returns
 */
export function importDevicesApi(miner_id: string, file: FormData) {
  return request({
    url: 'v5/public/device/create/import',
    method: 'post',
    params: { miner_id },
    data: file,
    loading: true
  })
}

/**
 * 主机列表 - 分页
 * @param data 筛选条件
 * @returns
 */
export function deviceListApi(data: DeviceListParams) {
  return request<DeviceListRes>({
    url: 'v5/public/device/get/list',
    method: 'get',
    data
  })
}

/** 主机详情操作记录 - 分页 */
export function deviceOperationListApi(data: DeviceOperationListParams) {
  return request<DeviceOperationListRes>({
    url: 'v5/public/device/operation/get/list',
    method: 'get',
    data
  })
}

/**
 * 主机标注故障机 - 单个或多个
 * @param data
 * @returns
 */
export function batchUpdateMachinesStatApi(data: BatchUpdateMachinesStatParams) {
  return request({
    url: 'v5/public/device/update/batch/machine_status',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 主机移除故障机-批量
 * @param ids 以逗号分割
 * @returns
 */
export function batchRemoveFaultMachinesApi(data: BatchRemoveFaultMachinesParams) {
  return request({
    url: 'v5/public/device/delete/batch/fault_machine',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 主机系统命令 - 关机
 * @param data
 * @returns
 */
export function shutdownDevicesApi(data: ShutdownDevicesParams) {
  return request({
    url: 'v5/public/device/cmd/shutdown',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 主机系统命令 - 重启
 * @param data
 * @returns
 */
export function rebootDevicesApi(data: RebootDevicesParams) {
  return request({
    url: 'v5/public/device/cmd/reboot',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 主机lotus命令 - 启动
 * @param data
 * @returns
 */
export function startLotusApi(data: StartLotusParams) {
  return request({
    url: 'v5/public/device/lotus/start',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 主机lotus命令 - 重启
 * @param data
 * @returns
 */
export function restartLotusApi(data: RestartLotusParams) {
  return request({
    url: 'v5/public/device/lotus/restart',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 主机lotus命令 - 停止
 * @param data
 * @returns
 */
export function stopLotusApi(data: StopLotusParams) {
  return request({
    url: 'v5/public/device/lotus/stop',
    method: 'post',
    data,
    loading: true
  })
}
