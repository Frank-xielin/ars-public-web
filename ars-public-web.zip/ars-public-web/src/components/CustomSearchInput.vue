<script lang="ts" setup>
import InputProps from 'ant-design-vue/lib/input/inputProps'
import { mergeProps } from 'vue'

const props = defineProps(InputProps)
const emit = defineEmits<{
  (event: 'searchFunc'): void
}>()

function handleKeydown(e: KeyboardEvent) {
  props.onKeydown && props.onKeydown(e)
  if (e.key === 'Enter') {
    emit('searchFunc')
  }
}
</script>

<template>
  <a-input v-bind="mergeProps($props, $attrs)" @keydown="handleKeydown">
    <template #suffix>
      <svg
        class="icon"
        aria-hidden="true"
        @click="$emit('searchFunc')"
        style="cursor: pointer; font-size: 16px"
      >
        <use href="#iconcontent_list_icon_search"></use>
      </svg>
    </template>
  </a-input>
</template>
