import { FuncListItem } from '@/models/systemSettings/userManagement/auth'
import {
  availablePermissionsApi,
  tokenValidityApi
} from '@/services/systemSettings/userManagement/auth'
import { useMainStore } from '@/store'
import storage from '@/utils/storage'
import { storageKeys } from '@/utils/storage/storageList'
import { usePageLeave, useTitle } from '@vueuse/core'
import { message } from 'ant-design-vue'
import { computed, ref, watch } from 'vue'
import { useAllMenuFuncList } from '../systemSettings/userManagement/auth'
import { useGetUserInfo } from '../systemSettings/userManagement/user/userManageTab'

/**
 * 初始化当前登录用户的信息
 * @returns
 */
export function useInitCurrentUserInfo() {
  const store = useMainStore()

  const { userInfo, getUserById } = useGetUserInfo()

  /** 使用缓存中的 userId 获取用户信息 */
  async function initUserInfo() {
    try {
      const userId = storage.getItem<number>(storageKeys.userId.key, storageKeys.userId.module)
      if (userId) {
        return getUserById(userId).then(() => {
          store.$patch({ userInfo: userInfo.value })
        })
      }
    } catch (e) {}
  }

  return { userInfo, initUserInfo }
}

/** 当前用户的权限数据 */
export function useCurrentUserAuths() {
  const store = useMainStore()
  const { menuList, funcList, getAllMenuFuncList } = useAllMenuFuncList()

  async function initCurrentUserAuths() {
    const publicFilter = ['public', '公有云']
    try {
      await getAllMenuFuncList()
      const reply = await availablePermissionsApi()
      const { code, data, msg } = reply
      if (code === 0 && data) {
        const funcs = funcList.value.filter(
          func =>
            data.func_ids.includes(func.id) && !func.status && publicFilter.includes(func.domain)
        )
        const menus = menuList.value.filter(
          menu =>
            data.menu_ids.includes(menu.id) && !menu.status && publicFilter.includes(menu.domain)
        )
        const approvalFuncIds = getApprovalFuncList(funcs)
        store.$patch({ funcAuthList: funcs, sourceMenu: menus, approvalFuncIds })
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { initCurrentUserAuths }
}

/**
 * 筛选需要审批的功能 id
 * @param funcList
 * @returns
 */
function getApprovalFuncList(funcList: FuncListItem[]) {
  const resultList: number[] = []
  funcList.forEach(func => {
    const { approval_flow_templates: templates } = func
    if (templates?.length && templates[0].enabled) {
      resultList.push(func.id)
    }
  })
  return resultList
}

/** 长时间离开页面后校验 token 是否已失效 */
export function useTokenAvailability() {
  const leftTime = ref(new Date().getTime())
  const isLeft = usePageLeave()

  watch(isLeft, left => {
    if (left) {
      leftTime.value = new Date().getTime()
    } else {
      const time = new Date().getTime()
      if (time - leftTime.value >= 30000) {
        tokenValidityApi().catch()
      } else {
        leftTime.value = time
      }
    }
  })
}

export function useAutoUpdateTitle() {
  const store = useMainStore()

  const title = computed(() => {
    const len = store.breadList.length
    const target = store.breadList[len - 1]
    return '集群运维系统' + (target?.name ? ` - ${target.name}` : '')
  })
  useTitle(title)
}
