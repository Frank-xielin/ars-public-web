import {
  CreateUserGroupParams,
  CreateUserParams,
  UpdateUserGroupParams,
  UpdateUserStatParams,
  UserGroupListAllRes,
  UserGroupListParams,
  UserGroupListRes,
  UserInfoByIdRes,
  UserLinkClusterParams,
  UserLinkRolesParams,
  UserListParams,
  UserListRes
} from '@/models/systemSettings/userManagement/user'
import { request } from '@/utils/httpConfig'

/**
 * 根据用户id获取用户信息 - 单个
 * @param id 用户 id
 * @returns
 */
export function getUserInfoByIdApi(id: number) {
  return request<UserInfoByIdRes>({
    url: `v5/public/user/get/info/id/${id}`,
    method: 'get',
    loading: true
  })
}

/** 用户列表 - 分页 */
export function userListApi(data: UserListParams) {
  return request<UserListRes>({
    url: 'v5/public/user/get/list',
    method: 'get',
    data
  })
}

/**
 * 创建单个用户
 * @param data
 * @returns
 */
export function createUserApi(data: CreateUserParams) {
  return request({
    url: 'v5/public/user/create/one',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 用户冻结、leader、参与审批 - 单个
 * @param id 用户 id
 * @returns
 */
export function updateUserStatApi(id: number, data: UpdateUserStatParams) {
  return request({
    url: `v5/public/user/update/id/${id}`,
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 用户关联角色
 * @param data 关联数据
 */
export function userLinkRolesApi(data: UserLinkRolesParams) {
  return request({
    url: 'v5/public/user/update/bind_role',
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 用户关联集群
 * @param data 关联数据
 */
export function userLinkClusterApi(data: UserLinkClusterParams) {
  return request({
    url: 'v5/public/user/update/bind_miner',
    method: 'put',
    data,
    loading: true
  })
}

/** 用户组列表 - 全部 */
export function userGroupListAllApi() {
  return request<UserGroupListAllRes>({
    url: 'v5/public/user/group/get/all',
    method: 'get'
  })
}

/**
 * 用户组列表 - 分页
 * @param vo 分页信息
 * @returns
 */
export function userGroupListApi(data: UserGroupListParams) {
  return request<UserGroupListRes>({
    url: 'v5/public/user/group/get/list',
    method: 'get',
    data
  })
}

/**
 * 用户组新建 - 单个
 * @param data 用户组信息
 * @returns
 */
export function createUserGroupApi(data: CreateUserGroupParams) {
  return request({
    url: 'v5/public/user/group/create/one',
    method: 'post',
    data
  })
}

/**
 * 用户组修改 - 单个
 * @param id 目标用户组 id
 * @param data
 * @returns
 */
export function updateUserGroupApi(id: number, data: UpdateUserGroupParams) {
  return request({
    url: `v5/public/user/group/update/id/${id}`,
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 获取指定用户已绑定的集群数据
 * @param id 目标用户 id
 * @returns
 */
export function getUsersClusterListApi(id: number) {
  return request<string[]>({
    url: `v5/public/user/get/miner/info/id/${id}`,
    method: 'get',
    loading: true
  })
}

/**
 * 用户组删除 - 单个
 * @param id 目标用户组 id
 * @returns
 */
export function deleteUserGroupApi(id: number) {
  return request({
    url: `v5/public/user/group/delete/id/${id}`,
    method: 'delete',
    loading: true
  })
}
