import { BreadItem } from '@/composables/asideMenu'
import { FuncListItem, MenuListItem } from '@/models/systemSettings/userManagement/auth'
import { UserInfoByIdRes } from '@/models/systemSettings/userManagement/user'
import { LoadStateObj } from '@/utils/httpConfig'
import { MenuItem } from '@/utils/routerController'
import { defineStore } from 'pinia'

export const useMainStore = defineStore('main', {
  state: () => ({
    isRouteReady: false,
    globalLoading: {
      loading: false,
      fetchList: [] as string[]
    },
    routerLoading: false,
    /** 用户信息 */
    userInfo: null as UserInfoByIdRes | null,
    /** 已有权限的按钮 */
    funcAuthList: [] as FuncListItem[],
    /** 已有权限的菜单 */
    menuList: [] as MenuItem[],
    /** 菜单原数据 */
    sourceMenu: [] as MenuListItem[],
    /** 面包屑数据 */
    breadList: [] as BreadItem[],
    /** 需要审批的功能 id */
    approvalFuncIds: [] as number[]
  }),
  actions: {
    changeLoading(payload: LoadStateObj) {
      this.$patch(state => {
        const { globalLoading } = state
        if (payload.status) {
          globalLoading.fetchList.push(payload.key)
        } else if (globalLoading.fetchList.length !== 0) {
          globalLoading.fetchList = globalLoading.fetchList.filter(item => item !== payload.key)
        }
        globalLoading.loading = globalLoading.fetchList.length !== 0
      })
    }
  }
})
