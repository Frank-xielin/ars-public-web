import useRequest from '@/common/useRequest'
import { ScriptTypeListItem } from '@/models/jobManagement/publishScript'
import {
  deleteScriptTypeApi,
  scriptTypeListAllApi,
  updateScriptTypeApi
} from '@/services/jobManagement/publishScript'
import { message, Modal } from 'ant-design-vue'
import { ref, unref } from 'vue'

export const columns: Utils.ColumnField<ScriptTypeListItem>[] = [
  { title: '脚本类型名称', dataIndex: 'name' },
  { title: '操作', dataIndex: 'id' }
]

/** 获取所有的脚本类型 */
export function useScriptTypeAllList() {
  const dataSource = ref<ScriptTypeListItem[]>([])

  const { loading, run } = useRequest(scriptTypeListAllApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data || []
      } else {
        message.error(msg)
      }
    }
  })

  return { dataSource, loading, run }
}

/**
 * 删除指定的脚本类型
 * @param successFn
 * @returns
 */
export function useDeleteScriptType(successFn: () => void) {
  function deleteType(id: number) {
    Modal.confirm({
      content: '是否删除指定脚本类型',
      async onOk() {
        try {
          const reply = await deleteScriptTypeApi(id)
          if (reply.code === 0) {
            message.success('删除成功')
            successFn()
          } else {
            message.error(reply.msg)
          }
        } catch (e) {}
      }
    })
  }

  return { deleteType }
}

/**
 * 编辑指定的脚本类型
 * @param successFn
 * @returns
 */
export function useUpdateScriptType(successFn: () => void) {
  const updateForm = ref({ id: 0, name: '' })

  async function updateType() {
    try {
      const { id, name } = unref(updateForm)
      const reply = await updateScriptTypeApi(id, name)
      if (reply.code === 0) {
        message.success('编辑成功')
        updateForm.value = { id: 0, name: '' }
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { updateForm, updateType }
}
