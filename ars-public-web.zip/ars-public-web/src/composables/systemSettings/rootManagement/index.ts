import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import {
  GetUpdateResultRes,
  RootPwdListItem,
  RootPwdListParams
} from '@/models/systemSettings/rootManagement'
import { rootPwdListApi } from '@/services/systemSettings/rootManagement'
import { message } from 'ant-design-vue'
import { pick } from 'lodash-es'
import { InjectionKey, provide, ref } from 'vue'

export const columns: Utils.ColumnField<RootPwdListItem>[] = [
  { title: '主机SN', dataIndex: 'device_sn' },
  { title: '软件角色', dataIndex: 'software_type' },
  { title: 'IP', dataIndex: 'ips' },
  { title: '是否故障', dataIndex: 'machine_status' },
  { title: '主机状态', dataIndex: 'ops_server_status' },
  { title: 'lotus状态', dataIndex: 'lotus_server_status' },
  { title: '操作', dataIndex: 'id' }
]

export const ChangeResultListFnKey: InjectionKey<(val: GetUpdateResultRes) => void> =
  Symbol('修改记录列表')

/** 操作按钮的执行逻辑 */
export const useRootManagementOperations = () => {
  const updatePwdShow = ref(false)
  const checkPwdShow = ref(false)
  const updateType = ref<'single' | 'role'>('single')
  const selectedRows = ref<RootPwdListItem[]>([])
  const updateTargetId = ref(0)
  const recordShow = ref(false)
  const updateResult = ref<GetUpdateResultRes>({
    list: [],
    total_size: 0,
    online_size: 0,
    offline_size: 0
  })
  const updateResultShow = ref(false)

  const handleOperate = (type: 'role' | 'single' | 'check' | 'record', id?: number) => {
    if (!selectedRows.value.length && type === 'check') {
      message.warn('至少选择一条数据')
      return
    }
    if (type === 'role' || type === 'single') {
      updateType.value = type
      updatePwdShow.value = true
      updateTargetId.value = id || 0
    } else if (type === 'check') {
      checkPwdShow.value = true
    } else {
      recordShow.value = true
    }
  }

  const changeResultList = (val: GetUpdateResultRes) => {
    updateResult.value = val
    updateResultShow.value = true
  }

  provide(ChangeResultListFnKey, changeResultList)

  return {
    updatePwdShow,
    updateResultShow,
    checkPwdShow,
    updateType,
    recordShow,
    updateTargetId,
    updateResult,
    selectedRows,
    handleOperate
  }
}

/** root 密码管理表格数据 */
export const useRootManagementData = (afterSearchFn: () => void) => {
  const formModel = ref<Utils.NoPager<RootPwdListParams>>({
    cluster_id: '',
    software: -1,
    sn_ip: ''
  })
  const dataSource = ref<RootPwdListItem[]>([])
  const statistics = ref({ offline_size: 0, online_size: 0 })
  const { pageVo, setPageFromData } = usePagination()

  const { loading, run } = useRequest(rootPwdListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
        data && (statistics.value = pick(data, ['online_size', 'offline_size']))
      } else {
        message.error(msg)
      }
      afterSearchFn()
    }
  })

  const handleSearch = async (vo?: Utils.SearchVO) => {
    try {
      const params: RootPwdListParams = {
        ...formModel.value,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params)
    } catch (e) {}
  }

  return { pageVo, statistics, dataSource, loading, formModel, handleSearch }
}
