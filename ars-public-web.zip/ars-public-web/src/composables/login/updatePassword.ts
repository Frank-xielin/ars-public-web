import { UpdatePwOriginParams } from '@/models/login'
import { updatePwOriginApi } from '@/services/login'
import { RSAEncryption } from '@/utils/cryptage'
import { Form, message } from 'ant-design-vue'
import { omit } from 'lodash-es'
import { inject, onMounted, ref } from 'vue'
import { LoginUserKey } from '.'
import { requireInput } from '../systemSettings/clusterInformation/addEditCluster'

const crypto = new RSAEncryption()

interface UpdatePasswordForm extends UpdatePwOriginParams {
  repeat_new_password: string
}

/**
 * 更新密码
 * @param successFn 更新成功后的回调
 * @returns
 */
export function useUpdatePw(successFn?: () => void) {
  const formModel = ref<UpdatePasswordForm>({
    phone: '',
    original_password: '',
    new_password: '',
    repeat_new_password: ''
  })
  const rules = ref<Utils.RulesObject<UpdatePasswordForm>>({
    phone: [requireInput('手机号'), { pattern: /^1([3-9])\d{9}$/, message: '手机号格式错误' }],
    new_password: [requireInput('新密码')],
    repeat_new_password: [
      { required: true, message: '请再次输入新密码' },
      {
        validator: (_, val) => {
          if (val && val !== formModel.value.new_password) {
            return Promise.reject('两次密码输入不一致')
          }
          return Promise.resolve()
        }
      }
    ]
  })
  const userInfo = inject(LoginUserKey)
  const form = Form.useForm(formModel, rules)

  /** 提交修改 */
  async function submitForm() {
    try {
      await form.validate()
      const params: UpdatePwOriginParams = {
        ...omit(formModel.value, ['repeat_new_password']),
        original_password: crypto.encode(formModel.value.original_password) || '',
        new_password: crypto.encode(formModel.value.new_password) || ''
      }
      const reply = await updatePwOriginApi(params)
      if (reply.code === 0) {
        successFn?.()
      } else {
        message.error(reply.msg)
      }
    } catch (error) {}
  }

  onMounted(() => {
    if (userInfo) {
      formModel.value.phone = userInfo.value.phone
      formModel.value.original_password = userInfo.value.origin_password
    }
  })

  return { form, formModel, submitForm }
}
