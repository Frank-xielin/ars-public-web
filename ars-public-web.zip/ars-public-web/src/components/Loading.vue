<script lang="ts" setup>
import { spinProps } from 'ant-design-vue/lib/spin'
import LoadingImage from './LoadingImage.vue'

defineProps({
  ...spinProps(),
  spinning: {
    type: Boolean,
    default: true
  }
})
</script>

<template>
  <div>
    <a-spin class="loading-custom" v-bind="$.props">
      <template #indicator>
        <loading-image is-global />
      </template>
    </a-spin>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.loading-custom {
  position: fixed !important;
  top: 50vh;
  left: 50vw;
  transform: translate(-50%, -50%);
  height: 80px;
  border-radius: 80px;
  box-shadow: 0 0 15px 5px @ueColor_first;
  z-index: 3000;
}
</style>
