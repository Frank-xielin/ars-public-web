<script lang="ts" setup>
import { useAllClientList } from '@/composables/systemSettings/clientInformation'
import {
  sectorSizeList,
  useChangeCluster
} from '@/composables/systemSettings/clusterInformation/addEditCluster'
import { useRoomList } from '@/composables/systemSettings/roomInformation'
import { ModalType } from '@/composables/workbench/errorRecord'
import { ClusterListItem } from '@/models/systemSettings/clusterInformation'
import { toRefs, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  modalType: ModalType
  targetInfo?: ClusterListItem | null
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()

const { modalType } = toRefs(props)

const { clients, getAllClients } = useAllClientList()
const { dataSource: roomList, handleSearch: getAllRooms } = useRoomList()
const { formModel, form, onSubmit } = useChangeCluster(modalType, () => {
  emit('update:visible', false)
  form.resetFields()
  emit('search')
})

watch(
  () => props.visible,
  val => {
    if (val) {
      const { modalType, targetInfo } = props
      const isCreate = modalType === '新建'
      getAllClients().then(() => {
        isCreate && (formModel.value.owned_customer = clients.value[0]?.id || 0)
      })
      getAllRooms({ page: 1, page_size: 10000 }).then(() => {
        isCreate && (formModel.value.machine_room = roomList.value[0]?.id || 0)
      })
      if (!isCreate && targetInfo) {
        formModel.value = {
          cluster_id: targetInfo.miner,
          domain: targetInfo.domain,
          machine_room: targetInfo.machine_room_id,
          note: targetInfo.note,
          owned_customer: targetInfo.client_id,
          sector_size: targetInfo.sector_size
        }
      }
    } else {
      form.resetFields()
    }
  }
)
</script>

<template>
  <a-modal
    :title="`${modalType}集群信息`"
    :visible="visible"
    @cancel="$emit('update:visible', false)"
    @ok="onSubmit(targetInfo?.id)"
  >
    <a-form :label-col="{ span: 5 }">
      <a-form-item label="集群ID" v-bind="form.validateInfos.cluster_id">
        <a-input v-model:value="formModel.cluster_id" />
      </a-form-item>
      <a-form-item label="所属客户" v-bind="form.validateInfos.owned_customer">
        <custom-select
          :data="clients"
          value-field="id"
          label-field="name"
          v-model:value="formModel.owned_customer"
        />
      </a-form-item>
      <a-form-item label="所在机房" v-bind="form.validateInfos.machine_room">
        <custom-select
          :data="roomList"
          value-field="id"
          label-field="name"
          v-model:value="formModel.machine_room"
        />
      </a-form-item>
      <a-form-item label="域名" v-bind="form.validateInfos.domain">
        <a-input v-model:value="formModel.domain" />
      </a-form-item>
      <a-form-item label="扇区大小" v-bind="form.validateInfos.sector_size">
        <custom-select :data="sectorSizeList" v-model:value="formModel.sector_size" />
      </a-form-item>
      <a-form-item label="备注">
        <a-input v-model:value="formModel.note" />
      </a-form-item>
    </a-form>
  </a-modal>
</template>
