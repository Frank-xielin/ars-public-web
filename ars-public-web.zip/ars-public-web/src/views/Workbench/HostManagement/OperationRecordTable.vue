<script lang="ts" setup>
import {
  columns,
  SearchForm,
  useOperationRecords
} from '@/composables/workbench/hostManagement/hostDetail'
import { FormRenderOptions } from '@/models/formRender'
import { DeviceOperationListItem } from '@/models/workbench/hostManagement'
import { pagerConfigs, scroller } from '@/utils/formTools'

const { dataSource, pageVo, searchModel, handleSearch } = useOperationRecords()

const formOp = (): FormRenderOptions<SearchForm, DeviceOperationListItem> => {
  return {
    queryParams: [
      {
        label: 'dates',
        type: 'date-picker',
        range: ['start_time', 'end_time'],
        itemStyle: { position: 'absolute', right: '210px' }
      },
      {
        label: 'key',
        type: 'search',
        placeholder: '输入关键字进行搜索',
        itemStyle: { position: 'absolute', right: 0 }
      }
    ],
    initialValues: { dates: undefined, end_time: '', start_time: '', key: '', sn: '' },
    pager: true,
    tableConfigs: {
      columns,
      tableProps: {
        style: 'margin-top: 30px',
        scroll: scroller(500),
        pagination: {
          ...pagerConfigs(pageVo.value),
          showTotal: (total: number) => `记录数: ${total}`
        }
      },
      async onSearch(values, vo) {
        searchModel.value = { ...values }
        await handleSearch(vo)
        return { res: dataSource.value, vo: pageVo.value }
      }
    }
  }
}
</script>

<template>
  <div class="operation-records">
    <form-render :op="formOp()" />
  </div>
</template>

<style scoped lang="less">
.operation-records {
  min-height: 670px;
}
</style>
