import useRequest from '@/common/useRequest'
import { useInitCurrentUserInfo } from '@/composables/layout'
import { CreateUserParams, UserInfoByIdRes } from '@/models/systemSettings/userManagement/user'
import {
  createUserApi,
  getUserInfoByIdApi,
  updateUserStatApi
} from '@/services/systemSettings/userManagement/user'
import { useMainStore } from '@/store'
import { RSAEncryption } from '@/utils/cryptage'
import { requestHandler } from '@/utils/formTools'
import { Form, message } from 'ant-design-vue'
import { inject, InjectionKey, Ref, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { requireInput, requireSelect } from '../../clusterInformation/addEditCluster'

const crypto = new RSAEncryption()
export const CreateUserKey: InjectionKey<Readonly<Ref<boolean>>> = Symbol('是否为新建页面')
const initialInfo: CreateUserParams = {
  owned_customer: 0,
  user_name: '',
  chinese_name: '',
  phone: '',
  email: '',
  organization_id: 0,
  password: 'ars@123456',
  leader: false,
  approve: false,
  enable: true
}
const rulesObj: Utils.RulesObject<CreateUserParams> = {
  user_name: [requireInput('用户名')],
  organization_id: [requireSelect('用户分组')],
  chinese_name: [requireInput('中文名')],
  owned_customer: [requireSelect('所属客户')],
  phone: [requireInput('手机号')],
  email: [requireInput('邮箱')]
}

export function useInitOperator() {
  const route = useRoute()
  const userInfo = ref<CreateUserParams>({ ...initialInfo })
  const username = ref('')
  const oldInfo = ref<UserInfoByIdRes | null>(null)
  const isCreate = inject(CreateUserKey)
  const rules = ref<Utils.RulesObject<CreateUserParams>>({})
  const form = Form.useForm(userInfo, rules)

  async function initUserInfo() {
    const { id } = route.query

    if (id != null && !isNaN(+id) && !isCreate?.value) {
      try {
        const reply = await getUserInfoByIdApi(+id)
        const { code, data, msg } = reply
        if (code === 0) {
          if (data) {
            username.value = data.user_name
            oldInfo.value = data
            userInfo.value = {
              owned_customer: data.client_id,
              user_name: data.user_name,
              chinese_name: data.nick_name,
              phone: data.phone,
              email: data.email,
              organization_id: data.user_group_id,
              password: '',
              leader: data.leader,
              approve: data.approve,
              enable: data.enable
            }
          }
        } else {
          message.error(msg)
        }
      } catch (e) {}
    }
  }

  initUserInfo()

  watch(
    () => isCreate?.value,
    create => {
      rules.value = create ? rulesObj : ({} as any)
    },
    { immediate: true }
  )

  return { userInfo, username, oldInfo, form, initUserInfo }
}

export function useEditUserInfo() {
  const store = useMainStore()
  const router = useRouter()
  const route = useRoute()
  const isEdit = ref(false)
  const isCreate = inject(CreateUserKey)
  const { userInfo, oldInfo, username, form, initUserInfo } = useInitOperator()
  const { initUserInfo: initSystemUser } = useInitCurrentUserInfo()

  const { run: createFetch } = useRequest(createUserApi, {
    onSuccess: reply => {
      requestHandler('创建用户成功')(reply)
      reply.code === 0 && router.push('/SystemSettings/UserManagement/User')
    }
  })
  const { run: updateFetch } = useRequest(updateUserStatApi, {
    onSuccess: (reply, [userId]) => {
      requestHandler('编辑用户成功')(reply)
      if (reply.code === 0) {
        isEdit.value = false
        initUserInfo()
        if (store.userInfo?.id === userId) {
          initSystemUser()
        }
      }
    }
  })

  async function onSubmit() {
    const { id } = route.query
    try {
      const params: CreateUserParams = {
        ...userInfo.value,
        password: userInfo.value.password ? crypto.encode(userInfo.value.password) || '' : ''
      }
      await form.validate()
      if (isCreate?.value) {
        createFetch(params)
      } else if (id && !isNaN(+id)) {
        updateFetch(+id, params)
      }
    } catch (e) {}
  }

  function onCancel() {
    if (isCreate?.value) {
      router.push('/SystemSettings/UserManagement/User')
    } else {
      isEdit.value = false
      userInfo.value.leader = oldInfo.value?.leader ?? false
      userInfo.value.approve = oldInfo.value?.approve ?? false
      userInfo.value.enable = oldInfo.value?.enable ?? false
    }
  }

  isEdit.value = !!isCreate?.value

  return { userInfo, oldInfo, username, isEdit, form, onCancel, onSubmit, initUserInfo }
}
