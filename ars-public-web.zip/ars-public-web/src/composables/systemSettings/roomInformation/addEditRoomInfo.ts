import { Form, message } from 'ant-design-vue'
import { ref } from 'vue'

import { ModalType } from '@/composables/workbench/errorRecord'
import { CreateRoomParams } from '@/models/systemSettings/roomInfomation'
import { createRoomApi, updateRoomApi } from '@/services/systemSettings/roomInfomation'

import { requireInput } from '../clusterInformation/addEditCluster'

const initialInfo: CreateRoomParams = {
  machine_name: '',
  machine_site: '',
  domain: '',
  note: '',
  scheduling: false
}

export function useEditRoomInfo(successFn: () => void) {
  const formModel = ref<CreateRoomParams>({ ...initialInfo })
  const rules = ref<Utils.RulesObject<CreateRoomParams>>({
    machine_name: [requireInput('机房名称')],
    machine_site: [requireInput('机房所在地')]
  })
  const form = Form.useForm(formModel, rules)

  async function handleSubmit(type: ModalType, id?: number) {
    try {
      await form.validate()
      const reply =
        type === '新建'
          ? await createRoomApi(formModel.value)
          : await updateRoomApi(id ?? -1, formModel.value)
      if (reply.code === 0) {
        message.success(`${type}机房信息成功`)
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { formModel, form, handleSubmit }
}
