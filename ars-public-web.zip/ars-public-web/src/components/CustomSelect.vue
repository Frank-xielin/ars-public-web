<script lang="ts" setup>
import { arrayType } from '@/utils/vue-tools/propTypes'
import { selectProps } from 'ant-design-vue/lib/select'
import { omit } from 'lodash-es'
import { mergeProps } from 'vue'

defineProps({
  ...selectProps(),
  data: arrayType<any>(),
  labelField: { type: String, default: 'label' },
  valueField: { type: String, default: 'value' },
  oneParameter: Boolean,
  notCircle: Boolean
})
</script>

<template>
  <a-select
    :class="['my-select-comp', { normal: notCircle }]"
    v-bind="
      mergeProps(
        $attrs,
        omit($props, ['data', 'labelField', 'valueField', 'oneParameter', 'notCircle'])
      )
    "
  >
    <template #suffixIcon>
      <svg
        class="icon"
        viewBox="0 0 1024 1024"
        version="1.1"
        xmlns="http://www.w3.org/2000/svg"
        p-id="5091"
        width="10"
        height="10"
        style="transform: translateY(-2px); font-size: 8px"
      >
        <path
          d="M601.244 786.18l332.827-399.558c41.074-49.31 34.415-122.594-14.874-163.685A116.142 116.142 0 0 0 844.825 196H179.172C115.012 196 63 248.033 63 312.22c0 27.188 9.528 53.515 26.926 74.402l332.827 399.557c41.074 49.31 114.328 55.972 163.617 14.88 5.398-4.5 10.376-9.48 14.874-14.88z"
          fill="#a7b1ca"
          p-id="5092"
        ></path>
      </svg>
    </template>
    <template v-if="!oneParameter">
      <a-select-option
        class="my-select-option"
        v-for="item in data"
        :key="item[valueField]"
        :value="item[valueField]"
      >
        {{ item[labelField] }}
      </a-select-option>
    </template>
    <template v-else>
      <a-select-option class="my-select-option" v-for="item in data" :value="item" :key="item">
        {{ item }}
      </a-select-option>
    </template>
  </a-select>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.my-select-comp {
  > * {
    font-size: 12px;
    color: @textColor_first;
  }

  .ant-select-selector {
    background: @bgClor_main !important;
    border: 1px solid @textColor_second !important;

    .ant-select-selection-search,
    .ant-select-selection-item {
      text-align: center;
    }
  }
}

.my-select-comp:not(.normal) {
  .ant-select-selector {
    border-radius: 30px !important;
  }
}

.my-select-option {
  .ant-select-item-option-content {
    text-align: center;
  }
}
</style>
