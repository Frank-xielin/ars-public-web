import { LoginLogListParams, LoginLogListRes } from '@/models/logManagement/loginLog'
import { request } from '@/utils/httpConfig'

/**
 * 登录日志（当前用户）
 * @param data
 * @returns
 */
export function loginLogListApi(data: LoginLogListParams) {
  return request<LoginLogListRes>({
    url: 'v5/public/log/login/get/list',
    method: 'GET',
    data
  })
}
