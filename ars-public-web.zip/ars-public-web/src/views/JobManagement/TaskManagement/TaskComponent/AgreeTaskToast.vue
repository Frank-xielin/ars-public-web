<script lang="ts" setup>
import { useApprovalRefuseProcess } from '@/composables/jobManagement/taskManagement/allTaskApi'
// 父组件传值
defineProps<{
  visible: boolean
  approvalId: number
}>()
// 传给父组件
const emit = defineEmits(['update:visible', 'handleOk'])

const { formModel, checkApprove } = useApprovalRefuseProcess(() => {
  emit('handleOk')
  emit('update:visible', false)
})
formModel.value.action = 'approve'
</script>

<template>
  <a-modal
    class="sumbitApprovalModal"
    :visible="visible"
    title="提示"
    @ok="checkApprove(approvalId)"
    okText="确定"
    @cancel="$emit('update:visible', false)"
    cancelText="取消"
    width="356px"
  >
    确认批准？
  </a-modal>
</template>
