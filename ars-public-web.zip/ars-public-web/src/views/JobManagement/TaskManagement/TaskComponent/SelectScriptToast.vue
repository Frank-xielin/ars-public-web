<script lang="ts" setup>
import { columns, useScriptAllList } from '@/composables/jobManagement/publishScript'
import { useGetScriptInfo } from '@/composables/jobManagement/publishScript/checkScript'
import { ScriptListItem } from '@/models/jobManagement/publishScript'
import { message } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { ref, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  selectTaskScp: ScriptListItem[]
}>()

const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'select', val: ScriptListItem[]): void
}>()
const selectTaskScpRows = ref<ScriptListItem[]>([])

// 拿到脚本内容
const { scriptInfo, getScriptById } = useGetScriptInfo()
async function onSubmit() {
  if (!selectTaskScpRows.value.length) {
    message.warn('至少选择一条数据！')
    return
  }
  await getScriptById(selectTaskScpRows.value[0].id)
  selectTaskScpRows.value[0].content = scriptInfo.value?.content ?? ''
  emit('select', selectTaskScpRows.value)
  emit('update:visible', false)
}

const newScriptColunms = ['脚本名称', '脚本类型', '版本号', '脚本描述']

function selectionHandlerScp(_: Utils.Key[], rows: ScriptListItem[]) {
  selectTaskScpRows.value = rows
}
const { searchModel, dataSource, searchScriptList, pageVo } = useScriptAllList()
searchModel.value.enabled = 1

watch(
  () => props.visible,
  nValue => {
    if (nValue) {
      searchScriptList()
      selectTaskScpRows.value = cloneDeep(props.selectTaskScp)
    } else {
      selectTaskScpRows.value.length = 0
    }
  }
)
</script>

<template>
  <a-modal
    title="选择脚本"
    :visible="visible"
    :width="1000"
    @cancel="$emit('update:visible', false)"
    :footer="null"
  >
    <a-table
      class="approvalTable contentDiv"
      v-bind="$tableConfigs(dataSource, false, pageVo)"
      :columns="$columnsSetter(columns.filter(col => newScriptColunms.includes(col.title)))"
      :scroll="$scroller('calc(100vh - 340px)')"
      row-key="id"
      :row-selection="
        $tableSelection({
          type: 'radio',
          selectedRowKeys: selectTaskScpRows.map(row => row.id),
          onChange: selectionHandlerScp
        })
      "
    >
      <template #bodyCell="{ text }">
        <custom-tooltip>
          <span>{{ text }}</span>
        </custom-tooltip>
      </template>
    </a-table>
    <footer class="footer-operation">
      <a-button class="footer-operation__cancel" @click="$emit('update:visible', false)">
        取消
      </a-button>
      <a-button type="primary" @click="onSubmit">确认</a-button>
    </footer>
  </a-modal>
</template>

<style lang="less" scoped>
.footer-operation {
  padding: 20px 0 20px !important;
  display: flex;
  justify-content: flex-end;
  &__cancel {
    margin-right: 18px;
  }
}
</style>
