export interface ClientListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string
  name: string
  note: string
}

export type ClientListAllRes = ClientListItem[]

export interface ClientListRes extends Utils.PageVO {
  list: ClientListItem[]
}

export interface CreateClientParams {
  name: string
  note: string
}

export type UpdateClientParams = CreateClientParams
