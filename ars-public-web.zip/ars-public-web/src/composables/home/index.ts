import { assetsInfoApi, clusterCountApi, deviceCountApi } from '@/services/home'
import { useMainStore } from '@/store'
import { message } from 'ant-design-vue'
import { computed, onMounted, ref } from 'vue'

export function useGetUserAssetsInfo() {
  // 初始化
  const assetsInfo = ref({
    cluster: 0,
    device: 0,
    power: '0',
    asset: '0'
  })

  // 通过接口异步获取数据
  async function initAssetsInfo() {
    try {
      clusterCountApi().then(reply =>
        assetsHandle(reply, () => (assetsInfo.value.cluster = reply.data || 0))
      )
      deviceCountApi().then(reply =>
        assetsHandle(reply, () => (assetsInfo.value.device = reply.data || 0))
      )
      assetsInfoApi().then(reply =>
        assetsHandle(reply, () => {
          assetsInfo.value.power = reply.data?.total_power || '0'
          assetsInfo.value.asset = reply.data?.total_fil || '0'
        })
      )
    } catch (e) {}
  }
  // 返回结果处理和报错逻辑
  function assetsHandle(reply: Utils.Result<any>, callback: () => void) {
    const { code, msg } = reply
    if (code === 0) {
      callback()
    } else {
      message.error(msg)
    }
  }

  return { assetsInfo, initAssetsInfo }
}

/** tab 页动态控制 */
export const useTabDynamicGenerate = () => {
  const activeKey = ref('1')

  // 首页显示
  const store = useMainStore()
  const showPeddingApproval = computed(() => store.userInfo?.approve)

  /** tab栏数字显示 */
  const pOrsNumber = ref(0) // 待办剩几条
  const pOrsNumberTwo = ref(0) // 已提交剩几条
  const pOrsNumberThree = ref(0) // 未读消息有几条
  function handlePorSnumber(val: number) {
    pOrsNumber.value = val
  }
  function handlePorSnumberTwo(val: number) {
    pOrsNumberTwo.value = val
  }
  function handlePorSnumberThree(val: number) {
    pOrsNumberThree.value = val
  }

  onMounted(() => {
    if (!showPeddingApproval.value) {
      activeKey.value = '2'
    }
  })

  return {
    showPeddingApproval,
    activeKey,
    pOrsNumber,
    pOrsNumberTwo,
    pOrsNumberThree,
    handlePorSnumber,
    handlePorSnumberTwo,
    handlePorSnumberThree
  }
}
