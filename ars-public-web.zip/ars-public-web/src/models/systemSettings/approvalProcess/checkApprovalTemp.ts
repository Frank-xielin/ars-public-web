import { ApprovalTempListItem } from './'
import { CreateApprovalTempParams } from './createApprovalTemp'

export type GetApprovalTempRes = ApprovalTempListItem

export type UpdateApprovalTempParams = CreateApprovalTempParams

export type UpdateApprovalTempRes = ApprovalTempListItem
