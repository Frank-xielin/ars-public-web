<script lang="ts" setup>
import { colors } from '@/composables/jobManagement/taskManagement/allTaskApi'
import { softwareList } from '@/composables/workbench/hostManagement/index'
import { ViewTaskRes } from '@/models/jobManagement/taskManagement'
const props = defineProps<{
  viewData: ViewTaskRes | null
}>()

// const devicesList = props.viewData?.devices.split('')
</script>

<template>
  <div class="taskdetail">
    <h3 class="big__title">任务详情</h3>
    <div class="taskdetail__content">
      <h5 class="taskdetail__content__target">任务名称：&emsp;{{ viewData?.name }}</h5>
      <div class="taskdetail__content__target taskdetail__target">
        <h5>目标主机：&emsp;</h5>
        <div class="deviceList">
          <span v-for="item in viewData?.device_list" :key="item.device_sn">
            {{ item?.device_sn }}({{
              softwareList.find(type => item.software_type === type.value)?.label
            }})
          </span>
          <!-- <span v-for="item in viewData?.devices.split(',')" :key="item.length">{{ item }}</span> -->
        </div>
      </div>
      <h5 class="number">&emsp;数量：{{ viewData?.device_list.length || 0 }}&emsp;</h5>
      <h5 class="taskdetail__content__target">申请人：&emsp;{{ viewData?.creator }}</h5>
      <h5 class="taskdetail__content__target">创建时间：&emsp;{{ viewData?.created_at }}</h5>
      <h5 class="taskdetail__content__target" style="display: flex; align-items: center">
        状态：&emsp;
        <a-tag id="Atag" :color="colors.find(item => item.id === viewData?.state)?.color">
          {{ colors.find(item => item.id === viewData?.state)?.text }}
        </a-tag>
      </h5>
      <h5 class="taskdetail__content__target">备注：&emsp;{{ viewData?.note }}</h5>
      <template v-if="viewData?.state === 4">
        <h5 class="taskdetail__content__target">发布人：&emsp;{{ viewData?.publish_name }}</h5>
        <h5 class="taskdetail__content__target">发布时间：&emsp;{{ viewData?.published_at }}</h5>
      </template>
    </div>
  </div>
  <div class="scriptContent">
    <div class="scriptContent__title">
      <h5>脚本内容：&emsp;</h5>
      <div class="scriptContent__content">
        {{ viewData?.script_content }}
      </div>
    </div>
    <h5 class="scriptContent__title">脚本参数：&emsp;{{ viewData?.script_params }}</h5>
    <h5 class="scriptContent__title">超时时常：&emsp;{{ viewData?.timeout }} s</h5>
    <h5 class="scriptContent__title">执行帐号：&emsp;{{ viewData?.exec_user }}</h5>
  </div>
</template>

<style lang="less" scoped>
@import (reference) '@/assets/styles/index.less';
.taskdetail {
  background-color: #fff;
  padding: 17px 36px 48px 36px !important;
  min-width: 800px;
  &__target {
    display: flex;
    // flex-direction: row;
    min-width: 500px;

    .deviceList {
      border: 1px solid #cbcbcb;
      width: 220px;
      height: 76px;
      display: flex;
      flex-direction: column;
      padding: 8px !important;
      overflow: hidden auto;
      margin-right: 8px;
      text-align: center;
      span {
        width: 120px;
        // word-wrap: break-word;
        margin-bottom: 4px;
      }
    }
  }
  &__content {
    // min-width: 1280px;
    padding: 24px 493px 0 170px;
    .number {
      // display: flex;
      // align-items: flex-end;
      margin: 0;
      margin-bottom: 25px !important;
      margin-left: 69px;
    }

    &__title {
      margin: 0;
    }
    &__target {
      margin-bottom: 20px !important;
    }
  }
}
.scriptContent {
  position: absolute;
  top: 185px;
  left: 57%;
  &__title {
    display: flex;
    margin-bottom: 27px;
  }
  &__content {
    padding: 4px;
    width: 300px;
    max-height: 200px; //超过200px执行如下滚动
    overflow: hidden auto;
    line-height: 15px;
    border: 0px solid #cbcbcb;
  }
}

&:not(#Atag, .wrapper__headDiv > .agreement) {
  color: @textColor_first !important;
  font-size: 14px;
}
@media screen and(max-width:1280px) {
  .taskdetail {
    &__content {
      padding: 24px 493px 0 140px;
    }
  }
}
</style>
