import { requireSelect } from '@/composables/systemSettings/clusterInformation/addEditCluster'
import {
  GetAnsibleExecParams,
  PublishTemplateParams
} from '@/models/jobManagement/commandExecution'
import { ansibleExecResultApi, publishTemplateApi } from '@/services/jobManagement/commandExecution'
import { Form, message } from 'ant-design-vue'
import { omit } from 'lodash-es'
import { ref } from 'vue'

interface FormModel extends PublishTemplateParams {
  id?: number
}

const rulesObj = (): Utils.RulesObject<FormModel> => {
  return {
    miner_id: [requireSelect('目标集群')],
    device_ids: [requireSelect('执行主机')],
    id: [requireSelect('执行命令')]
  }
}

/** 执行命令 */
export function useCommandExec() {
  const commandUuid = ref('')
  const execResult = ref<string>('')
  const execCompleted = ref(false)
  const formModel = ref<FormModel>({ miner_id: '', device_ids: [], id: undefined })
  const rules = ref<Utils.RulesObject<FormModel>>(rulesObj())
  const form = Form.useForm(formModel, rules)

  async function startCommand() {
    try {
      await form.validate()

      const reply = await publishTemplateApi(formModel.value.id ?? 0, omit(formModel.value, ['id']))
      const { code, data, msg } = reply
      if (code === 0 && data) {
        commandUuid.value = data.uuid
        execCompleted.value = true
        getExecList()
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  async function getExecList() {
    try {
      const params: GetAnsibleExecParams = {
        uuid: commandUuid.value,
        page: 1,
        page_size: 20
      }
      const reply = await ansibleExecResultApi(params)
      const { code, data, msg } = reply
      if (code === 0) {
        if (data?.includes('执行中')) {
          setTimeout(() => {
            getExecList()
          }, 3000)
        }
        execResult.value = data || ''
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { execResult, form, execCompleted, formModel, commandUuid, startCommand, getExecList }
}
