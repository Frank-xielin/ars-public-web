<script lang="ts" setup>
import { useEnableScript } from '@/composables/jobManagement/publishScript'
import { useGetScriptInfo } from '@/composables/jobManagement/publishScript/checkScript'
import router from '@/router'
import { dateFormatter } from '@/utils/dateFormat'
import { ref } from 'vue'
import { useRoute } from 'vue-router'
import ScriptEditor, { ScriptEditorExpose } from './ScriptEditor.vue'

const formRef = ref<ScriptEditorExpose>()
const route = useRoute()
const { scriptInfo, scriptId, isEdit, initScriptInfo } = useGetScriptInfo()
const { enableScript } = useEnableScript(initScriptInfo)

function formatter(date = '') {
  return dateFormatter(date, 'YYYY年MM月DD日 HH:mm')
}
function submitForm() {
  formRef.value?.onSubmitForm(scriptId.value)
}
function onCancel() {
  const { type } = route.query
  if (type === 'edit') {
    router.push('/JobManagement/PublishScript')
  } else {
    isEdit.value = false
  }
}

initScriptInfo()
</script>

<template>
  <div class="check-script page" :class="{ 'check-mode': !isEdit }">
    <div class="content-wrapper top">
      <h2 v-show="isEdit" class="page-title">编辑脚本</h2>
      <div class="operation-top">
        <template v-if="!isEdit">
          <a-button @click="isEdit = true" :disabled="scriptInfo?.enabled || !$auth(99)">
            编辑
          </a-button>
          <a-button @click="enableScript(scriptId, !scriptInfo?.enabled)" :disabled="!$auth(103)">
            {{ scriptInfo?.enabled ? '停用' : '启用' }}
          </a-button>
        </template>
        <template v-else>
          <a-button type="primary" @click="submitForm">保存</a-button>
          <a-button @click="onCancel">取消</a-button>
        </template>
      </div>
    </div>

    <div v-show="!isEdit" class="content-wrapper">
      <h3 class="form-title">脚本基本信息</h3>
      <a-form class="script-edit-form" layout="inline" :wrapper-col="{ span: 13 }">
        <a-form-item label="脚本类型">
          <span>{{ scriptInfo?.script_type }}</span>
        </a-form-item>
        <a-form-item label="版本号">
          <span>{{ scriptInfo?.version }}</span>
        </a-form-item>
        <a-form-item label="脚本名称">
          <span>{{ scriptInfo?.script_name }}</span>
        </a-form-item>
        <a-form-item label="启用">
          <a-checkbox disabled :checked="scriptInfo?.enabled" />
        </a-form-item>
        <a-form-item label="脚本内容" :wrapper-col="{ span: 24 }">
          <a-textarea style="width: 625px; height: 200px" :value="scriptInfo?.content" />
        </a-form-item>
        <a-form-item></a-form-item>
        <a-form-item label="脚本描述">
          <span>{{ scriptInfo?.note }}</span>
        </a-form-item>
      </a-form>
    </div>
    <script-editor v-show="isEdit" ref="formRef" :model="scriptInfo" type="edit" />

    <div v-show="!isEdit" class="content-wrapper">
      <div class="form-title">系统信息</div>
      <a-row class="sys-info">
        <a-col :span="12">
          <span class="label">创建人:</span>
          <span class="name">{{ scriptInfo?.creator }}</span>
          <span class="time">{{ formatter(scriptInfo?.created_at) }}</span>
        </a-col>
        <a-col :span="12">
          <span class="label">最近修改:</span>
          <span class="name">{{ scriptInfo?.updater }}</span>
          <span class="time">{{ formatter(scriptInfo?.updated_at) }}</span>
        </a-col>
      </a-row>
    </div>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.check-mode {
  padding: 0 !important;
  background: @backDivColor;
  .content-wrapper.top {
    padding-top: 27px;
  }
}
.page-title {
  padding: 0 0 11px;
  margin: 0 36px 45px;
  font-size: 14px;
  font-weight: bold;
  border-bottom: 1px solid @ueColor_fifth;
}
.content-wrapper {
  padding-bottom: 27px;
  margin-bottom: 10px;
  background: #fff;
}
.operation-top {
  display: flex;
  justify-content: center;
  > button {
    width: 170px;
    margin: 0 10px;
  }
}
.form-title {
  margin: 0 36px 24px;
  padding: 11px 0;
  font-size: 14px;
  font-weight: bold;
  border-bottom: 1px solid @ueColor_fifth;
}
.script-edit-form {
  width: 80%;
  margin: auto;
  :deep(.ant-form-item) {
    width: 45%;
    min-height: 56px;
    margin-bottom: 5px;
    &.ant-form-item-with-help {
      margin-bottom: 5px;
    }
    .ant-form-item-label {
      min-width: 80px;
    }
  }
}
.sys-info {
  width: 80%;
  margin: 0 auto 48px;
  .ant-col {
    span {
      margin-right: 20px;
      font-size: 14px;
    }
  }
}
</style>
