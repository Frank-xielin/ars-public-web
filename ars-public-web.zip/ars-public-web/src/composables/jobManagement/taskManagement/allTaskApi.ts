import { useApprovalToast } from '@/composables/home/approvalToast'
import {
  ApprovalTaskParams,
  GetApprovalInfoRes,
  ViewTaskRes
} from '@/models/jobManagement/taskManagement'
import router from '@/router'
import {
  achieveApprovalApi,
  approvalTaskApi,
  getApprovalInfoIApi,
  publishTaskApi,
  submitTaskApi,
  viewTasktApi
} from '@/services/jobManagement/taskManagement'
import { message } from 'ant-design-vue'
import { ref } from 'vue'
import { useRoute } from 'vue-router'

export const colors = [
  { text: '待提交', color: 'purple', id: 0 },
  { text: '待审核', color: 'blue', id: 1 },
  { text: '审核失败', color: 'red', id: 2 },
  { text: '审核通过,待发布', color: 'cyan', id: 3 },
  { text: '已发布', color: 'yellow', id: 4 }
]

/** 查看任务 单个 */
export function useViewTask() {
  const route = useRoute()
  const taskId = ref(0)
  const isEdit = ref(false)
  const viewData = ref<ViewTaskRes | null>(null)
  // 拿到审批后表格数据（同操作审批弹窗接口，他们是同一个接口）
  const { dataSource, handleSearch } = useApprovalToast()
  const { approvalId, achieveApprovalId } = useAchieveApprovalId(() =>
    handleSearch(approvalId.value)
  )
  async function getViewInfo() {
    try {
      const reply = await viewTasktApi(taskId.value)
      const { code, data, msg } = reply
      if (code === 0 && data) {
        viewData.value = data
        achieveApprovalId(taskId.value)
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  // 初始化
  function initViewTask() {
    const { id, type } = route.query
    if (!id || isNaN(+id)) {
      message.warn('任务ID不存在')
      router.push('/JobManagement/TaskManagement')
      return
    }
    if (type === 'edit') {
      isEdit.value = true
    }
    taskId.value = +id
    getViewInfo()
  }

  return { viewData, isEdit, taskId, initViewTask, approvalId, getViewInfo, dataSource }
}

// 获取审批流ID
function useAchieveApprovalId(successFn: () => void) {
  const approvalId = ref<number>(0)
  async function achieveApprovalId(id: number) {
    try {
      const reply = await achieveApprovalApi(id)
      const { code, data, msg } = reply
      if (code === 0 && data) {
        if (data?.list.length > 0) {
          approvalId.value = data.list[0].id
          successFn()
        }
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }
  return { approvalId, achieveApprovalId }
}

/** 任务提交审核 单个 */
export function useSubmitTask(successFn: () => void) {
  async function submitTask(id: number, auto: boolean) {
    try {
      const reply = await submitTaskApi(id, auto)
      const { code, msg } = reply

      // 开始提交审核
      if (code === 0) {
        message.success(' 提交审核成功')
        successFn()
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }
  return { submitTask }
}

/** 发布任务 单个 */
export function usePublishResult() {
  async function pbTaskResult(id: number) {
    try {
      const reply = await publishTaskApi(id)
      const { code, data, msg } = reply
      if (code === 0 && data) {
        message.success('发布成功')
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { pbTaskResult }
}

/** 批准/拒绝审批流 */
export function useApprovalRefuseProcess(successFn: () => void) {
  const formModel = ref<ApprovalTaskParams>({ action: 'approve', note: '' })
  async function checkApprove(id: number) {
    try {
      const reply = await approvalTaskApi(id, formModel.value)
      if (reply.code === 0) {
        message.success('操作成功')
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }
  return { formModel, checkApprove }
}

/** 审批流获取，单个。拿到当前处理人 */
export function useApprovalInfo() {
  const approveInfo = ref<GetApprovalInfoRes | null>(null)

  async function getApprovalInfo(id: number) {
    try {
      const reply = await getApprovalInfoIApi(id)
      const { code, data, msg } = reply
      if (code === 0 && data) {
        approveInfo.value = data
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { approveInfo, getApprovalInfo }
}
