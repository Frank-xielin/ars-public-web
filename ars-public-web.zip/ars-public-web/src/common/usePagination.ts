import { pagerSetter } from '@/utils/formTools'
import { ref } from 'vue'

export function usePagination(initialValue?: Utils.PageVO) {
  const pageVo = ref<Utils.PageVO>(initialValue ?? { page: 1, page_size: 20, total: 0 })

  function setPageFromData<T extends Utils.PageVO>(vo?: T | null) {
    if (vo) {
      pageVo.value = pagerSetter(vo)
    }
  }

  return { pageVo, setPageFromData }
}
