import { JSEncrypt } from 'jsencrypt'

const pubblica = `-----BEGIN PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAyYz+Q+dh+8ZNqzetthqA
CQW7bzAklGVqQb7DIeu5uAvMdowO0q/dNg+HLaUmTb4auA6tdN2MQa5/SzloE2qx
LFCx9itHuUXbKIVIApr+98R8f11S0GvNX1PVtSbActrWQnjpgXt1Agu9pyX1YNwx
sXi6MBYobKMcyXetSazkXXePZw+Um5/cCycVlBH56NlKXGSlRU4xw20H5iiDJX7K
1eR5K1eBrAdDkvxJX0IW+B3hpimLfNQM9gNhAikDaI/hz+my4M9YWSWq9aelCOro
l3sbOat7IHeSBzWAi8cLxke50c1oCdoDIqPvrOmj/GDZ8ZHBgiFZgBQpS6IPqPPl
qDm86RTxyHz9clhgctjPEXbBGEszq79KpL6oDUjOkpmFOXNl1SnEEOWf71pC7hHv
WR32JoSiZlDGipakgQciNVQl5OjWUXvHPKlyD1N784F8vZcEhCEGTR1P+eDyEWhb
wHVusjZlrZ1Sv3Owro77BUSq4N6yDkvmpolY/2xrZuVZtiH1SO1yEPk6Qlnp8FH4
uaMXBYmaX82ZJaJj8UFyHY0ZYYMJrWH93ExQ2cS4jH2tzo1V0KFncFloN6FeeX3b
s9gN6up721L2EzXLhBWqDc7ZI3cSAz9CD6IEgTikGpQHBbAtIYGXY3ee3ksrQwrS
+GD8Y8XPb3tmO1j8lDv2MRMCAwEAAQ==
-----END PUBLIC KEY-----`

export class RSAEncryption {
  private encrypt: JSEncrypt

  /**
   * 使用对应公钥生成加密工具
   * @param pub 加密的公钥，默认为密码公钥
   */
  constructor(pub?: string) {
    this.encrypt = new JSEncrypt()
    this.encrypt.setPublicKey(pub || pubblica)
  }

  /**
   * 加密
   * @param val
   * @returns
   */
  encode(val: string) {
    return this.encrypt.encrypt(val)
  }

  /**
   * 解密
   * @param val
   * @returns
   */
  decode(val: string) {
    return this.encrypt.decrypt(val)
  }
}
