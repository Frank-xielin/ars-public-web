<script lang="ts" setup>
import { useAllClientList } from '@/composables/systemSettings/clientInformation'
import {
  userCols,
  useUserManager
} from '@/composables/systemSettings/userManagement/user/userManageTab'
import { RoleListItem } from '@/models/systemSettings/userManagement/role'
import { UserListItem } from '@/models/systemSettings/userManagement/user'
import { useRouter } from 'vue-router'
import UserLinkClusters from './UserLinkClusters.vue'
import UserLinkRoles from './UserLinkRoles.vue'

const router = useRouter()

const { dataSource: clientList, getAllClients } = useAllClientList()
const {
  loading,
  pageVo,
  dataSource,
  searchModel,
  rolesShow,
  minersShow,
  selectedUser,
  handleSearch
} = useUserManager(() => {
  getAllClients()
})

function checkOrAddUser(type: 'create' | 'check', id?: number) {
  router.push({
    path: '/SystemSettings/UserManagement/User/UserSetting',
    query: { type, id }
  })
}

function userLinked(record: UserListItem, type: 'role' | 'miner') {
  selectedUser.value = record
  if (type === 'role') {
    rolesShow.value = true
  } else {
    minersShow.value = true
  }
}
/**
 * 展示多个角色名称
 * @param roles 角色信息列表
 */
function getCorrectRoles(roles: RoleListItem[] | null) {
  return roles?.map(role => role.name).join(', ')
}
</script>

<template>
  <div class="user-manage-tab">
    <a-form layout="inline">
      <a-form-item>
        <custom-select
          style="width: 100px"
          :data="clientList"
          v-model:value="searchModel.client_id"
          value-field="id"
          label-field="name"
          @change="handleSearch()"
        />
      </a-form-item>
      <a-form-item label="用户">
        <custom-search-input
          v-model:value="searchModel.user"
          placeholder="输入用户名进行搜索"
          @search-func="handleSearch()"
        />
      </a-form-item>

      <a-form-item class="right-operator">
        <a-button
          :disabled="!$auth(56)"
          style="width: 110px"
          type="primary"
          shape="round"
          @click="checkOrAddUser('create')"
        >
          新建
        </a-button>
      </a-form-item>
    </a-form>

    <a-table
      class="table-box"
      v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
      row-key="id"
      :columns="$columnsSetter(userCols)"
      :scroll="$scroller('calc(100vh - 430px)')"
    >
      <template #bodyCell="{ column: col, text, record }">
        <div v-if="col.title === '操作'">
          <a-button type="link" class="table-btn" @click="checkOrAddUser('check', record.id)">
            查看
          </a-button>
          <a-button
            type="link"
            v-if="text > 3"
            :disabled="!$auth(58)"
            class="table-btn"
            @click="userLinked(record, 'role')"
          >
            关联角色
          </a-button>
          <a-button
            type="link"
            :disabled="!$auth(59)"
            class="table-btn"
            @click="userLinked(record, 'miner')"
          >
            关联集群
          </a-button>
        </div>
        <span v-else-if="['启用', 'Leader', '参与审批'].includes(col.title)">
          <icon-font v-if="text" type="iconicon_gou" />
        </span>
        <custom-tooltip v-else>
          <span v-if="col.title === '所属客户'">{{ text?.name }}</span>
          <span v-else-if="col.title === '分组'">{{ text?.name }}</span>
          <span v-else-if="col.title === '角色'">{{ getCorrectRoles(text) }}</span>
          <span v-else>{{ text }}</span>
        </custom-tooltip>
      </template>
    </a-table>

    <user-link-roles
      :record="selectedUser"
      v-model:visible="rolesShow"
      @search="handleSearch(pageVo)"
    />
    <user-link-clusters
      :record="selectedUser"
      v-model:visible="minersShow"
      @search="handleSearch(pageVo)"
    />
  </div>
</template>

<style scoped lang="less">
.right-operator {
  position: absolute;
  right: 20px;
}
</style>
