// 此处配置 antd 组件的全局设置
import { Spin } from 'ant-design-vue'

import LoadingImageVue from './LoadingImage.vue'

Spin.setDefaultIndicator({ indicator: <LoadingImageVue /> })
