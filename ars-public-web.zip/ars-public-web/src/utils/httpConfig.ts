import { message, Modal } from 'ant-design-vue'
import axios, { AxiosError, AxiosRequestConfig, AxiosResponse, Canceler } from 'axios'
import Cookies from 'js-cookie'
import { isNil } from 'lodash-es'
import nProgress from 'nprogress'

import config, { EnvTypes } from '@/config'
import { useMainStore } from '@/store'

import { clearAccountInfo } from './auth'
import { errorHandler } from './errorHandler'
import generateUUID from './generateUUID'
import { storageKeys } from './storage/storageList'

export interface IAxiosOptions extends AxiosRequestConfig {
  noModal?: boolean
  /** 是否需要全局的加载效果（默认不开启） */
  loading?: boolean
  /** 是否需要启用独立的接口 mock（与 baseURL 同时设置时不生效） */
  mock?: boolean
  /** 是否不随页面改变而取消请求 */
  noCancel?: boolean
}

export interface LoadStateObj {
  status: boolean
  key: string
}

nProgress.configure({ showSpinner: false })
const pendingMap = new Map<string, Canceler>()
/** 终止所有未完成的请求 */
export const removeAllPending = () => {
  pendingMap.forEach(cancel => {
    cancel()
  })
  pendingMap.clear()
  nProgress.done()
}

/**
 * 判断是否需要使用 mock 数据
 * @param isMock 是否启用 mock
 * @returns
 */
const isMockApi = (isMock?: boolean) => {
  const { mock, mockApi, baseApi, env } = config
  let correctApi = ''
  if (env === EnvTypes.PROD) {
    // 线上禁用 mock
    correctApi = baseApi
  } else if (!isNil(isMock)) {
    correctApi = isMock ? mockApi : baseApi
  } else {
    correctApi = mock ? mockApi : baseApi
  }
  return correctApi
}

let count = 0
/**
 * 封装的请求函数
 * @param options
 */
export const request = async <T = null>(options: IAxiosOptions) => {
  const store = useMainStore()
  const token = Cookies.get(storageKeys.token)
  const { noModal, loading, noCancel, headers, baseURL, mock, ...others } = options

  if (['get', 'GET'].includes(others.method || 'get') && !others.params && others.data) {
    others.params = others.data
  }

  // 使用 UUID 标识单个请求
  const key = generateUUID()
  if (!noCancel) {
    options.cancelToken = new axios.CancelToken(c => pendingMap.set(key, c))
  }
  if (!count) {
    nProgress.start()
  } else {
    const progress = 1 - (count + 1) / 10
    nProgress.set(progress > 1 ? 1 : progress)
  }
  count++
  // 默认不提供 loading 效果
  loading && store.changeLoading({ status: true, key })

  try {
    const reply = (await axios({
      ...others,
      baseURL: baseURL ?? isMockApi(mock),
      headers: { ...headers, Authorization: 'Bearer ' + token }
    })) as AxiosResponse<Utils.Result<T>>

    if (reply.data.code === 199) {
      clearAccountInfo()
      message.error('登录信息失效')
      throw new Error('abort')
    }
    return reply.data
  } catch (error: any) {
    const err = error as AxiosError
    if (!noModal && err.message && !err.message.toLowerCase().includes('abort')) {
      Modal.destroyAll()
      Modal.error({ content: errorHandler(err.message) })
    }
    throw err
  } finally {
    pendingMap.delete(key)
    !noCancel && progressBarController()
    loading && store.changeLoading({ status: false, key })
  }
}

/**
 * 下载文件专用请求函数
 * @param options
 * @returns
 */
export const fileRequest = async (options: IAxiosOptions) => {
  const configs: IAxiosOptions = { ...options, responseType: 'blob' }
  const result = (await request(configs)) as Utils.Result | Blob
  return result
}

const progressBarController = () => {
  count--
  // 顶部进度条设置
  if (count <= 0) {
    nProgress.done()
    count = 0
  } else {
    const progress = 1 - count / 10
    nProgress.set(progress > 1 ? 1 : progress)
  }
}
