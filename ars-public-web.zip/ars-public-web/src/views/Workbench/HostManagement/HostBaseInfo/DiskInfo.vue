<script lang="ts" setup>
import {
  diskColumns,
  HostBaseInfoKey,
  storageConversion,
  useDiskInfoChart
} from '@/composables/workbench/hostManagement/hostDetail'
import { computed, inject } from 'vue'

const baseInfo = inject(HostBaseInfoKey)

const diskList = computed(() => baseInfo?.value.disk_list || [])

const { chartsEl } = useDiskInfoChart()
</script>

<template>
  <div class="disk-info">
    <h3 class="title">我的磁盘（{{ diskList.length }}）</h3>
    <div class="chart" ref="chartsEl"></div>
    <a-table
      style="width: 491px"
      :data-source="diskList"
      :scroll="$scroller(230)"
      :columns="$columnsSetter(diskColumns)"
      :pagination="false"
      size="small"
      bordered
    >
      <template #bodyCell="{ column, index, text }">
        <span v-if="column.title === '序号'">{{ index + 1 }}</span>
        <span v-else-if="['存储空间', '已使用'].includes(column.title)">
          {{ text ? `${(text / storageConversion).toFixed(2)} G` : text }}
        </span>
      </template>
    </a-table>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.disk-info {
  display: flex;
  flex-direction: column;
  align-items: center;
  .title {
    width: 491px;
    height: 19px;
    margin-bottom: 15px;
    font-size: 14px;
    color: @textColor_first;
  }
  .chart {
    width: 491px;
    height: 230px;
  }
  :deep(.ant-table-small .ant-table-thead > tr > th) {
    background: #fff;
  }
}
</style>
