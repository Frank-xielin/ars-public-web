<script lang="ts" setup>
import { useAllClientList } from '@/composables/systemSettings/clientInformation'
import { useUserGroupManager } from '@/composables/systemSettings/userManagement/user/userGroupManageTab'
import { useEditUserInfo } from '@/composables/systemSettings/userManagement/userSetting'

const { userInfo, form, onCancel, onSubmit } = useEditUserInfo()
const { clients, getAllClients } = useAllClientList()
const { dataSource: groupList, handleSearch: searchGroups } = useUserGroupManager()

getAllClients().then(() => {
  userInfo.value.owned_customer = clients.value[0]?.id ?? 0
})
searchGroups({ page: 1, page_size: 10000 }).then(() => {
  userInfo.value.organization_id = groupList.value[0]?.id ?? 0
})
</script>

<template>
  <div class="create-user">
    <h2 class="operate-title">
      <span>新建用户</span>
    </h2>
    <div class="operator-wrapper">
      <a-button :disabled="!$auth(56)" size="middle" type="primary" @click="onSubmit">
        保存
      </a-button>
      <a-button size="middle" @click="onCancel">取消</a-button>
    </div>

    <h3 class="form-title">用户管理</h3>
    <a-form class="user-edit-form" layout="inline" :wrapper-col="{ span: 13 }">
      <a-form-item label="用户名" v-bind="form.validateInfos.user_name">
        <a-input v-model:value="userInfo.user_name" />
      </a-form-item>
      <a-form-item label="分组" v-bind="form.validateInfos.organization_id">
        <custom-select
          :data="groupList"
          value-field="id"
          label-field="name"
          v-model:value="userInfo.organization_id"
        />
      </a-form-item>
      <a-form-item label="中文名" v-bind="form.validateInfos.chinese_name">
        <a-input v-model:value="userInfo.chinese_name" />
      </a-form-item>
      <a-form-item label="所属客户" v-bind="form.validateInfos.owned_customer">
        <custom-select
          :data="clients"
          label-field="name"
          value-field="id"
          v-model:value="userInfo.owned_customer"
        />
      </a-form-item>
      <a-form-item label="手机号" v-bind="form.validateInfos.phone">
        <a-input v-model:value="userInfo.phone" />
      </a-form-item>
      <a-form-item label="Leader">
        <a-checkbox v-model:checked="userInfo.leader" />
      </a-form-item>
      <a-form-item label="邮箱" v-bind="form.validateInfos.email">
        <a-input type="email" v-model:value="userInfo.email" />
      </a-form-item>
      <a-form-item label="参与审批">
        <a-checkbox v-model:checked="userInfo.approve" />
      </a-form-item>
      <a-form-item label="密码">
        <a-input-password v-model:value="userInfo.password" disabled :visibility-toggle="false" />
      </a-form-item>
      <a-form-item label="启用">
        <a-checkbox v-model:checked="userInfo.enable" />
      </a-form-item>
    </a-form>
  </div>
</template>
