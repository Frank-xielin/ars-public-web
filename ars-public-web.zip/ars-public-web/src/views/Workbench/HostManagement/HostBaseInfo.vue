<script lang="ts" setup>
import { ref } from 'vue'
import BaseInfo from './HostBaseInfo/BaseInfo.vue'
import DiskInfo from './HostBaseInfo/DiskInfo.vue'
import NetworkInfo from './HostBaseInfo/NetworkInfo.vue'

const activeRadio = ref('base')
</script>

<template>
  <div class="host-base-info">
    <a-radio-group class="radio-group-tab" v-model:value="activeRadio" button-style="solid">
      <a-radio-button value="base">基本信息</a-radio-button>
      <a-radio-button value="disk">磁盘信息</a-radio-button>
      <a-radio-button value="network">网络配置</a-radio-button>
    </a-radio-group>
    <div class="tab-content">
      <base-info v-if="activeRadio === 'base'" />
      <disk-info v-if="activeRadio === 'disk'" />
      <network-info v-if="activeRadio === 'network'" />
    </div>
  </div>
</template>

<style scoped lang="less">
.host-base-info {
  position: relative;
  min-height: 670px;
  .radio-group-tab {
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
  }
  .tab-content {
    position: absolute;
    top: 100px;
    width: 100%;
  }
}
</style>
