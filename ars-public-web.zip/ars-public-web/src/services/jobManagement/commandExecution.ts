import {
  GetAnsibleExecParams,
  PublishTemplateParams,
  PublishTemplateRes
} from '@/models/jobManagement/commandExecution'
import { request } from '@/utils/httpConfig'

/**
 * 公共模板发布 - 单个
 * @param id 目标模板 id
 * @param data 需要执行的机器信息
 * @returns 根据返回的 UUID 在「ansible 执行结果」接口里查执行结果
 */
export function publishTemplateApi(id: number, data: PublishTemplateParams) {
  return request<PublishTemplateRes>({
    url: `v5/public/public_template/publish/id/${id}`,
    method: 'patch',
    data,
    loading: true
  })
}

/**
 * ansible 执行结果
 * @param data
 * @returns target 字段会根据 target_type （task 任务审批，public_template 公共模板）的不同而不同
 */
export function ansibleExecResultApi(data: GetAnsibleExecParams) {
  return request<string>({
    url: 'v5/public/ansible/get/list',
    method: 'get',
    data,
    loading: true
  })
}
