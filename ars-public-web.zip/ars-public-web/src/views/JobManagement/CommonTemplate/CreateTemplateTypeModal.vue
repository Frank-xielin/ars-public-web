<script lang="ts" setup>
import { useCreateTemplateType } from '@/composables/jobManagement/commonTemplate/createTemplateType'
import { watch } from 'vue'

const props = defineProps<{ visible: boolean }>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'change'): void
}>()

const { name, createType } = useCreateTemplateType(() => {
  emit('update:visible', false)
  emit('change')
})

watch(
  () => props.visible,
  val => {
    if (val) {
      name.value = ''
    }
  }
)
</script>

<template>
  <a-modal
    title="添加类型"
    :visible="visible"
    @ok="createType"
    @cancel="$emit('update:visible', false)"
  >
    <a-input style="margin: 20px 0" placeholder="模板类型名称" v-model:value="name" />
  </a-modal>
</template>
