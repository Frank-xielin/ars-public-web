<script lang="ts" setup>
import { HostBaseInfoKey } from '@/composables/workbench/hostManagement/hostDetail'
import { inject } from 'vue'

const baseInfo = inject(HostBaseInfoKey)
</script>

<template>
  <div class="network-info-list">
    <div class="network-list-item" v-for="(item, index) of baseInfo?.net_list" :key="item.name">
      <h3 class="network-name">网口{{ index + 1 }}: {{ item.name }}</h3>
      <p class="content">
        <span class="name">proto:</span>
        <span class="value">{{ item.proto }}</span>
      </p>
      <p class="content">
        <span class="name">IP:</span>
        <span class="value">{{ item.ip }}</span>
      </p>
      <p class="content">
        <span class="name">网关:</span>
        <span class="value">{{ item.gateway }}</span>
      </p>
      <p class="content">
        <span class="name">DNS:</span>
        <span class="value">{{ item.dns }}</span>
      </p>
      <p class="content">
        <span class="name">子网掩码:</span>
        <span class="value">{{ item.netmask }}</span>
      </p>
    </div>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.network-info-list {
  display: flex;
  flex-wrap: wrap;
  height: 570px;
  padding: 0 110px;
  overflow: hidden auto;
  .network-list-item {
    width: 329px;
    margin-bottom: 75px;
    padding-left: 48px;
    border-right: 1px solid @titleBack;
    .network-name {
      margin-bottom: 15px;
      font-size: 14px;
      font-weight: bold;
      color: @textColor_first;
    }
    .content {
      position: relative;
      left: 52px;
      margin-bottom: 18px;
      font-size: 14px;
      color: @textColor_first;
      .name {
        display: inline-block;
        width: 70px;
      }
    }
    &:nth-of-type(3n + 0) {
      border: none;
    }
  }
}
</style>
