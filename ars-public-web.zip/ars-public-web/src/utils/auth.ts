import router from '@/router'
import { useMainStore } from '@/store'
import Cookies from 'js-cookie'
import { storageKeys } from './storage/storageList'

/**
 * 功能权限检测
 * @param funcId
 * @param type 校验的是页面还是按钮，默认为 btn
 * @returns 功能是否有权使用
 */
export function checkFuncAuth(funcId: number, type: 'btn' | 'menu' = 'btn') {
  const store = useMainStore()

  if (type === 'btn') {
    const isAuth = store.funcAuthList.some(func => func.id === funcId)
    return isAuth
  } else {
    const isAuth = store.sourceMenu.some(menu => menu.id === funcId)
    return isAuth
  }
}

/** 清理用户信息退出登录 */
export function clearAccountInfo() {
  Cookies.remove(storageKeys.token)
  router.push('/Login')
}
