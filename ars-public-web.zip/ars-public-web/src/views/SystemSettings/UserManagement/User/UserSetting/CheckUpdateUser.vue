<script lang="ts" setup>
import { useAllClientList } from '@/composables/systemSettings/clientInformation'
import { useUserGroupManager } from '@/composables/systemSettings/userManagement/user/userGroupManageTab'
import { useUserManager } from '@/composables/systemSettings/userManagement/user/userManageTab'
import { useEditUserInfo } from '@/composables/systemSettings/userManagement/userSetting'
import { dateFormatter } from '@/utils/dateFormat'
import { watch } from 'vue'

const { userInfo, username, isEdit, oldInfo, onCancel, onSubmit } = useEditUserInfo()
const { clients, getAllClients } = useAllClientList()
const { dataSource: groupList, handleSearch: searchGroups } = useUserGroupManager()
const { dataSource: userList, handleSearch: getUsers } = useUserManager()

function formatter(date = '') {
  return dateFormatter(date, 'YYYY年MM月DD日 HH:mm')
}

getAllClients()
getUsers({ page: 1, page_size: 10000 })
searchGroups({ page: 1, page_size: 10000 })

watch(
  isEdit,
  edit => {
    if (edit) {
      userInfo.value.password = ''
    }
  },
  { immediate: true }
)
</script>

<template>
  <div class="check-update-user">
    <h2 class="operate-title">
      <span>用户：{{ username }}</span>
    </h2>
    <div class="operator-wrapper">
      <a-button v-if="!isEdit" :disabled="!$auth(57)" size="middle" @click="isEdit = true">
        编辑
      </a-button>
      <template v-else>
        <a-button size="middle" type="primary" @click="onSubmit">保存</a-button>
        <a-button size="middle" @click="onCancel">取消</a-button>
      </template>
    </div>

    <h3 class="form-title">用户管理</h3>
    <a-form class="user-edit-form" layout="inline" :wrapper-col="{ span: 13 }">
      <a-form-item label="用户名">
        <a-input v-if="isEdit" v-model:value="userInfo.user_name" />
        <span v-else>{{ oldInfo?.user_name }}</span>
      </a-form-item>
      <a-form-item label="分组">
        <custom-select
          v-if="isEdit"
          :data="groupList"
          value-field="id"
          label-field="name"
          v-model:value="userInfo.organization_id"
        />
        <span v-else>
          {{ groupList.find(group => oldInfo?.user_group_id === group.id)?.name }}
        </span>
      </a-form-item>
      <a-form-item label="中文名">
        <a-input v-if="isEdit" v-model:value="userInfo.chinese_name" />
        <span v-else>{{ oldInfo?.nick_name }}</span>
      </a-form-item>
      <a-form-item label="所属客户">
        <custom-select
          v-if="isEdit"
          :data="clients"
          value-field="id"
          label-field="name"
          v-model:value="userInfo.owned_customer"
        />
        <span v-else>{{ clients.find(item => item.id === oldInfo?.client_id)?.name }}</span>
      </a-form-item>
      <a-form-item label="手机号">
        <a-input v-if="isEdit" v-model:value="userInfo.phone" />
        <span v-else>{{ oldInfo?.phone }}</span>
      </a-form-item>
      <a-form-item label="Leader">
        <a-checkbox v-if="isEdit" v-model:checked="userInfo.leader" :disabled="!isEdit" />
        <a-checkbox v-else :checked="oldInfo?.leader" :disabled="!isEdit" />
      </a-form-item>
      <a-form-item label="邮箱">
        <a-input v-if="isEdit" v-model:value="userInfo.email" />
        <span v-else>{{ oldInfo?.email }}</span>
      </a-form-item>
      <a-form-item label="参与审批">
        <a-checkbox v-if="isEdit" v-model:checked="userInfo.approve" :disabled="!isEdit" />
        <a-checkbox v-else :checked="oldInfo?.approve" :disabled="!isEdit" />
      </a-form-item>
      <a-form-item label="密码">
        <a-input-password v-if="isEdit" v-model:value="userInfo.password" />
        <span v-else>******</span>
      </a-form-item>
      <a-form-item label="启用">
        <a-checkbox v-if="isEdit" v-model:checked="userInfo.enable" />
        <a-checkbox v-else :checked="oldInfo?.enable" :disabled="!isEdit" />
      </a-form-item>
    </a-form>

    <h3 class="form-title">系统信息</h3>
    <a-row class="sys-info">
      <a-col :span="12">
        <span class="label">创建人:</span>
        <span class="name">
          {{ userList.find(user => user.id === oldInfo?.created_by)?.user_name }}
        </span>
        <span class="time">{{ formatter(oldInfo?.created_at) }}</span>
      </a-col>
      <a-col :span="12">
        <span class="label">最近修改:</span>
        <span class="name">
          {{ userList.find(user => user.id === oldInfo?.updated_by)?.user_name }}
        </span>
        <span class="time">{{ formatter(oldInfo?.updated_at) }}</span>
      </a-col>
    </a-row>
  </div>
</template>

<style scoped lang="less">
.sys-info {
  max-width: 1214px;
  margin: auto;
  .ant-col {
    span {
      margin-right: 20px;
      font-size: 14px;
    }
  }
}
</style>
