<script lang="ts" setup>
import { ModalType } from '@/composables/workbench/errorRecord'
import { useAllClientList } from '@/composables/systemSettings/clientInformation'
import { computed, watch } from 'vue'
import { useAddEditRole } from '@/composables/systemSettings/userManagement/role/addEditRole'
import { RoleListItem } from '@/models/systemSettings/userManagement/role'

const props = defineProps<{
  visible: boolean
  modalType: ModalType
  targetInfo?: RoleListItem | null
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()

const { dataSource: clients, getAllClients } = useAllClientList()

const { formModel, form, submitForm } = useAddEditRole(() => {
  emit('update:visible', false)
  emit('search')
})

const clientList = computed(() => clients.value.filter(item => item.id !== -1))

watch(
  () => props.visible,
  async visible => {
    if (visible) {
      const { modalType, targetInfo } = props
      await getAllClients()
      if (modalType === '编辑') {
        formModel.value = {
          name: targetInfo?.name || '',
          note: targetInfo?.note || '',
          owned_customer: targetInfo?.client_id || 1
        }
      } else {
        formModel.value.owned_customer = clientList.value[0]?.id
      }
    } else {
      form.resetFields()
    }
  }
)
</script>

<template>
  <a-modal
    :visible="visible"
    :title="`${modalType}角色`"
    @ok="submitForm(modalType, targetInfo?.id)"
    @cancel="$emit('update:visible', false)"
  >
    <a-form :label-col="{ span: 5 }">
      <a-form-item label="角色名" v-bind="form.validateInfos.name">
        <a-input v-model:value="formModel.name" />
      </a-form-item>
      <a-form-item label="备注">
        <a-input v-model:value="formModel.note" />
      </a-form-item>
      <a-form-item label="所属客户" v-bind="form.validateInfos.owned_customer">
        <custom-select
          :data="clientList"
          label-field="name"
          value-field="id"
          v-model:value="formModel.owned_customer"
        />
      </a-form-item>
    </a-form>
  </a-modal>
</template>
