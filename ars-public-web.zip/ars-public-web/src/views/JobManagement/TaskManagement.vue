<script lang="tsx" setup>
import { ref } from 'vue'
import AlltaskMenu from './TaskManagement/TaskComponent/AlltaskMenu.vue'

const activeKey = ref('1')
</script>

<template>
  <div class="taskManagementWrapper page">
    <a-tabs v-model:activeKey="activeKey">
      <a-tab-pane key="1" tab="我的任务">
        <AlltaskMenu type="1" />
      </a-tab-pane>
      <a-tab-pane key="2" tab="全部任务" :disabled="!$auth(188)">
        <AlltaskMenu type="2" />
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<style lang="less" scoped>
.taskManagementWrapper {
  overflow-y: hidden !important;
  padding: 20px 36px 31px 36px !important;
  .search-form-wrapper {
    display: flex;
    position: relative;
    margin: 0 0 40px 0;
    justify-content: space-between;
    .search-input {
      width: 310px;
      margin-right: 10px;
    }
    .searchAnddata__task {
      display: flex;
    }
  }
}
</style>
