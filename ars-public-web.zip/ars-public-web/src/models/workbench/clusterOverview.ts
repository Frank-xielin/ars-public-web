export interface OverviewListParams extends Utils.SearchVO {
  search: string
}

export interface OverviewListItem {
  miner_id: string
  warning: number
  offline: number
  order_state: boolean
  principal: string
  client_name: string
}

export interface OverviewListRes extends Utils.PageVO {
  list: OverviewListItem[]
}

export type OverviewListAllParams = Utils.NoPager<OverviewListParams>

export type OverviewListAllRes = OverviewListItem[]

export interface OverviewDetailParams {
  miner_id: string
}

export type OverviewDetailRes = OverviewListItem
