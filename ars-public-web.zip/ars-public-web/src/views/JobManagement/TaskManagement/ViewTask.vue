<script lang="ts" setup>
import {
  useApprovalInfo,
  usePublishResult,
  useSubmitTask,
  useViewTask
} from '@/composables/jobManagement/taskManagement/allTaskApi'
import { useMainStore } from '@/store'
import { watch } from 'vue'
import { ref } from 'vue-demi'
import AgreeTaskToast from './TaskComponent/AgreeTaskToast.vue'
import ApprovalInfo from './TaskComponent/ApprovalInfo.vue'
import EditTask from './TaskComponent/EditTask.vue'
import PublishResult from './TaskComponent/PublishResult.vue'
import RefuseApprovalToast from './TaskComponent/RefuseApprovalToast.vue'
import SubmitApprovalToast from './TaskComponent/SubmitApprovalToast.vue'
import SystemInfo from './TaskComponent/SystemInfo.vue'
import TaskDetail from './TaskComponent/TaskDetail.vue'

// 这是一条测试注释
// 这是第二条测试注释

// 查看任务接口封装数据导出
const { viewData, taskId, initViewTask, dataSource, approvalId } = useViewTask()

// 拿到当前处理人
const { approveInfo, getApprovalInfo } = useApprovalInfo()

// 提交审核弹窗
const { submitTask } = useSubmitTask(() => {
  initViewTask()
  submitVisible.value = false
})
const submitVisible = ref<boolean>(false)
function toSubmitTaskToast(auto: boolean) {
  submitTask(taskId.value, auto)
}

// 拿到发布任务接口数据
const { pbTaskResult } = usePublishResult()

/** 收到审批后有权限的人确认审批弹窗 */
const visible = ref<boolean>(false)
function handleOk() {
  visible.value = false
  initViewTask()
  getApprovalInfo(approvalId.value)
}

// 收到审批后有权限的人拒绝审批确定
const refusevisible = ref<boolean>(false)
function handleRefuseOk() {
  refusevisible.value = false
  initViewTask()
}

const isEditTask = ref(false)
/** 取消编辑 */
function handleCancelEditTask(val: boolean) {
  isEditTask.value = val
}

const store = useMainStore()
function isActorUser() {
  return store.userInfo?.id === approveInfo.value?.current_node.approver_id
}

watch(approvalId, id => {
  if (id) {
    getApprovalInfo(id)
  }
})

initViewTask()
</script>

<template>
  <div v-show="!isEditTask" class="wrapper">
    <div class="wrapper__headDiv">
      <template v-if="viewData?.state === 1 && isActorUser()">
        <a-button class="agreement" @click="visible = true">批准</a-button>
        <a-button class="refuse" @click="refusevisible = true">拒绝</a-button>
      </template>
      <template v-else-if="viewData?.state === 3">
        <a-button class="agreement" @click="pbTaskResult(taskId)" :disabled="!$auth(43)">
          去发布
        </a-button>
        <a-button class="refuse" @click="initViewTask()">刷新</a-button>
      </template>
      <a-button v-else-if="viewData?.state === 4" class="refuse" @click="initViewTask()">
        刷新
      </a-button>
      <template v-if="viewData?.state === 0">
        <a-button class="agreement" @click="isEditTask = true" :disabled="!$auth(40)">
          编辑
        </a-button>
        <a-button class="refuse" @click="submitVisible = true" :disabled="!$auth(42)">
          提交审批
        </a-button>
      </template>
    </div>
    <div class="wrapper__contentDiv">
      <TaskDetail :viewData="viewData" />
      <SystemInfo :viewData="viewData" />
      <ApprovalInfo
        v-if="dataSource.length && viewData?.state !== 0"
        :submitInfo="dataSource"
        :submitter="viewData?.creator || ''"
      />
      <PublishResult v-if="viewData?.state === 4" :publishData="viewData" />
    </div>
  </div>
  <edit-task
    v-show="isEditTask"
    :model="viewData"
    :task-id="taskId"
    :approval-id="approvalId"
    @handleCancelEditTask="handleCancelEditTask"
    @submit="initViewTask"
  />
  <agree-task-toast v-model:visible="visible" :approval-id="approvalId" @handle-ok="handleOk" />
  <submit-approval-toast
    v-model:visible="submitVisible"
    :approval-id="approvalId"
    @handleSelect="toSubmitTaskToast"
  />
  <RefuseApprovalToast
    v-model:visible="refusevisible"
    :approval-id="approvalId"
    @handleRefuseOk="handleRefuseOk"
  />
</template>

<style lang="less" scoped>
.wrapper {
  height: calc(100%);
  position: relative;
  overflow: hidden auto;
  background-color: #eef0f2;
  .wrapper__contentDiv {
    overflow-y: hidden;
  }

  &__isEditContent {
    background-color: #fff;
  }
}
</style>

<style lang="less">
@import (reference) '@/assets/styles/index.less';

.wrapper__headDiv {
  position: relative;
  background-color: #fff;
  padding: 20px 0 15px 20px;
  display: flex;
  justify-content: center;
  margin: 20px 0 20px 0 !important;
  .agreement {
    width: 170px;
    height: 38px;
    margin: 0 20px 0 20px;
    background-color: @ueColor_first;
    color: #fff !important;
  }
  .refuse {
    width: 170px;
    height: 38px;
  }
  .page-title {
    font-size: 20px;
    padding: 0 20px 20px;
    border-bottom: @tableBorder;
  }
  .operation-top {
    display: flex;
    justify-content: center;
    margin: 20px 0 30px;
    > button {
      width: 150px;
      margin: 0 10px;
    }
  }
}
.big__title {
  font-size: 14px;
  font-weight: bold;
  line-height: 19px;
  border-bottom: 1px solid #ebf1f5;
  padding-bottom: 12px;
}
</style>
