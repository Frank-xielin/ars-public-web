import { ClusterListItem } from '@/models/systemSettings/clusterInformation'
import {
  getUsersClusterListApi,
  userLinkClusterApi
} from '@/services/systemSettings/userManagement/user'
import { message } from 'ant-design-vue'
import { Ref, ref } from 'vue'

export const columns: Utils.ColumnField<ClusterListItem>[] = [
  { title: '集群', dataIndex: 'miner' },
  { title: '所属客户', dataIndex: 'client_name' }
]

/** 指定用户已关联的集群管理 */
export function useUsersClusterManager(id: Ref<number>, successFn?: () => void) {
  const usersClusters = ref<string[]>([])

  /** 获取已关联的集群 */
  async function getUsersClusters() {
    try {
      const reply = await getUsersClusterListApi(id.value)
      const { code, data, msg } = reply
      if (code === 0) {
        usersClusters.value = data || []
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  /** 提交需要关联的集群 */
  async function onSubmit() {
    if (!usersClusters.value.length) {
      message.warn('至少选择一个集群！')
      return
    }
    const reply = await userLinkClusterApi({
      user_id: id.value,
      miner_ids: usersClusters.value
    })
    if (reply.code === 0) {
      message.success('关联集群成功')
      successFn?.()
    } else {
      message.error(reply.msg)
    }
  }

  return { usersClusters, getUsersClusters, onSubmit }
}
