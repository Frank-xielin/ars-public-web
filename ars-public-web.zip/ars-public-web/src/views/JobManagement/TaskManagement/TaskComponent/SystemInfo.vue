<script lang="ts" setup>
import { ViewTaskRes } from '@/models/jobManagement/taskManagement'

const props = defineProps<{
  viewData: ViewTaskRes | null
}>()
</script>

<template>
  <div class="systemInfo">
    <h3 class="big__title">系统信息</h3>
    <div class="systemInfo__content">
      <span>创建人：&emsp;{{ viewData?.creator }}</span>
      <span>最近修改：&emsp;{{ viewData?.updater }}&emsp;{{ viewData?.updated_at }}</span>
    </div>
  </div>
</template>

<style lang="less" scoped>
@import (reference) '@/assets/styles/index.less';
.systemInfo {
  padding: 17px 36px 48px 36px !important;
  margin: 20px 0 20px 0;
  background-color: #fff;
  &__content {
    display: flex;
    padding: 24px 0 0 177px;
    span {
      flex-wrap: nowrap;
      justify-content: center;
      white-space: normal;
      padding-right: 230px;
    }
  }
}
.big__title {
  font-size: 14px;
  font-weight: bold;
  line-height: 19px;
  border-bottom: 1px solid #ebf1f5;
  padding-bottom: 12px;
}
* {
  color: @textColor_first !important;
  font-size: 14px;
}
@media screen and(max-width:1330px) {
  .systemInfo {
    &__content {
      min-width: 900px;
      padding: 24px 0 0 145px;
      span {
        flex-wrap: nowrap;
        justify-content: center;
        white-space: normal;
        padding-right: 100px;
      }
    }
  }
}
</style>
