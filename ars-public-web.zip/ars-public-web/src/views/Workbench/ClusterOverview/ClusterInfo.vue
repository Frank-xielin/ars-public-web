<script lang="ts" setup>
import {
  useDetailsOfCluster,
  useViewClusterServer
} from '@/composables/workbench/clusterOverview/clusterInfo'
import { OverviewListItem } from '@/models/workbench/clusterOverview'
import { ref } from 'vue'

const props = defineProps<{
  data: OverviewListItem
}>()

const clusterStatus: Utils.ColumnField<OverviewListItem>[] = [
  { title: '今日告警', dataIndex: 'warning' },
  { title: '设备离线', dataIndex: 'offline' },
  { title: '下单状态', dataIndex: 'order_state' },
  { title: '集群负责人', dataIndex: 'principal' }
]

const isBtnHovered = ref(false)
const { loading, isError, errorDesc, clusterInfo, getClusterDetails } = useDetailsOfCluster()
const { intoClustersServer } = useViewClusterServer()

getClusterDetails(props.data.miner_id)
</script>

<template>
  <div class="cluster-info">
    <div class="cluster-label">
      <span class="code">{{ clusterInfo?.miner_id }} - {{ clusterInfo?.client_name }}</span>
    </div>
    <div class="info-content">
      <a-skeleton :loading="loading" active :paragraph="{ rows: 4 }">
        <template v-if="!isError && clusterInfo">
          <div class="cluster-status-list">
            <div v-for="col of clusterStatus" class="status-item" :key="col.dataIndex">
              <span class="label">{{ col.title }}:</span>
              <custom-tooltip>
                <span v-if="col.dataIndex === 'order_state'" class="value">
                  {{ clusterInfo[col.dataIndex] ? '下单中' : '已停止' }}
                </span>
                <span v-else-if="col.dataIndex === 'principal'" class="value">
                  {{ clusterInfo[col.dataIndex] }}
                </span>
                <span
                  v-else
                  :class="{ 'primary-text': !!clusterInfo[col.dataIndex] }"
                  class="value"
                >
                  {{ clusterInfo[col.dataIndex] ?? 0 }}
                </span>
              </custom-tooltip>
            </div>
          </div>
          <a-button
            class="check-cluster-btn"
            :type="isBtnHovered ? 'primary' : 'default'"
            :disabled="!$auth(18)"
            shape="round"
            @mouseenter="isBtnHovered = true"
            @mouseleave="isBtnHovered = false"
            @click="intoClustersServer(data.miner_id)"
          >
            <span v-show="isBtnHovered">进入集群</span>
            <icon-font v-show="!isBtnHovered" type="icon-cloudconsole_button_icon_arrow" />
          </a-button>
        </template>
        <div class="error-info" v-else>
          <h4 class="error-title">请求错误 :</h4>
          <p class="error-desc">{{ errorDesc }}</p>
        </div>
      </a-skeleton>
    </div>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.cluster-info {
  width: 305px;
  height: 276px;
  margin: 0 13px 16px 0;
  border: 1px solid @ueColor_fifth;
  border-radius: 4px;
  .animate();

  .cluster-label {
    height: 38px;
    margin: 0;
    background: rgba(209, 229, 255, 0.502);
    font-weight: bold;
    color: @textColor_first;
    text-align: center;
    line-height: 38px;

    .code {
      font-size: 12px;
    }
  }

  .info-content {
    position: relative;
    height: calc(100% - 38px);
    width: 100%;
    border-radius: 0px 0px 4px 4px;
    padding: 0 20px;
    .cluster-status-list {
      height: 100%;
      padding: 20px 0;

      .status-item {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 15px;
        margin-bottom: 15px;
        font-size: 12px;
        .primary-text {
          color: @ueColor_first;
        }
        .label {
          width: 100px;
          margin-right: 20px;
        }
        .value {
          width: 100px;
          height: 100%;
          font-weight: bold;
          overflow-x: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          .warning {
            margin-bottom: 5px;
            &:last-of-type {
              margin: 0;
            }
          }
        }
      }
    }

    .check-cluster-btn {
      position: absolute;
      bottom: 18px;
      left: 50%;
      height: 28px;
      width: 148px;
      line-height: 16px;
      font-size: 12px;
      transform: translateX(-50%);
      .animate();
    }

    .error-info {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100%;
      padding: 20px 0;
      .error-title {
        font-size: 16px;
        font-weight: bold;
        margin-bottom: 10px;
      }
      .error-desc {
        width: 100%;
        font-size: 14px;
        line-height: 20px;
        text-align: center;
        overflow-wrap: break-word;
      }
    }
  }
}

@media screen and (max-width: 1440px) {
  .cluster-info {
    width: 276px;
    height: 276px;

    .info-content {
      .cluster-status-list .status-item .label {
        width: 80px;
      }
    }
  }
}
</style>
