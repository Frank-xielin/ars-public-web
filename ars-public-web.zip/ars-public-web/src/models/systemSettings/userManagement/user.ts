import { ClientListItem } from '../clientInformation'
import { RoleListItem } from './role'

export interface UserInfoByIdRes {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string
  user_name: string
  passwd: string
  phone: string
  email: string
  avatar: string
  nick_name: string
  introduction: string
  created_by: number
  updated_by: number
  last_login: string
  is_first_login: number
  passwd_need_modify: number
  passwd_expired: string
  passwd_last_updated: string
  client_id: number
  leader: boolean
  approve: boolean
  enable: boolean
  user_group_id: number
  role_id: number[]
}

export interface UserListParams extends Utils.SearchVO {
  client_id: number
  user: string
}

export interface UserListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string
  user_name: string
  passwd: string
  phone: string
  email: string
  avatar: string
  nick_name: string
  introduction: string
  created_by: number
  last_login: string
  is_first_login: number
  passwd_need_modify: number
  passwd_expired: string
  passwd_last_updated: string
  clients: ClientListItem | null
  leader: boolean
  approve: boolean
  enable: boolean
  user_group: UserGroupListItem | null
  roles: RoleListItem[] | null
}

export interface UserListRes extends Utils.PageVO {
  list: UserListItem[]
}

export interface CreateUserParams {
  owned_customer: number
  user_name: string
  chinese_name: string
  phone: string
  email: string
  organization_id: number
  password: string
  leader: boolean
  approve: boolean
  enable: boolean
}

export type UpdateUserStatParams = CreateUserParams

export interface UserLinkRolesParams {
  user_id: number
  role_ids: number[]
}

export interface UserLinkClusterParams {
  user_id: number
  miner_ids: string[]
}

export interface UserGroupListItem {
  id: number
  created_at: string
  name: string
  parent_id: number
  created_by: number
  note: string
}

export type UserGroupListAllRes = UserGroupListItem[]

export interface UserGroupListParams extends Utils.SearchVO {
  search: string
}

export interface UserGroupListRes extends Utils.PageVO {
  list: UserGroupListItem[]
}

export interface CreateUserGroupParams {
  group_name: string
  parent_id: number
  note: string
}

export type UpdateUserGroupParams = CreateUserGroupParams
