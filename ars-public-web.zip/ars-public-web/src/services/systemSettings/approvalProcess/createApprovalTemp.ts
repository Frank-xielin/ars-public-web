import {
  CreateApprovalTempParams,
  CreateApprovalTempRes,
  NotifyChannelListRes
} from '@/models/systemSettings/approvalProcess/createApprovalTemp'
import { request } from '@/utils/httpConfig'

/**
 * 审批流模板创建 - 单个
 * @param data
 * @returns
 */
export function createApprovalTempApi(data: CreateApprovalTempParams) {
  return request<CreateApprovalTempRes>({
    url: 'v5/public/approval_template/create/one',
    method: 'POST',
    data,
    loading: true
  })
}

/** 审批流模板创建 - 获取通知方式列表 */
export function notifyChannelListApi() {
  return request<NotifyChannelListRes>({
    url: 'v5/public/notify_channel/get/all',
    method: 'get',
    loading: true
  })
}
