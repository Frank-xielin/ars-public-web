<script lang="ts" setup>
import zhCN from 'ant-design-vue/es/locale/zh_CN'
</script>

<template>
  <div class="App">
    <a-config-provider :locale="zhCN">
      <layout />
    </a-config-provider>
  </div>
</template>

<style lang="less">
@import (reference) '@/assets/styles/index.less';

.App {
  display: flex;
  height: 100vh;
  width: 100vw;
  overflow: hidden;
  background: @bgClor_main;
}

@media screen and (max-width: 1440px) {
  .App main .main-content.current {
    max-width: calc(100vw - 194px);
  }
}
</style>
