import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { TemplateListItem, TemplateListParams } from '@/models/jobManagement/commonTemplate'
import { deleteTemplateApi, templateListApi } from '@/services/jobManagement/commonTemplate'
import { Form, message, Modal } from 'ant-design-vue'
import { ref } from 'vue'

export const columns: Utils.ColumnField<TemplateListItem>[] = [
  { title: '模板名称', dataIndex: 'template_name' },
  { title: '模板类型', dataIndex: 'template_type' },
  { title: '模板内容', dataIndex: 'content' },
  { title: '创建人', dataIndex: 'creator' },
  { title: '创建时间', dataIndex: 'created_at' },
  { title: '启用', dataIndex: 'enabled' },
  { title: '操作', dataIndex: 'id' }
]

/** 公共模板列表 */
export function useTemplateList() {
  const searchModel = ref<Utils.NoPager<TemplateListParams>>({
    type_id: 0,
    content: '',
    enabled: undefined
  })
  const dataSource = ref<TemplateListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()
  const form = Form.useForm(searchModel)

  const { loading, run } = useRequest(templateListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  function handleSearch(vo?: Utils.SearchVO) {
    try {
      const params = {
        ...searchModel.value,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params)
    } catch (e) {}
  }

  return { pageVo, form, searchModel, dataSource, loading, handleSearch }
}

/** 删除单个公共模板 */
export function useDeleteTemplate(successFn: () => void) {
  function deleteTemplate(id: number) {
    Modal.confirm({
      content: '是否删除指定模板？',
      async onOk() {
        try {
          const reply = await deleteTemplateApi(id)
          if (reply.code === 0) {
            message.success('删除成功')
            successFn()
          } else {
            message.error(reply.msg)
          }
        } catch (e) {}
      }
    })
  }

  return { deleteTemplate }
}
