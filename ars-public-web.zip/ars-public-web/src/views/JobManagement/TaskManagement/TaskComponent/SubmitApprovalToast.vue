<script lang="ts" setup>
import { ref } from 'vue'

// 父组件传值
defineProps<{
  visible: boolean
  approvalId: number
}>()

// 传给父组件
const emit = defineEmits(['update:visible', 'handleSelect'])
const selectValue = ref<boolean>(false)

// // 提交审核
// const emit = defineEmits(['update:visible'])
// const { taskId, initViewTask } = useViewTask()
// const { SubmitTask } = useSubmitTask(() => {
//   initViewTask()
// })
// function handleSelect(auto: boolean) {
//   SubmitTask(taskId.value, auto)
// }
</script>

<template>
  <!-- @ok="handleSelect(selectValue)" -->
  <a-modal
    class="sumbitApprovalModal"
    :visible="visible"
    title="提示"
    @ok="$emit('handleSelect', selectValue)"
    okText="确定"
    @cancel="$emit('update:visible', false)"
    cancelText="取消"
    width="356px"
  >
    审核通过后，是否自动执行任务？
    <a-radio-group v-model:value="selectValue" name="radioGroup">
      <a-radio :value="true">是</a-radio>
      <a-radio :value="false">否</a-radio>
    </a-radio-group>
  </a-modal>
</template>
