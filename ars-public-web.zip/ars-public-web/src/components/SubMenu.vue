<script lang="ts" setup>
import { menuIcons } from '@/composables/asideMenu/menuIcon'
import { MenuItem } from '@/utils/routerController'

defineProps<{
  menuObject: MenuItem
}>()

/** 是否有不需要隐藏的菜单 */
function hasVisibleMenu(list: MenuItem[]) {
  return list.some(item => !item.visible)
}
</script>

<template>
  <a-sub-menu
    v-if="menuObject.children && hasVisibleMenu(menuObject.children)"
    :key="menuObject.path"
  >
    <template v-if="menuIcons.has(menuObject.name)" #icon>
      <icon-font :type="menuIcons.get(menuObject.name) || ''" />
    </template>
    <template #title>{{ menuObject.name }}</template>
    <sub-menu
      v-for="item in menuObject.children.filter(item => !item.visible)"
      :key="item.path"
      :menu-object="item"
    />
  </a-sub-menu>
  <a-menu-item v-else-if="!menuObject.visible" :key="menuObject.path || ''">
    <template v-if="menuIcons.has(menuObject.name)" #icon>
      <icon-font :type="menuIcons.get(menuObject.name) || ''" />
    </template>
    {{ menuObject.name }}
  </a-menu-item>
</template>
