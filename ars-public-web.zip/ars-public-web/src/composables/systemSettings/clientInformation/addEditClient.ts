import { Form } from 'ant-design-vue'
import { ref } from 'vue'

import useRequest from '@/common/useRequest'
import { CreateClientParams } from '@/models/systemSettings/clientInformation'
import { createClientApi, updateClientApi } from '@/services/systemSettings/clientInformation'
import { requestHandler } from '@/utils/formTools'

/**
 * 新建、修改客户信息
 * @param successFn
 * @returns
 */
export function useChangeClient(successFn: () => void) {
  const formModel = ref<CreateClientParams>({ name: '', note: '' })
  const rules = ref<Utils.RulesObject<CreateClientParams>>({
    name: [{ message: '请输入客户简称', required: true }]
  })
  const form = Form.useForm(formModel, rules)

  const { run: addClientFetch } = useRequest(createClientApi, {
    onSuccess: reply => {
      requestHandler('新建客户成功')(reply)
      successFn()
    }
  })
  const { run: editClientFetch } = useRequest(updateClientApi, {
    onSuccess: reply => {
      requestHandler('编辑客户成功')(reply)
      successFn()
    }
  })

  async function onSubmit(id?: number) {
    try {
      await form.validate()
      if (id != null) {
        editClientFetch(id, formModel.value)
      } else {
        addClientFetch(formModel.value)
      }
    } catch (e) {}
  }

  return { form, formModel, onSubmit }
}
