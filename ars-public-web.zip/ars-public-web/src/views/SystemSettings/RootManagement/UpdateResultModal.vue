<script lang="tsx" setup>
import { softwareList } from '@/composables/workbench/hostManagement'
import { GetUpdateResultItem, GetUpdateResultRes } from '@/models/systemSettings/rootManagement'

defineProps<{
  visible: boolean
  updateResult: GetUpdateResultRes
}>()
defineEmits<{
  (event: 'update:visible', val: boolean): void
}>()

const columns: Utils.ColumnField<GetUpdateResultItem>[] = [
  { title: '主机SN', dataIndex: 'device_sn' },
  { title: '主机IP', dataIndex: 'ips' },
  { title: '软件角色', dataIndex: 'software_type' },
  { title: '状态', dataIndex: 'root_passwd_status' }
]
</script>

<template>
  <a-modal
    title="修改root密码"
    :visible="visible"
    :width="900"
    :footer="null"
    @cancel="$emit('update:visible', false)"
  >
    <a-table
      v-bind="$tableConfigs(updateResult.list)"
      :scroll="$scroller(400)"
      row-key="device_sn"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ column, text }">
        <span v-if="column.title === '状态'">
          <span v-if="text">
            <icon-font type="icon-normal" />
            成功
          </span>
          <span v-else class="error-text">
            <icon-font type="icon-critical" />
            失败
          </span>
        </span>
        <span v-else-if="column.title === '软件角色'">
          {{ softwareList.find(item => item.value === text)?.label }}
        </span>
      </template>
    </a-table>
    <footer class="total-content">
      <span>总数 : {{ updateResult.total_size }}</span>
      <span>成功 : {{ updateResult.online_size }}</span>
      <span>失败 : {{ updateResult.offline_size }}</span>
    </footer>
  </a-modal>
</template>

<style scoped lang="less">
.total-content {
  padding: 20px 0;
  span {
    margin-right: 20px;
  }
}
</style>
