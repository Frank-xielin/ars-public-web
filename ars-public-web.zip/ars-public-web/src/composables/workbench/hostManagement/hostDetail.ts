import useChartsInit from '@/common/useChartsInit'
import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import {
  DeviceBaseInfo,
  DeviceDiskListItem,
  DeviceListItem,
  DeviceOperationListItem,
  DeviceOperationListParams
} from '@/models/workbench/hostManagement'
import { deviceOperationListApi } from '@/services/workbench/hostManagement'
import { Objectkeys } from '@/utils/dataJudgement'
import { message } from 'ant-design-vue'
import { Dayjs } from 'dayjs'
import { EChartsOption } from 'echarts'
import { isNumber, omit } from 'lodash-es'
import { inject, InjectionKey, nextTick, ref, Ref, watch } from 'vue'

export const HostBaseInfoKey: InjectionKey<Ref<Readonly<DeviceBaseInfo & DeviceListItem>>> =
  Symbol('基本信息')
export const storageConversion = 1024 * 1024 * 1024

export const diskColumns: Utils.ColumnField<DeviceDiskListItem>[] = [
  { title: '序号', dataIndex: 'dev_name' },
  { title: '磁盘名称', dataIndex: 'dev_name' },
  { title: '磁盘类型', dataIndex: 'type' },
  { title: '存储空间', dataIndex: 'space_all' },
  { title: '已使用', dataIndex: 'space_used' }
]

export const gpuHandler = (list?: { gpu_model: string }[]) => {
  if (!list || !list.length) {
    return ''
  }
  const map: Utils.Dict<number> = {}
  list.forEach(item => {
    const key = item.gpu_model
    if (isNumber(map[key])) {
      map[key] += 1
    } else {
      map[key] = 1
    }
  })
  let str = ''
  Objectkeys(map, k => {
    str += `, ${k}*${map[k]}`
  })
  return str.substring(1)
}

export function useDiskInfoChart() {
  const chartsOp = ref<EChartsOption>({})
  const baseInfo = inject(HostBaseInfoKey)

  const { charts, chartsEl } = useChartsInit(chartsOp)

  watch(
    () => baseInfo?.value,
    info => {
      nextTick(() => {
        if (info) {
          let spaceAll = 0
          let spaceUsed = 0
          info.disk_list.forEach(disk => {
            spaceAll += disk.space_all / storageConversion
            spaceUsed += disk.space_used / storageConversion
          })
          const notUsed = spaceAll - spaceUsed
          chartsOp.value = {
            type: 'pie',
            tooltip: { trigger: 'item' },
            legend: { top: 'center', right: '10%', orient: 'vertical' },
            color: ['#35A4F5', '#00D8A0'],
            series: [
              {
                type: 'pie',
                radius: ['75%', '90%'],
                tooltip: { formatter: obj => `${obj.name}: ${(+obj.value).toFixed(2)} G` },
                avoidLabelOverlap: false,
                label: { show: false, position: 'center' },
                labelLine: { show: false },
                center: ['30%', '50%'],
                emphasis: {
                  label: {
                    show: true,
                    fontSize: '20',
                    fontWeight: 'bold',
                    formatter: obj => {
                      return `${obj.name}: ${obj.percent}%`
                    }
                  }
                },
                data: [
                  { value: spaceUsed, name: '已用' },
                  { value: notUsed, name: '可用' }
                ]
              }
            ]
          }
        }
      })
    },
    { immediate: true, deep: true }
  )

  return { chartsOp, chartsEl, charts }
}

export interface SearchForm extends Utils.NoPager<DeviceOperationListParams> {
  dates: [Dayjs, Dayjs] | undefined
}
export const columns: Utils.ColumnField<DeviceOperationListItem>[] = [
  { title: '时间', dataIndex: 'created_at' },
  { title: '操作', dataIndex: 'operation' },
  { title: '用户', dataIndex: 'user_name' }
]

/** 主机操作记录列表 */
export function useOperationRecords() {
  const searchModel = ref<SearchForm>({
    dates: undefined,
    end_time: '',
    start_time: '',
    key: '',
    sn: ''
  })
  const dataSource = ref<DeviceOperationListItem[]>([])
  const baseInfo = inject(HostBaseInfoKey)
  const { pageVo, setPageFromData } = usePagination()

  const { loading, run } = useRequest(deviceOperationListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  function handleSearch(vo?: Utils.SearchVO) {
    searchModel.value.sn = baseInfo?.value.device_sn || ''
    try {
      const pattern = 'YYYY-MM-DD HH:mm:ss'
      searchModel.value.start_time = searchModel.value.dates?.[0].format(pattern) || ''
      searchModel.value.end_time = searchModel.value.dates?.[1].format(pattern) || ''
      const params: DeviceOperationListParams = {
        ...omit(searchModel.value),
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params)
    } catch (e) {}
  }

  return { dataSource, pageVo, loading, searchModel, handleSearch }
}
