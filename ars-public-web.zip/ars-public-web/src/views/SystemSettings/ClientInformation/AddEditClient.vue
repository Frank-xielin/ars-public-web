<script lang="ts" setup>
import { useChangeClient } from '@/composables/systemSettings/clientInformation/addEditClient'
import { ModalType } from '@/composables/workbench/errorRecord'
import { ClientListItem } from '@/models/systemSettings/clientInformation'
import { watch } from 'vue'

const props = defineProps<{
  visible: boolean
  modalType: ModalType
  targetInfo: ClientListItem | null
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()

const { form, formModel, onSubmit } = useChangeClient(() => {
  emit('update:visible', false)
  emit('search')
})

watch(
  () => props.visible,
  val => {
    const { targetInfo, modalType } = props
    if (val && modalType === '编辑' && targetInfo) {
      formModel.value = {
        name: targetInfo.name,
        note: targetInfo.note
      }
    } else {
      form.resetFields()
    }
  }
)
</script>

<template>
  <a-modal
    :title="`${modalType}客户信息`"
    :visible="visible"
    @cancel="$emit('update:visible', false)"
    @ok="onSubmit(targetInfo?.id)"
  >
    <a-form :label-col="{ span: 5 }">
      <a-form-item label="客户简称" v-bind="form.validateInfos.name">
        <a-input v-model:value="formModel.name" />
      </a-form-item>
      <a-form-item label="备注">
        <a-input v-model:value="formModel.note" />
      </a-form-item>
    </a-form>
  </a-modal>
</template>
