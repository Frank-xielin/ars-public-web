<script lang="ts" setup>
import {
  useCreateApprovalTemp,
  useNotifyChannelAllList
} from '@/composables/systemSettings/approvalProcess/createApprovalTemp'
import { useUserManager } from '@/composables/systemSettings/userManagement/user/userManageTab'
import { computed } from 'vue'

const { dataSource: userList, handleSearch: searchUsers } = useUserManager()
const { formModel, form, submitApprovalTemp } = useCreateApprovalTemp()
const { notifyChannels, getAllNotifyChannels } = useNotifyChannelAllList()

const users = computed(() => userList.value.filter(user => user.approve))

searchUsers({ page: 1, page_size: 10000 })
getAllNotifyChannels()
</script>

<template>
  <div class="create-approval-temp page">
    <h2 class="title">新建审批流</h2>
    <div class="operator-wrapper">
      <a-button shape="round" size="middle" type="primary" @click="submitApprovalTemp">
        保存
      </a-button>
      <a-button
        shape="round"
        size="middle"
        @click="$router.push('/SystemSettings/ApprovalProcess')"
      >
        取消
      </a-button>
    </div>

    <h3 class="form-title">审批流信息</h3>
    <a-form class="approval-temp-form" :label-col="{ span: 4 }">
      <a-form-item label="名称" v-bind="form.validateInfos.title">
        <a-input v-model:value="formModel.title" />
      </a-form-item>
      <a-form-item label="审核人1" v-bind="form.validateInfos.approver1_id">
        <custom-select
          :data="users"
          label-field="user_name"
          value-field="id"
          v-model:value="formModel.approver1_id"
        />
      </a-form-item>
      <a-form-item label="审核人2" v-bind="form.validateInfos.approver2_id">
        <custom-select
          :data="users"
          label-field="user_name"
          value-field="id"
          v-model:value="formModel.approver2_id"
          allow-clear
        />
      </a-form-item>
      <a-form-item label="审核人3" v-bind="form.validateInfos.approver3_id">
        <custom-select
          :data="users"
          label-field="user_name"
          value-field="id"
          v-model:value="formModel.approver3_id"
          allow-clear
        />
      </a-form-item>
      <a-form-item label="通知人">
        <custom-select
          :data="userList"
          label-field="user_name"
          value-field="id"
          mode="multiple"
          v-model:value="formModel.notifiers"
        />
      </a-form-item>
      <a-form-item label="通知方式">
        <custom-select
          :data="notifyChannels"
          value-field="id"
          label-field="name"
          mode="multiple"
          v-model:value="formModel.notify_channels"
        />
      </a-form-item>
      <a-form-item label="启用">
        <a-checkbox v-model:checked="formModel.enabled" />
      </a-form-item>
    </a-form>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.title {
  font-size: 20px;
  padding: 0 20px 20px;
  border-bottom: @tableBorder;
}
.operator-wrapper {
  display: flex;
  justify-content: center;
  margin: 30px;
  > button {
    width: 100px;
    margin: 0 10px;
  }
}
.form-title {
  padding: 10px;
  margin-bottom: 30px;
  font-size: 16px;
  background: @titleBack;
}
.approval-temp-form {
  width: 500px;
  margin: auto;
}
</style>
