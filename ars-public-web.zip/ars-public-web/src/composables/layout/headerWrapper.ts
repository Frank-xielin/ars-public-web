import config from '@/config'
import { backendVersionApi } from '@/services/infrastructure'
import { message } from 'ant-design-vue'
import { ref, watch } from 'vue'

interface SelectDataItem {
  name: string
  link: string
}

export const selectData: SelectDataItem[] = [
  { name: '个人信息', link: '/Personal/PersonalInfomation' },
  { name: '我的审批', link: '/Personal/MyApprovals' },
  { name: '我的消息', link: '/Personal/MyMessages' },
  { name: '登录历史', link: '/Personal/LoginHistory' }
]

/** 获取系统版本信息 */
export function useSystemVersionInfo() {
  const versionShow = ref(false)
  const versionInfo = ref({
    client: '',
    service: ''
  })

  async function getBackendVersion() {
    try {
      const reply = await backendVersionApi()
      const { code, data, msg } = reply
      if (code === 0) {
        versionInfo.value.service = data || ''
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  watch(versionShow, show => {
    if (show) {
      getBackendVersion()
      versionInfo.value.client = config.version
    }
  })

  return { versionShow, versionInfo }
}
