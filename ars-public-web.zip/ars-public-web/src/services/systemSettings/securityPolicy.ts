import { GetPwTacticRes, UpdatePwTacticParams } from '@/models/systemSettings/securityPolicy'
import { request } from '@/utils/httpConfig'

/** 密码策略展示 */
export function getPwTacticApi() {
  return request<GetPwTacticRes>({
    url: 'v5/public/tactic/get/info',
    method: 'GET',
    loading: true
  })
}

/** 设置密码策略 */
export function updatePwTacticApi(data: UpdatePwTacticParams) {
  return request({
    url: 'v5/public/tactic/update/info',
    method: 'put',
    data,
    loading: true
  })
}
