<script lang="tsx" setup>
import { useClusterAllList } from '@/composables/systemSettings/clusterInformation'
import {
  columns,
  useRootManagementData,
  useRootManagementOperations
} from '@/composables/systemSettings/rootManagement'
import { softwareList } from '@/composables/workbench/hostManagement'
import { RootPwdListItem } from '@/models/systemSettings/rootManagement'
import { pagerConfigs } from '@/utils/formTools'
import CheckRootPasswordModal from './RootManagement/CheckRootPasswordModal.vue'
import UpdateRecordModal from './RootManagement/UpdateRecordModal.vue'
import UpdateResultModal from './RootManagement/UpdateResultModal.vue'
import UpdateRootPasswordModal from './RootManagement/UpdateRootPasswordModal.vue'

const { pageVo, dataSource, statistics, formModel, loading, handleSearch } = useRootManagementData(
  () => {
    selectedRows.value.length = 0
  }
)
const {
  updatePwdShow,
  checkPwdShow,
  updateResult,
  updateResultShow,
  recordShow,
  updateType,
  selectedRows,
  updateTargetId,
  handleOperate
} = useRootManagementOperations()
const { dataSource: clusterList, searchAllClusters } = useClusterAllList()

const selectionHandle = (_: Utils.Key[], rows: RootPwdListItem[]) => {
  selectedRows.value = rows
}

searchAllClusters().then(() => {
  formModel.value.cluster_id = clusterList.value[0]?.miner || ''
  handleSearch()
})
</script>

<template>
  <div class="root-management page">
    <a-form class="search-form" layout="inline">
      <a-form-item>
        <custom-select
          style="width: 150px"
          :data="clusterList"
          value-field="miner"
          label-field="miner"
          v-model:value="formModel.cluster_id"
          @change="handleSearch()"
        />
      </a-form-item>
      <a-form-item>
        <custom-select
          style="width: 150px"
          :data="softwareList"
          v-model:value="formModel.software"
          @change="handleSearch()"
        />
      </a-form-item>

      <a-form-item>
        <a-button-group>
          <a-button @click="handleOperate('role')">按角色修改root密码</a-button>
          <a-button @click="handleOperate('check')">查看root密码</a-button>
          <a-button @click="handleOperate('record')">修改记录</a-button>
        </a-button-group>
      </a-form-item>

      <a-form-item class="search-input-item">
        <custom-search-input
          placeholder="主机SN/IP"
          v-model:value="formModel.sn_ip"
          @search-func="handleSearch()"
        />
      </a-form-item>
    </a-form>

    <a-table
      v-bind="$tableConfigs(dataSource, loading)"
      class="table-box"
      row-key="id"
      :row-selection="
        $tableSelection({
          selectedRowKeys: selectedRows.map(row => row.id),
          onChange: selectionHandle,
          getCheckboxProps: record => ({ disabled: record.ops_server_status !== 1 })
        })
      "
      :scroll="$scroller('calc(100vh - 345px)')"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ column: col, text, record }">
        <span v-if="col.title === '操作'">
          <a-button
            class="table-btn"
            type="link"
            :disabled="record.ops_server_status !== 1"
            @click="handleOperate('single', text)"
          >
            编辑
          </a-button>
        </span>
        <span
          v-else-if="['主机状态', 'lotus状态'].includes(col.title)"
          class="dot"
          :class="text === 1 ? 'online' : 'offline'"
        ></span>
        <custom-tooltip v-else>
          <span v-if="col.title === '软件角色'">
            {{ softwareList.find(item => item.value === text)?.label }}
          </span>
          <span v-else-if="col.title === '是否故障'" :class="{ 'error-text': text === 2 }">
            {{ text === 2 ? '是' : '否' }}
          </span>
          <span v-else>{{ text }}</span>
        </custom-tooltip>
      </template>
    </a-table>
    <div class="total-show">
      <span>总数 : {{ pageVo.total }}</span>
      <span>在线 : {{ statistics.online_size }}</span>
      <span>离线 : {{ statistics.offline_size }}</span>
    </div>
    <a-pagination
      v-bind="{ ...pagerConfigs(pageVo), size: 'small', showTotal: null }"
      class="footer-pager"
      @change="(p, s) => handleSearch({ page: p, page_size: s })"
    />

    <update-root-password-modal
      v-model:visible="updatePwdShow"
      :type="updateType"
      :selected-rows="selectedRows"
      :device-id="updateTargetId"
      :cluster-id="formModel.cluster_id"
      @success="handleSearch(pageVo)"
    />
    <check-root-password-modal
      v-model:visible="checkPwdShow"
      :selected-ids="selectedRows.map(row => row.id)"
    />
    <update-record-modal v-model:visible="recordShow" />
    <update-result-modal v-model:visible="updateResultShow" :update-result="updateResult" />
  </div>
</template>

<style lang="less" scoped>
@import (reference) '@/assets/styles/index.less';

.root-management {
  .search-form {
    position: relative;
  }
  .search-input-item {
    position: absolute;
    right: 0;
  }
  .dot {
    display: inline-block;
    height: 15px;
    width: 15px;
    border-radius: 15px;
    &.online {
      background: @ueColor_third;
    }
    &.offline {
      background: @errorColor;
    }
  }
  .total-show {
    position: absolute;
    bottom: 20px;
    font-size: 14px;
    > span:not(span:last-of-type) {
      margin-right: 43px;
    }
  }
  .footer-pager {
    position: absolute;
    bottom: 20px;
    right: 20px;
  }
  @media screen and (max-width: 1280px) {
    .search-input-item {
      position: unset;
    }
  }
}
</style>
