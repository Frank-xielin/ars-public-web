<script lang="ts" setup>
import { softwareList } from '@/composables/workbench/hostManagement'
import { columns } from '@/composables/workbench/publicCalculate/calculateTable'
import { DeviceListOfRoomItem } from '@/models/workbench/publicCalculate'
import { ref } from 'vue'
import MachineScheduleModal from './MachineScheduleModal.vue'

defineProps<{
  dataSource: DeviceListOfRoomItem[]
  loading: boolean
  pageVo: Utils.PageVO
  selectedRows: DeviceListOfRoomItem[]
}>()
const emit = defineEmits<{
  (event: 'update:selectedRows', val: DeviceListOfRoomItem[]): void
  (event: 'search', vo?: Utils.SearchVO): void
}>()

const scheduleShow = ref(false)
const scheduleTarget = ref<DeviceListOfRoomItem | null>(null)

function selectionHandle(_: Utils.Key[], rows: DeviceListOfRoomItem[]) {
  emit('update:selectedRows', rows as DeviceListOfRoomItem[])
}
function scheduleOneMachine(record: DeviceListOfRoomItem) {
  scheduleTarget.value = record
  scheduleShow.value = true
}
</script>

<template>
  <a-table
    v-bind="$tableConfigs(dataSource, loading, pageVo, vo => $emit('search', vo))"
    class="table-box"
    row-key="device_sn"
    :scroll="{ ...$scroller('calc(100vh - 350px)'), x: 'main-content' }"
    :columns="$columnsSetter(columns)"
    :row-selection="
      $tableSelection({
        fixed: true,
        selectedRowKeys: selectedRows.map(row => row.device_sn),
        getCheckboxProps: r => ({ disabled: !r.is_can_schedule }),
        onChange: selectionHandle
      })
    "
  >
    <template #bodyCell="{ column: col, text, record }">
      <a-button
        v-if="col.title === '操作'"
        type="link"
        :disabled="!record.is_can_schedule || !$auth(174)"
        class="table-btn"
        @click="scheduleOneMachine(record)"
      >
        调度
      </a-button>
      <span
        v-else-if="['服务状态', 'lotus状态'].includes(col.title)"
        class="dot"
        :class="text === 1 ? 'online' : 'offline'"
      ></span>
      <custom-tooltip v-else>
        <span v-if="col.title === '软件角色'">
          {{ softwareList.find(item => item.value === text)?.label }}
        </span>
        <span v-else-if="col.title === '是否故障'" :class="{ 'error-text': text !== 1 }">
          {{ text === 1 ? '否' : '是' }}
        </span>
        <span v-else>{{ text }}</span>
      </custom-tooltip>
    </template>
  </a-table>
  <machine-schedule-modal
    v-model:visible="scheduleShow"
    :selected-rows="scheduleTarget ? [scheduleTarget] : []"
    @search="$emit('search', pageVo)"
  />
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.dot {
  display: inline-block;
  height: 15px;
  width: 15px;
  border-radius: 15px;
  &.online {
    background: @ueColor_third;
  }
  &.offline {
    background: @errorColor;
  }
}
</style>
