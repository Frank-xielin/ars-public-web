<script lang="ts" setup>
import { FormRenderExpose } from '@/components/FormRender.vue'
import { analysisHttpbody } from '@/composables/home/approval'
import {
  approvalTypeList,
  columns,
  getDeviceOfBody,
  initialValues,
  useSearchCurrentLoginHistory
} from '@/composables/personal/myApprovals'
import { FormRenderOptions } from '@/models/formRender'
import { ApprovalListItem, ApprovalListParams } from '@/models/systemSettings/approvalProcess'
import { scroller } from '@/utils/formTools'
import { Dayjs } from 'dayjs'
import { ref } from 'vue'

const formRef = ref<FormRenderExpose | null>(null)
const visible = ref(false)
const selectedInfo = ref<any | null>(null)
const isCheck = ref(false)

const { searchModel, dataSource, pageVo, handleSearch } = useSearchCurrentLoginHistory()

interface SearchForm extends Utils.NoPager<ApprovalListParams> {
  dates?: [Dayjs, Dayjs]
}

const tableOps = (): FormRenderOptions<SearchForm, ApprovalListItem> => ({
  queryParams: [
    {
      label: 'state',
      type: 'select',
      style: { width: '100px' },
      selectOptions: { data: approvalTypeList }
    },
    {
      label: 'dates',
      type: 'date-picker',
      range: ['start_date', 'end_date'],
      itemStyle: { position: 'absolute', right: '210px' }
    },
    {
      label: 'search',
      type: 'search',
      placeholder: '输入关键字进行搜索',
      itemStyle: { position: 'absolute', right: 0 }
    }
  ],
  initialValues,
  tableConfigs: {
    columns,
    tableProps: { scroll: scroller('calc(100vh - 350px)'), rowKey: 'id' },
    async onSearch(values, vo) {
      searchModel.value = { ...values }
      await handleSearch(vo)
      return { res: dataSource.value, vo: pageVo.value }
    }
  }
})

const approveTarget = (record: ApprovalListItem, check = false) => {
  selectedInfo.value = { ...record }
  isCheck.value = check
  visible.value = true
}
</script>

<template>
  <div class="my-approvals page">
    <form-render ref="formRef" :op="tableOps()">
      <template #tableRender="{ column: col, text, record }">
        <div v-if="col.title === '操作'">
          <a-button
            v-if="record.state <= 1"
            type="link"
            class="table-btn"
            @click="approveTarget(record)"
          >
            去审核
          </a-button>
          <a-button type="link" class="table-btn" @click="approveTarget(record, true)">
            查看
          </a-button>
        </div>
        <custom-tooltip
          v-else-if="col.title === '状态'"
          :title="approvalTypeList.find(item => item.value === text)?.label"
        >
          <a-tag :color="approvalTypeList.find(item => item.value === text)?.color">
            {{ approvalTypeList.find(item => item.value === text)?.label }}
          </a-tag>
        </custom-tooltip>
        <custom-tooltip v-else>
          <span v-if="col.title === '提交时间'">{{ text.submit_at }}</span>
          <span v-else-if="col.title === '集群'">
            {{ analysisHttpbody(text.http_body).miner_id }}
          </span>
          <span v-else-if="col.title === '类型'">
            {{ text.includes('operation') ? '操作审批' : '任务审批' }}
          </span>
          <span v-else-if="col.title === '名称'">{{ text.name }}</span>
          <span v-else-if="col.title === '目标主机'">{{ getDeviceOfBody(text.http_body) }}</span>
          <span v-else-if="col.title === '提交人'">{{ text.user_name }}</span>
          <span v-else>{{ text }}</span>
        </custom-tooltip>
      </template>
    </form-render>
    <span class="tips"><u>*目前仅包含操作审批</u></span>
    <approval-toast
      v-model:visible="visible"
      :record-toast="selectedInfo"
      :readonly="isCheck"
      @is-agree-operate="formRef?.onSearch(pageVo)"
    />
  </div>
</template>

<style scoped lang="less">
.search-form {
  position: relative;
  .input-form-item {
    position: absolute;
  }
}
.tips {
  position: absolute;
  right: 40px;
  margin-top: 20px;
  font-size: 12px;
}
</style>
