import { PropType } from 'vue'

/**
 * 复杂对象类型
 * @requires
 */
export function objectType<T>() {
  return { type: Object as PropType<T>, required: true as const }
}

/**
 * 复杂数组类型
 * @requires
 */
export function arrayType<T>() {
  return { type: Array as PropType<T[]>, required: true as const }
}

/**
 * 基础数据类型
 * @param type
 * @requires
 */
export function baseType<T extends NumberConstructor | StringConstructor | BooleanConstructor>(
  type: T
) {
  return { type, required: true as const }
}

/**
 * 特殊字符类型
 * @requires
 */
export function strType<T extends string>() {
  return { type: String as unknown as PropType<T>, required: true as const }
}
