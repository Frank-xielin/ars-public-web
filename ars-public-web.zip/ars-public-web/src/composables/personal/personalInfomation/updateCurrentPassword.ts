import { UpdatePwCodeParams } from '@/models/login'
import { updatePwCodepi } from '@/services/login'
import { RSAEncryption } from '@/utils/cryptage'
import { Form, message } from 'ant-design-vue'
import { ref } from 'vue'
import { codeValidator, useVerifyCode } from '../../login/account'
import { requireInput } from '../../systemSettings/clusterInformation/addEditCluster'

const crypto = new RSAEncryption()

export function useUpdateCurrentPw(successFn: () => void) {
  const formModel = ref<UpdatePwCodeParams>({
    new_password: '',
    phone: '',
    sms_code: ''
  })
  const rules = ref<Utils.RulesObject<UpdatePwCodeParams>>({
    phone: [requireInput('手机号')],
    new_password: [requireInput('新密码')],
    sms_code: [
      requireInput('验证码'),
      { validator: (_, val) => codeValidator(val, codeError.value) }
    ]
  })
  const form = Form.useForm(formModel, rules)
  const { codeError, checkCode } = useVerifyCode(formModel, () => form.validate('sms_code'))

  async function submitForm() {
    try {
      await form.validate()
      const isValidCode = await checkCode('modify_passwd')
      if (!isValidCode) {
        return
      }
      const params: UpdatePwCodeParams = {
        ...formModel.value,
        new_password: crypto.encode(formModel.value.new_password) || ''
      }
      const reply = await updatePwCodepi(params)
      if (reply.code === 0) {
        message.success('密码修改成功')
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { form, formModel, submitForm }
}
