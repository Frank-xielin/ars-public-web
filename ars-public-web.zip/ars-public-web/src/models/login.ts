export type SmsCodeType = 'login' | 'modify_passwd'

export interface SmsCheckParams {
  phone: string
  sms_type: SmsCodeType
  sms_code: string
}

export interface SmsCheckRes {
  sms_code: string
  is_expired: boolean
  expire_sec: number
}

export interface SmsByPhoneParams {
  phone: string
  sms_type: SmsCodeType
}

export interface LoginParams {
  phone: string
  password: string
  sms_code: string
}

export interface LoginRes {
  user_id: number
  token: string
  passwd_err_cnt: number
  is_disable: boolean
  is_locked: boolean
  locked_remaining_time: number
  is_passwd_expired: boolean
}

export interface UpdatePwCodeParams {
  phone: string
  sms_code: string
  new_password: string
}

export interface UpdatePwOriginParams {
  phone: string
  original_password: string
  new_password: string
}

export interface CodeByMinerRes {
  code: string
  user_id: number
  domain: string
  miner_id: string
}

export interface TokenByCodeRes {
  user_id: number
  token: string
  expires_at: number
}

export interface UserInfoOfToken {
  buffer_time: number
  exp: number
  iss: string
  nbf: number
  nick_name: string
  permission: number
  phone: string
  role_id: number
  user_id: number
  user_name: string
}
