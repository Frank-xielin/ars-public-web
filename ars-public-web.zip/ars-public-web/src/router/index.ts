import { useMainStore } from '@/store'
import { routerBeforeEach } from '@/utils/routerController'
import { createRouter, createWebHashHistory, RouteRecordRaw } from 'vue-router'

export const routes: RouteRecordRaw[] = [
  {
    path: '/Login',
    name: 'Login',
    component: () => import('@/views/Login.vue')
  },
  {
    path: '/Personal/PersonalInfomation',
    name: 'PersonalInfomation',
    meta: { name: 'PersonalInfomation', title: '个人信息' },
    component: () => import('@/views/Personal/PersonalInfomation.vue')
  },
  {
    path: '/Personal/MyApprovals',
    name: 'MyApprovals',
    meta: { name: 'MyApprovals', title: '我的审批' },
    component: () => import('@/views/Personal/MyApprovals.vue')
  },
  {
    path: '/Personal/MyMessages',
    name: 'MyMessages',
    meta: { name: 'MyMessages', title: '我的消息' },
    component: () => import('@/views/Personal/MyMessages.vue')
  },
  {
    path: '/Personal/LoginHistory',
    name: 'LoginHistory',
    meta: { name: 'LoginHistory', title: '登录历史' },
    component: () => import('@/views/Personal/LoginHistory.vue')
  },
  {
    path: '/:catchAll(.*)',
    component: () => import('@/views/NotFound.vue')
  }
]

const router = createRouter({
  routes,
  history: createWebHashHistory()
})

// 解决没登陆就能去主页的问题
router.beforeEach(routerBeforeEach)
router.afterEach(() => {
  const store = useMainStore()
  store.$patch({ routerLoading: false })
})

export default router
