import { createScriptTypeApi } from '@/services/jobManagement/publishScript'
import { message } from 'ant-design-vue'
import { ref } from 'vue'

/**
 * 创建脚本类型
 * @param successFn
 * @returns
 */
export function useCreateScriptType(successFn: () => void) {
  const name = ref('')

  async function createType() {
    if (!name.value) {
      message.warn('请输入名称')
      return
    }
    try {
      const reply = await createScriptTypeApi(name.value)
      if (reply.code === 0) {
        message.success('添加成功')
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { name, createType }
}
