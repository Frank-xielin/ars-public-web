<script lang="tsx">
import { Tooltip } from 'ant-design-vue'
import { defineComponent } from 'vue'

export default defineComponent({
  inheritAttrs: false,
  props: { title: String },
  setup(props, { slots }) {
    return () => (
      <Tooltip color="#fff" placement="bottom" title={props.title ?? slots.default?.()}>
        {slots.default?.()}
      </Tooltip>
    )
  }
})
</script>
