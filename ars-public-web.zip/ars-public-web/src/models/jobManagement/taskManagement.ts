import { ClusterListItem } from '../systemSettings/clusterInformation'
import { UserInfoByIdRes } from '../systemSettings/userManagement/user'
import { ScriptListItem } from './publishScript'

export interface TaskManagementParams extends Utils.SearchVO {
  state: number | ''
  search: string
  start_date: string
  end_date: string
}

export interface CreateTaskParams {
  name: string
  miner: string
  device_sn_list: {
    device_sn: string
    software_type: number
  }[]
  script_id: number | undefined
  script_content: string
  script_params: string
  timeout: number
  exec_user: string
  note: string
  auto_submit: boolean
}

export interface CreateTaskRes {
  auto_publish: boolean
  auto_submit: boolean
  created_at: string
  creator: UserInfoByIdRes | null
  creator_id: number
  deleted_at: string | null
  exec_user: string
  id: number
  miner: ClusterListItem
  miner_id: number
  name: string
  note: string
  publish_uuid: string
  published_at: string
  publisher: null
  publisher_id: number
  script: null
  script_content: string
  script_id: number
  script_params: string
  state: number
  timeout: number
  updated_at: string
  updater: UserInfoByIdRes | null
  updater_id: number
}

export interface AchieveApprovalRes extends Utils.PageVO {
  list: AchieveApprovalIdItem[]
}
export interface AchieveApprovalIdItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string
  target_id: number
  target_type: string
  target: {
    id: number
    created_at: string
    updated_at: string
    deleted_at: null
    name: string
    route: string
    http_text: string
    http_body: string
    submiter_id: number
    submiter: UserInfoByIdRes
    submit_at: string
    state: number
  }
  state: number
  submitor_id: number
  submitor: UserInfoByIdRes
  total_step: number
  current_step: number
  current_node_id: number
  current_node: {
    id: number
    flow_id: number
    step: number
    title: string
    created_at: string
    updated_at: string
    note: string
    state: number
    approver_id: number
    approver: UserInfoByIdRes | null
  }
  notifiers: UserInfoByIdRes[]
}

export type UpdateTaskParams = CreateTaskParams

export interface SubmitTaskParams {
  id: number
  created_at: string
  updated_at: string
  deleted_at: null
  title: string
  target_id: number
  target_type: string
  target: null
  state: number
  submitor_id: number
  submitor: UserInfoByIdRes
  total_step: number
  current_step: number
  current_node_id: number
  current_node: {
    id: number
    flow_id: number
    step: number
    title: string
    created_at: string
    updated_at: string
    note: string
    state: number
    approver_id: number
    approver: null
  }
  notifiers: []
}

export interface PublishTaskParams {
  uuid: string
  publisher: UserInfoByIdRes
  pulished_at: string
}

export interface TaskManagementItem {
  id: number
  created_at: string
  name: string
  miner: string
  creator: string
  devices: string
  device_list: {
    device_sn: string
    software_type: number
  }[]
  state: number
  exec_user: string
  note: string
  script_content: string
  script_params: string
  timeout: number
  updated_at: string
  updater: string
  // miner_id: number
  script_id: number
  script: ScriptListItem
  // timeout: number
  // exec_user: string
  // note: string
  // creator_id: number
  // creator: UserInfoByIdRes | null
  // updater_id: number
  // updater: UserInfoByIdRes | null
  // submiter_id: number
  // submiter: UserInfoByIdRes | null
  // submit_at: string
  // publisher_id: number
  publisher: UserInfoByIdRes
  // auto_submit: boolean
  // auto_publish: boolean
  published_at: string
  publish_uuid: string
  publish_name: string
}

export interface TaskManagementRes extends Utils.PageVO {
  list: TaskManagementItem[]
}

export type ViewTaskRes = TaskManagementItem

export interface ApprovalTaskParams {
  action: 'approve' | 'reject'
  note: string
}

export interface GetApprovalInfoRes {
  id: number
  created_at: string
  updated_at: string
  deleted_at: null
  target_id: number
  target_type: string
  target: {
    id: number
    created_at: string
    updated_at: string
    deleted_at: null
    name: string
    route: string
    http_text: string
    http_body: string
    submiter_id: number
    submiter: UserInfoByIdRes
    submit_at: string
    state: number
  }
  state: number
  submitor_id: number
  submitor: UserInfoByIdRes
  total_step: number
  current_step: number
  current_node_id: number
  current_node: {
    id: number
    flow_id: number
    step: number
    title: string
    created_at: string
    updated_at: string
    note: string
    state: number
    approver_id: number
    approver: UserInfoByIdRes | null
  }
  notifiers: UserInfoByIdRes[]
}
