import { message, TableProps, Tooltip, TablePaginationConfig } from 'ant-design-vue'
import { TableRowSelection } from 'ant-design-vue/lib/table/interface'
import { cloneDeep, isBoolean, pick } from 'lodash-es'

/**
 * 清空表单，仅对对象第一层做处理
 * @param target
 */
export function formDataClean<T extends Utils.Dict>(target: T) {
  const obj = cloneDeep(target) as Utils.Dict
  Object.keys(obj).forEach(key => {
    if (typeof obj[key] === 'string') {
      obj[key] = ''
    }
  })
  return obj as T
}

/**
 * 检查手机号合法性
 * @param phone
 */
export function checkMobileNumber(phone: string) {
  const reg = /(1[3-9]\d{9}$)/
  return reg.test(phone)
}

/**
 * 检查邮箱的合法性
 * @param email
 */
export function checkEmailFormat(email: string) {
  const reg = /^\w+((.\w+)|(-\w+))@[A-Za-z0-9]+((.|-)[A-Za-z0-9]+).[A-Za-z0-9]+$/
  return reg.test(email)
}

/**
 * 下载文件
 * @param data 文件流
 * @param fileName 文件名
 * @param suffix 后缀名
 */
export function downloadFile(data: BlobPart, fileName: string, suffix: string) {
  const blob = new Blob([data])
  const fullName = fileName + suffix
  const elink = document.createElement('a')
  elink.download = fullName
  elink.style.display = 'none'
  elink.href = URL.createObjectURL(blob)
  document.body.appendChild(elink)
  elink.click()
  URL.revokeObjectURL(elink.href)
  document.body.removeChild(elink)
}

/**
 * 筛选返回数据中的分页信息
 * @param obj
 */
export function pagerSetter<T extends Utils.PageVO>(obj: T) {
  return pick(obj, ['page', 'page_size', 'total'])
}

/** 自定义必填校验 */
export function requireChecker(baseMsg: string, pos: 'start' | 'end' = 'start') {
  return function (msg: string) {
    const messages = [baseMsg]
    pos === 'start' ? messages.push(msg) : messages.unshift(msg)
    return {
      required: true,
      message: messages.join('')
    }
  }
}

/**
 * 通用的表格列设置
 * @param tableItem
 * @param showTip 默认开启 tooltip，如需关闭请赋值 false
 * @returns
 */
export const columnConfig = (tableItem: Utils.ColumnField<any>, showTip = true) => {
  const { title, dataIndex, width, sorter } = tableItem

  return {
    title,
    dataIndex,
    width,
    sorter,
    align: 'center',
    ellipsis: showTip
  } as any
}

/**
 * 通用的表格设置（不使用 Table.Column）
 * @param columns
 * @returns
 */
export function columnsSetter(columns: Utils.ColumnField<any>[]): TableProps['columns'] {
  return columns.map(col => ({
    ...columnConfig(col),
    ...col,
    key: col.dataIndex
  }))
}

/**
 * 设置操作完成后的弹窗内容
 * @param successDesc
 * @returns
 */
export function requestHandler(successDesc: string) {
  return (reply: Utils.Result<unknown>) => {
    if (reply.code === 0) {
      message.success(successDesc)
    } else {
      message.error(reply.msg)
    }
  }
}

/**
 * 紧凑型的斑马纹表格
 * @param dataSource 表格数据
 * @param loading 控制加载动画
 * @param vo 分页器
 * @param searchFn 搜索函数
 * @returns
 */
export function tableConfigs(
  dataSource?: any[],
  loading?: boolean,
  vo?: Utils.PageVO,
  searchFn?: (pager: Utils.SearchVO) => void
): TableProps {
  return {
    dataSource: dataSource || [],
    rowClassName: (_, index: number) => {
      let className = 'light-row'
      index % 2 === 1 && (className = 'dark-row')
      return className
    },
    size: 'small',
    loading,
    locale: {
      emptyText: (
        <div class="ant-empty-normal">
          <div class="ant-empty-image" style="height: 25vh">
            <img src="/empty_table.svg" height="100%" />
          </div>
          <p class="ant-empty-description empty-desc">这里空空如也</p>
        </div>
      )
    } as any,
    pagination: vo ? pagerConfigs(vo) : false,
    onChange: (pager: TableProps['pagination']) => {
      if (!isBoolean(pager) && pager) {
        searchFn?.({ page: pager.current || 1, page_size: pager.pageSize || vo?.page_size || 20 })
      }
    }
  }
}

/**
 * 带 tooltip 的表格内容
 * @param content
 * @param title
 * @returns
 */
export function contentByTips(content: any, title: string, ...excludes: string[]) {
  if (['详情', '操作'].includes(title) || excludes.includes(title)) {
    return content
  }
  return (
    <Tooltip placement="bottom" title={content} color="#fff">
      {content}
    </Tooltip>
  )
}

/**
 * 设置表格的最大高度
 * @param y 高度
 * @returns
 */
export function scroller(y: string | number): TableProps['scroll'] {
  return { scrollToFirstRowOnChange: true, y }
}

/** 分页器公共设置 */
export function pagerConfigs(vo: Utils.PageVO): TablePaginationConfig {
  return {
    hideOnSinglePage: false,
    showSizeChanger: true,
    showQuickJumper: false,
    position: ['bottomRight'],
    showTotal: (total: number) => `总数：${total}`,
    current: vo.page,
    pageSize: vo.page_size,
    total: vo.total
  }
}

/**
 * 表格的选择器设置 - 类型增强
 * @param op
 * @returns
 */
export function tableSelection<T>(op: TableRowSelection<T>): TableRowSelection<any> {
  return op
}
