export interface ApprovalToastParams extends Utils.SearchVO {
  search: string
  start_date: string
  end_date: string
}

export interface ApprovalToastItem {
  id: number
  flow_id: number
  step: number
  title: string
  created_at: string
  updated_at: string
  note: string
  state: number
  approver_id: number
  approver: {
    id: number
    created_at: string
    updated_at: string
    deleted_at: null
    phone: string
    status: number
    user_name: string
    created_by: number
    updated_by: number
    nick_name: string
    email: string
    avatar: string
    introduction: string
    last_login: string
    passwd_last_updated: string
    client_id: number
    leader: boolean
    approve: boolean
    enable: boolean
  }
}

export type ApprovalToastRes = ApprovalToastItem[]
