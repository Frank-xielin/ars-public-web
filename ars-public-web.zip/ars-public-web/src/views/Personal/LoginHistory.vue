<script lang="ts" setup>
import { loginStatusList, useLoginLogs } from '@/composables/logManagement/loginLog'
import { historyCols } from '@/composables/personal/personalInfomation'

const { dataSource, pageVo, loading, handleSearch } = useLoginLogs()

handleSearch()
</script>

<template>
  <div class="login-history page">
    <h3 class="block-title">
      登录历史
      <span class="tips">如果发现非本人登录，请及时修改密码</span>
    </h3>
    <a-table
      v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
      :columns="$columnsSetter(historyCols)"
      row-key="id"
      :scroll="$scroller('calc(100vh - 330px)')"
    >
      <template #bodyCell="{ column: col, text, record }">
        <custom-tooltip>
          <span :class="{ 'error-text': record.is_abnormal === 1 }">
            <span v-if="col.title === '登录结果'">
              {{ text === 0 ? '成功' : '失败' }}
            </span>
            <template v-else-if="col.title === '状态'">
              {{ loginStatusList.find(item => item.value === text)?.label }}
            </template>
            <template v-else>{{ text }}</template>
          </span>
        </custom-tooltip>
      </template>
    </a-table>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';
.login-history {
  padding-top: 0 !important;
}
.block-title {
  height: 44px;
  margin: 0 0 36px;
  padding-left: 24px;
  font-size: 14px;
  font-weight: bold;
  color: @textColor_first;
  line-height: 44px;
  border-bottom: 1px solid @ueColor_fifth;
  .tips {
    margin-left: 50px;
    font-size: 12px;
    color: @textColor_third;
  }
}
</style>
