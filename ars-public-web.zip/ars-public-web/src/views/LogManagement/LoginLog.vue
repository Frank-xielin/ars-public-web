<script lang="ts" setup>
import { columns, loginStatusList, useLoginLogs } from '@/composables/logManagement/loginLog'
import { useUserManager } from '@/composables/systemSettings/userManagement/user/userManageTab'

const { pageVo, dataSource, searchModel, loading, handleSearch } = useLoginLogs()
const { dataSource: userList, handleSearch: getUsers } = useUserManager()

function onSearch(vo?: Utils.SearchVO) {
  handleSearch(vo)
  getUsers({ page: 1, page_size: 10000 })
}
onSearch()
</script>

<template>
  <div class="login-log page">
    <a-form layout="inline" class="search-form" @submit="onSearch()">
      <a-form-item label="状态">
        <custom-select
          :data="loginStatusList"
          v-model:value="searchModel.is_abnormal"
          @change="onSearch()"
        />
      </a-form-item>
      <a-form-item class="search-right-item">
        <a-range-picker
          separator="至"
          format="YYYY-MM-DD HH:mm:ss"
          v-model:value="searchModel.dates"
          @change="onSearch()"
        />
        <a-button type="primary" html-type="submit" style="margin-left: 20px">搜索</a-button>
      </a-form-item>
    </a-form>

    <a-table
      v-bind="$tableConfigs(dataSource, loading, pageVo, onSearch)"
      class="table-box"
      row-key="id"
      :scroll="$scroller('calc(100vh - 340px)')"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ column: col, record, text }">
        <custom-tooltip>
          <span :class="{ 'error-text': record.is_abnormal === 1 }">
            <span v-if="col.title === '登录结果'">
              {{ text === 0 ? '成功' : '失败' }}
            </span>
            <span v-else-if="col.title === '状态'">
              {{ loginStatusList.find(item => item.value === text)?.label }}
            </span>
            <span v-else-if="col.title === '用户名'">
              {{ userList.find(item => item.id === text)?.user_name }}
            </span>
            <span v-else>{{ text }}</span>
          </span>
        </custom-tooltip>
      </template>
    </a-table>
  </div>
</template>

<style scoped lang="less">
.search-form {
  position: relative;

  .search-right-item {
    position: absolute;
    right: 20px;
  }
}
</style>
