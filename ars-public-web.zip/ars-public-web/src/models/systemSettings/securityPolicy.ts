export interface GetPwTacticRes {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string
  first_login_err_lock: number
  second_login_err_lock: number
  third_login_err_lock: number
  passwd_length: number
  passwd_expired: number
  passwd_err_try_cnt: number
  passwd_verify: string
  sms_expired: number
}

export interface UpdatePwTacticParams {
  passwd_length: number
  passwd_expired: number
  passwd_err_try_cnt: number
  first_login_err_lock: number
  second_login_err_lock: number
  third_login_err_lock: number
  root_passwd_validity: number
}
