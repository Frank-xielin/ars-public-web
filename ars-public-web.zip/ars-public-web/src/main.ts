import '@/assets/styles/index.less'
import '@/components/AntComponents'
import 'dayjs/locale/zh-cn'
import { createPinia } from 'pinia'
import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import { componentRegistration } from './utils/vue-tools/globalComponents'
import { functionRegistration } from './utils/vue-tools/globalFunc'

const app = createApp(App)
app.use(router).use(createPinia())
componentRegistration(app)
functionRegistration(app)

app.mount('#app')
