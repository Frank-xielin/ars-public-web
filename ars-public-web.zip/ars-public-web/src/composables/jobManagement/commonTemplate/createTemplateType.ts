import { createTemplateTypeApi } from '@/services/jobManagement/commonTemplate'
import { message } from 'ant-design-vue'
import { ref } from 'vue'

/** 创建模板类型 */
export function useCreateTemplateType(successFn?: () => void) {
  const name = ref('')

  async function createType() {
    try {
      const reply = await createTemplateTypeApi(name.value)
      if (reply.code === 0) {
        message.success('添加模板类型成功')
        name.value = ''
        successFn?.()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { name, createType }
}
