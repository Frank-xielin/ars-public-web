import { UserInfoByIdRes } from '../userManagement/user'
import { NotifyChannelListItem } from './createApprovalTemp'

export interface ApprovalTempListItem {
  id: number
  title: string
  approver1_id: number | null
  approver1: UserInfoByIdRes | null
  approver2_id: number | null
  approver2: UserInfoByIdRes | null
  approver3_id: number | null
  approver3: UserInfoByIdRes | null
  notifiers: UserInfoByIdRes[]
  notify_channels: NotifyChannelListItem[]
  enabled: boolean
  created_at: string
  updated_at: string
  creator_id: number
  creator: UserInfoByIdRes | null
  updater_id: number
  updater: UserInfoByIdRes | null
  func_apis: FuncApiObject[]
  tag: string
}

export interface FuncApiObject {
  id: number
  api_method: string
  created_at: string
  need_approval: boolean
  domain: string
  api_route_group: string
  deleted_at: string | null
  title: string
  updated_at: string
  menu_id: number
  api_desc: string
  name: string
  status: number
}

export type ApprovalTempAllListRes = ApprovalTempListItem[]

export interface BindOpsByApprovalParams {
  func_api_ids: number[]
}

export interface ApprovalListParams extends Utils.SearchVO {
  target_type: 'task' | 'operation'
  state: number | ''
  start_date: string
  end_date: string
  search: string
  /** 是否只展示当前用户参与的审批，1为是 */
  only_participated: number
}

export interface ApprovalListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string | null
  target_id: number
  target_type: string
  target: {
    id: number
    created_at: string
    updated_at: string
    deleted_at: string | null
    name: string
    route: string
    http_text: string
    http_body: string
    submiter_id: number
    submiter: UserInfoByIdRes
    submit_at: string
    state: number
  }
  state: number
  submitor_id: number
  submitor: UserInfoByIdRes
  total_step: number
  current_step: number
  current_node_id: number
  current_node: {
    id: number
    flow_id: number
    step: number
    title: string
    created_at: string
    updated_at: string
    note: string
    state: number
    approver_id: number
    approver: UserInfoByIdRes
  }
  notifiers: UserInfoByIdRes[]
}

export interface ApprovalListRes extends Utils.PageVO {
  list: ApprovalListItem[]
}
