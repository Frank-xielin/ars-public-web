import {
  AchieveApprovalRes,
  ApprovalTaskParams,
  CreateTaskParams,
  CreateTaskRes,
  GetApprovalInfoRes,
  PublishTaskParams,
  SubmitTaskParams,
  TaskManagementParams,
  TaskManagementRes,
  UpdateTaskParams,
  ViewTaskRes
} from '@/models/jobManagement/taskManagement'
import { request } from '@/utils/httpConfig'

/** 获取全部任务 */
export function allTaskApprovalApi(data: TaskManagementParams) {
  return request<TaskManagementRes>({
    url: 'v5/public/task/get/all',
    method: 'get',
    data,
    loading: true
  })
}

/** 任务获取 - 分页 */
export function taskManagementApi(data: TaskManagementParams) {
  return request<TaskManagementRes>({
    url: 'v5/public/task/get/list',
    method: 'get',
    data,
    loading: true
  })
}
/** 任务获取 - 单个 */
export function viewTasktApi(id: number) {
  return request<ViewTaskRes>({
    url: `v5/public/task/get/id/${id}`,
    method: 'get',
    loading: true
  })
}

/** 获取审批流ID */
export function achieveApprovalApi(target_id: number) {
  return request<AchieveApprovalRes>({
    url: 'v5/public/approval/get/list',
    method: 'get',
    data: { target_id },
    loading: true
  })
}

/** 任务创建 - 单个 */
export function createTaskApi(data: CreateTaskParams) {
  return request<CreateTaskRes>({
    url: 'v5/public/task/create/one',
    method: 'post',
    loading: true,
    data
  })
}
/** 任务修改 - 单个 */
export function upadateTaskApi(id: number, data: UpdateTaskParams) {
  return request({
    url: `v5/public/task/update/id/${id}`,
    method: 'put',
    data,
    loading: true
  })
}
/** 任务删除 - 单个 */
export function deleteTaskApi(id: number) {
  return request({
    url: `v5/public/task/delete/id/${id}`,
    method: 'delete',
    loading: true
  })
}
/** 任务提交审核 - 单个 */
export function submitTaskApi(id: number, auto_publish: boolean) {
  return request<SubmitTaskParams>({
    url: `v5/public/task/submit/id/${id}`,
    method: 'patch',
    data: { auto_publish },
    loading: true
  })
}
/** 任务发布 - 单个 */
export function publishTaskApi(id: number) {
  return request<PublishTaskParams>({
    url: `v5/public/task/publish/id/${id}`,
    method: 'patch',
    loading: true
  })
}
/** 任务批准或拒绝  */
export function approvalTaskApi(id: number, data: ApprovalTaskParams) {
  return request({
    url: `v5/public/approval/action/id/${id}`,
    method: 'patch',
    data,
    loading: true
  })
}

/**
 * 审批流获取 - 单个
 * @param approvalId 审批流 id
 */
export function getApprovalInfoIApi(approvalId: number) {
  return request<GetApprovalInfoRes>({
    url: `v5/public/approval/get/id/${approvalId}`,
    method: 'get',
    loading: true
  })
}
