<script lang="ts" setup>
import { FormRenderExpose } from '@/components/FormRender.vue'
import {
  columns,
  useDeleteScript,
  useEnableScript,
  useScriptAllList
} from '@/composables/jobManagement/publishScript'
import { useScriptTypeAllList } from '@/composables/jobManagement/publishScript/scriptTypeTable'
import { FormRenderOptions } from '@/models/formRender'
import { ScriptListItem, ScriptListParams } from '@/models/jobManagement/publishScript'
import router from '@/router'
import { scroller } from '@/utils/formTools'
import { cloneDeep } from 'lodash-es'
import { computed, ref } from 'vue'

const formRef = ref<FormRenderExpose>()
const { searchModel, dataSource, searchScriptList } = useScriptAllList()
const { dataSource: typeList, run: getTypeList } = useScriptTypeAllList()
const { deleteScript } = useDeleteScript(() => formRef.value?.onSearch())
const { enableScript } = useEnableScript(() => formRef.value?.onSearch())

const types = computed(() => {
  const arr = cloneDeep(typeList.value)
  arr.unshift({ created_at: '', id: 0, name: '全部', updated_at: '' })
  return arr
})
const formOp = (): FormRenderOptions<Utils.NoPager<ScriptListParams>, ScriptListItem> => {
  return {
    queryParams: [
      {
        label: 'type_id',
        formLabel: '脚本类型',
        type: 'select',
        style: { width: '150px' },
        selectOptions: {
          data: types.value,
          labelField: 'name',
          valueField: 'id'
        }
      },
      { label: 'name', type: 'search', placeholder: '请输入脚本名称' }
    ],
    initialValues: { type_id: 0, name: '', enabled: '' },
    tableConfigs: {
      columns,
      tableProps: { rowKey: r => r.id, scroll: scroller('calc(100vh - 330px)') },
      async onSearch(values, vo) {
        searchModel.value = { ...values }
        await searchScriptList(vo)
        getTypeList()
        return { res: dataSource.value }
      }
    }
  }
}

function checkUpdateScript(id: number, type: 'edit' | 'check') {
  router.push({
    path: '/JobManagement/PublishScript/CheckScript',
    query: { id, type }
  })
}
</script>

<template>
  <div class="publish-script page">
    <form-render :op="formOp()" ref="formRef">
      <template #lastItem>
        <a-form-item class="add-operator">
          <a-button
            type="primary"
            @click="$router.push('/JobManagement/PublishScript/CreateScript')"
            :disabled="!$auth(47, 'menu')"
          >
            <icon-font type="icon-icon_add" style="color: #fff" />
            添加脚本
          </a-button>
        </a-form-item>
      </template>
      <template #tableRender="{ column, text, record }">
        <template v-if="column.title === '操作'">
          <a-button
            type="link"
            class="table-btn"
            @click="checkUpdateScript(text, 'check')"
            :disabled="!$auth(48, 'menu')"
          >
            查看
          </a-button>
          <a-button
            v-if="!record.enabled"
            type="link"
            class="table-btn"
            @click="checkUpdateScript(text, 'edit')"
            :disabled="!$auth(99)"
          >
            编辑
          </a-button>
          <a-button
            type="link"
            v-if="!record.enabled"
            class="table-btn"
            @click="deleteScript(text)"
            :disabled="!$auth(102)"
          >
            删除
          </a-button>
          <a-button
            type="link"
            class="table-btn"
            @click="enableScript(text, !record.enabled)"
            :disabled="!$auth(103)"
          >
            {{ record.enabled ? '停用' : '启用' }}
          </a-button>
        </template>
        <template v-else-if="column.title === '启用'">
          <icon-font v-if="text" type="icon-normal" />
          <span v-else>-</span>
        </template>
        <custom-tooltip v-else>{{ text }}</custom-tooltip>
      </template>
    </form-render>
  </div>
</template>

<style scoped lang="less">
.add-operator {
  position: absolute;
  right: 0;
}
</style>
