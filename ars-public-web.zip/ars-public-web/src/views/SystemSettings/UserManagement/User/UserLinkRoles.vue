<script lang="ts" setup>
import { useRoleAllList } from '@/composables/systemSettings/userManagement/role'
import { RoleListItem } from '@/models/systemSettings/userManagement/role'
import { UserListItem } from '@/models/systemSettings/userManagement/user'
import { userLinkRolesApi } from '@/services/systemSettings/userManagement/user'
import { message } from 'ant-design-vue'
import { computed, ref, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  record: UserListItem | null
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()

const columns: Utils.ColumnField<RoleListItem>[] = [{ title: '角色名', dataIndex: 'name' }]
const selectedRows = ref<number[]>([])

const { dataSource, loading, handleSearch } = useRoleAllList()
const roleList = computed(() => dataSource.value.filter(item => item.id > 3))

function selectionHandle(keys: Utils.Key[]) {
  selectedRows.value = keys as number[]
}
async function onSubmit() {
  if (!selectedRows.value.length) {
    message.warn('至少选择一个角色！')
    return
  }
  const reply = await userLinkRolesApi({
    user_id: props.record?.id || 0,
    role_ids: [...new Set(selectedRows.value)]
  })
  if (reply.code === 0) {
    message.success('关联角色成功')
    emit('update:visible', false)
    emit('search')
  } else {
    message.error(reply.msg)
  }
}

watch(
  () => props.visible,
  visible => {
    if (visible) {
      selectedRows.value.push(...(props.record?.roles?.map(r => r.id) || []))
      handleSearch({ page: 1, page_size: 10000 })
    } else {
      selectedRows.value.length = 0
    }
  }
)
</script>

<template>
  <a-modal
    :visible="visible"
    title="关联角色"
    @cancel="$emit('update:visible', false)"
    @ok="onSubmit"
  >
    <a-table
      v-bind="$tableConfigs(roleList, loading)"
      row-key="id"
      :row-selection="{ selectedRowKeys: selectedRows, onChange: selectionHandle }"
      :scroll="$scroller(400)"
      :columns="$columnsSetter(columns)"
    />
  </a-modal>
</template>
