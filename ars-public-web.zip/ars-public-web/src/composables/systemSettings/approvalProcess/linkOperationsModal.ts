import { FuncListItem, MenuListItem } from '@/models/systemSettings/userManagement/auth'
import { bindOpsByApprovalApi } from '@/services/systemSettings/approvalProcess'
import { message } from 'ant-design-vue'
import { DataNode } from 'ant-design-vue/lib/tree'
import { inject, ref } from 'vue'
import { useAllMenuFuncList } from '../userManagement/auth'
import { BindedOperations } from './'
import { useGetApprovalTempInfo } from './checkApprovalTemp'

interface ApprovalTreeItem extends DataNode {
  title: string
  key: string
  menu_id?: number
  checked?: boolean
  id: number
}
// const featureSelections = [23, 27, 28, 29, 30, 31]

/** 为审批流关联功能 */
export function useApprovalLinkOperations(successFn?: () => void) {
  const approvalOperationList = ref<ApprovalTreeItem[]>([])
  const checkedKeys = ref<string[]>([])
  const bindedKeys = inject(BindedOperations)

  const { funcList, menuList, getAllMenuFuncList } = useAllMenuFuncList()
  const { fullTempInfo, getApprovalTempInfo } = useGetApprovalTempInfo(true)

  async function initOperations(id: number) {
    await getAllMenuFuncList()
    await getApprovalTempInfo(id)

    const checkedIds = fullTempInfo.value?.func_apis.map(item => item.id) || []
    const list = funcList.value.filter(func => func.need_approval)
    const checkedFilter = bindedKeys?.value.filter(key => !checkedIds.includes(key)) || []

    approvalOperationList.value = mergeFuncMenuList(menuList.value, list, checkedFilter)
    checkedKeys.value = checkedIds.map(id => `func-${id}`)
  }

  /** 修改关联操作数据 */
  async function changeOperationByApprovalId(id: number) {
    try {
      const list = checkedKeys.value
        .filter(key => key.includes('func'))
        .map(key => +key.split('-')[1])
      const reply = await bindOpsByApprovalApi(id, { func_api_ids: list })
      if (reply.code === 0) {
        message.success('关联操作成功')
        successFn?.()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { approvalOperationList, checkedKeys, initOperations, changeOperationByApprovalId }
}

function mergeFuncMenuList(menus: MenuListItem[], funcs: FuncListItem[], checkedFilter: number[]) {
  const availableMenuIds = funcs.map(func => func.menu_id)
  const originList: ApprovalTreeItem[] = menus
    .filter(menu => availableMenuIds.includes(menu.id) || menu.parent_id === 0)
    .map(item => ({
      key: `menu-${item.id}`,
      id: item.id,
      parent_id: item.parent_id,
      title: `${item.name}(${!item.parent_id && item.name !== '首页' ? '模块' : '页面'})`
    }))
  originList.push(
    ...funcs.map(item => ({
      key: `func-${item.id}`,
      id: item.id,
      menu_id: item.menu_id,
      title: `${item.name}(功能)`
    }))
  )

  const result = originList.filter(first => {
    if (!first.menu_id && !availableMenuIds.includes(first.id)) {
      first.checkable = false
    }
    if (first.menu_id && checkedFilter.includes(first.id)) {
      first.disableCheckbox = true
    }
    // 将菜单和功能放在一起做成树状结构
    if (!first.menu_id) {
      const children = originList.filter(second => {
        return second.parent_id === first.id || second.menu_id === first.id
      })
      if (children.length) {
        first.children = children
      }
    }

    return first.parent_id === 0 && first.children?.length
  })

  return result
}
