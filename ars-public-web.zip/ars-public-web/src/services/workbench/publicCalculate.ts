import {
  CalculateScheduleParams,
  ClustersOfRoomRes,
  DeviceListOfRoomParams,
  DeviceListOfRoomRes
} from '@/models/workbench/publicCalculate'
import { request } from '@/utils/httpConfig'

/**
 * 公共算力机列表
 * @param data
 * @returns
 */
export function deviceListOfRoomApi(data: DeviceListOfRoomParams) {
  return request<DeviceListOfRoomRes>({
    url: 'v5/public/public_calculate/machine_room/device/get/list',
    method: 'GET',
    data
  })
}

/**
 * 算力机批量调度
 * @param data
 * @returns
 */
export function calculateScheduleApi(data: CalculateScheduleParams) {
  return request({
    url: 'v5/public/public_calculate/machine_room/device/operation/switch_miner',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 根据机房获取集群列表
 * @param machine_room_id
 * @returns
 */
export function clustersOfRoomApi(machine_room_id: number) {
  return request<ClustersOfRoomRes>({
    url: 'v5/public/public_calculate/machine_room/miner/get/list',
    method: 'get',
    data: { machine_room_id },
    loading: true
  })
}
