import { CheckRootPwdItem, CheckRootPwdParams } from '@/models/systemSettings/rootManagement'
import { checkRootPwdApi } from '@/services/systemSettings/rootManagement'
import { RSAEncryption } from '@/utils/cryptage'
import { message } from 'ant-design-vue'
import { ref } from 'vue'

export const columns: Utils.ColumnField<CheckRootPwdItem>[] = [
  { title: '主机SN', dataIndex: 'device_sn' },
  { title: '主机角色', dataIndex: 'software_type' },
  { title: 'root密码', dataIndex: 'root_passwd' }
]

/**
 * 获取指定设备的 root 密码
 * @param selectedIds 已选定的设备 id
 * @returns
 */
export const useGetRootPassword = (selectedIds: Utils.Prop<number[]>) => {
  const encrypt = new RSAEncryption()
  const step = ref(0)
  const loginPassword = ref('')
  const passwordList = ref<CheckRootPwdItem[]>([])

  const getRootPassword = async () => {
    try {
      const params: CheckRootPwdParams = {
        ids: [...selectedIds.value],
        login_passwd: encrypt.encode(loginPassword.value) || ''
      }
      const reply = await checkRootPwdApi(params)
      const { code, data, msg } = reply
      if (code === 0) {
        passwordList.value = data?.list || []
        step.value += 1
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { step, loginPassword, passwordList, getRootPassword }
}
