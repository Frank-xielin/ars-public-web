import {
  ClientListAllRes,
  ClientListRes,
  CreateClientParams,
  UpdateClientParams
} from '@/models/systemSettings/clientInformation'
import { defaultPager } from '@/utils/dataJudgement'
import { request } from '@/utils/httpConfig'

/** 客户信息展示 - 全部 */
export function clientListAllApi() {
  return request<ClientListAllRes>({
    url: 'v5/public/client/get/all',
    method: 'GET',
    loading: true
  })
}

/**
 * 客户信息展示 - 分页
 * @param vo 分页信息
 * @returns
 */
export function clientListApi(vo?: Utils.SearchVO) {
  return request<ClientListRes>({
    url: 'v5/public/client/get/list',
    method: 'GET',
    data: defaultPager(vo)
  })
}

/**
 * 新建客户 - 单个
 * @param data
 * @returns
 */
export function createClientApi(data: CreateClientParams) {
  return request({
    url: 'v5/public/client/create/one',
    method: 'POST',
    data,
    loading: true
  })
}

/**
 * 编辑客户 - 单个
 * @param id 目标客户 id
 * @param data
 * @returns
 */
export function updateClientApi(id: number, data: UpdateClientParams) {
  return request({
    url: `v5/public/client/update/id/${id}`,
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 删除客户 - 单个
 * @param id 目标客户 id
 * @returns
 */
export function deleteClientApi(id: number) {
  return request({
    url: `v5/public/client/delete/id/${id}`,
    method: 'delete',
    loading: true
  })
}
