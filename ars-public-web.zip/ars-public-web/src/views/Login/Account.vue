<script lang="ts" setup>
import { useLogin, useSmsByPhone } from '@/composables/login/account'

const emit = defineEmits<{
  (event: 'nextPage', val: number): void
}>()

const { form, loginForm, action, submitLogin } = useLogin(handleClick)
const { readyToSend, excessTime, getCodeBySms } = useSmsByPhone()

function handleClick() {
  emit('nextPage', 1)
}

const sendCode = () => {
  getCodeBySms({
    phone: loginForm.value.phone,
    sms_type: 'login'
  }).catch()
}
</script>

<template>
  <a-form
    v-show="!action"
    class="login-form"
    size="large"
    @submit="submitLogin"
    :wrapper-col="{ offset: 5, span: 14 }"
  >
    <a-form-item class="login-form-item" v-bind="form.validateInfos.phone">
      <a-input class="account-input" v-model:value="loginForm.phone" placeholder="请输入手机号">
        <template #prefix>
          <icon-font style="font-size: 26px" type="iconicon_login_nor" />
        </template>
      </a-input>
    </a-form-item>
    <a-form-item class="login-form-item" v-bind="form.validateInfos.password">
      <a-input
        type="password"
        class="password-input"
        v-model:value="loginForm.password"
        placeholder="请输入密码"
      >
        <template #prefix>
          <icon-font style="font-size: 26px" type="iconicon_password_nor" />
        </template>
      </a-input>
    </a-form-item>
    <a-form-item class="login-form-item" v-bind="form.validateInfos.sms_code">
      <a-input class="password-input" v-model:value="loginForm.sms_code" placeholder="请输入验证码">
        <template #suffix>
          <a-button type="link" @click="sendCode" :disabled="!readyToSend || !loginForm.phone">
            {{ readyToSend ? '发送' : `已发送(${excessTime}s)` }}
          </a-button>
        </template>
      </a-input>
    </a-form-item>
    <a-form-item class="login-form-item">
      <a-button class="login-button" type="primary" shape="round" html-type="submit" block>
        登录
      </a-button>
    </a-form-item>
  </a-form>
  <img src="../../assets/images/loginWait.gif" v-show="action" class="loginWait" />
</template>

<style lang="less" scoped>
.loginWait {
  position: relative;
  width: 60%;
  top: 50px;
  right: -30px;
}
</style>
