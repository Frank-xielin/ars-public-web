<script lang="ts" setup>
import {
  complicacyList,
  expiredList,
  lockTimes,
  rootExpiredList,
  usePwTacticManager
} from '@/composables/systemSettings/securityPolicy'

const { formModel, form, getPwTactic, updateTactic } = usePwTacticManager()

getPwTactic()
</script>

<template>
  <div class="security-policy page">
    <h2 class="view-title">密码策略</h2>
    <a-form class="security-form" :label-col="{ span: 6 }" :wrapper-col="{ span: 10 }">
      <a-form-item label="用户密码最小长度" v-bind="form.validateInfos.passwd_length">
        <a-input-number style="width: 100%" disabled :value="formModel.passwd_length" />
      </a-form-item>
      <a-form-item label="用户密码有效期" v-bind="form.validateInfos.passwd_expired">
        <custom-select :data="expiredList" disabled :value="formModel.passwd_expired" />
      </a-form-item>
      <a-form-item label="密码复杂性要求" v-bind="form.validateInfos.complicacy">
        <custom-select :data="complicacyList" disabled :value="formModel.complicacy" />
      </a-form-item>
      <a-form-item label="最大连续无效登录次数" v-bind="form.validateInfos.passwd_err_try_cnt">
        <a-input-number style="width: 100%" :min="1" v-model:value="formModel.passwd_err_try_cnt" />
      </a-form-item>
      <a-form-item label="第1次锁定有效时长" v-bind="form.validateInfos.first_login_err_lock">
        <custom-select :data="lockTimes" v-model:value="formModel.first_login_err_lock" />
      </a-form-item>
      <a-form-item label="第2次锁定有效时长" v-bind="form.validateInfos.second_login_err_lock">
        <custom-select :data="lockTimes" v-model:value="formModel.second_login_err_lock" />
      </a-form-item>
      <a-form-item label="第3次锁定有效时长" v-bind="form.validateInfos.third_login_err_lock">
        <custom-select :data="lockTimes" v-model:value="formModel.third_login_err_lock" />
      </a-form-item>
    </a-form>

    <h2 class="view-title">root密码策略</h2>
    <a-form
      class="security-form"
      :label-col="{ span: 6 }"
      :wrapper-col="{ span: 10 }"
      @submit="updateTactic"
    >
      <a-form-item label="root密码有效期" v-bind="form.validateInfos.root_passwd_validity">
        <custom-select :data="rootExpiredList" v-model:value="formModel.root_passwd_validity" />
      </a-form-item>

      <a-form-item class="submit-form-item">
        <a-button :disabled="!$auth(72)" type="primary" html-type="submit" block>提交设置</a-button>
      </a-form-item>
    </a-form>
  </div>
</template>

<style scoped lang="less">
.view-title {
  font-size: 18px;
  font-weight: bold;
}
.security-form {
  width: 700px;
  margin: auto;
}
.submit-form-item {
  :deep(.ant-form-item-control) {
    position: relative;
    left: calc(50% - 29px);
    transform: translateX(-50%);
  }
}
</style>
