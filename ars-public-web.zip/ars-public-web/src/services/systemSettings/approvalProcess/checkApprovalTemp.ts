import {
  GetApprovalTempRes,
  UpdateApprovalTempParams,
  UpdateApprovalTempRes
} from '@/models/systemSettings/approvalProcess/checkApprovalTemp'
import { request } from '@/utils/httpConfig'

/**
 * 审批流模板获取 - 单个
 * @param id 目标审批流模板的 id
 * @returns
 */
export function getApprovalTempApi(id: number) {
  return request<GetApprovalTempRes>({
    url: `v5/public/approval_template/get/id/${id}`,
    method: 'get',
    loading: true
  })
}

/**
 * 审批流模板编辑 - 单个
 * @param id 目标审批流模板的 id
 * @param data
 * @returns
 */
export function updateApprovalTempApi(id: number, data: UpdateApprovalTempParams) {
  return request<UpdateApprovalTempRes>({
    url: `v5/public/approval_template/update/id/${id}`,
    method: 'put',
    data,
    loading: true
  })
}
