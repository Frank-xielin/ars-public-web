<script lang="ts" setup>
import {
  columns,
  useGetRootPassword
} from '@/composables/systemSettings/rootManagement/checkRootPassword'
import { softwareList } from '@/composables/workbench/hostManagement'
import { toRefs, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  selectedIds: number[]
}>()
defineEmits<{
  (event: 'update:visible', val: boolean): void
}>()
const { selectedIds } = toRefs(props)

const { step, loginPassword, passwordList, getRootPassword } = useGetRootPassword(selectedIds)

watch(
  () => props.visible,
  val => {
    if (val) {
      loginPassword.value = ''
      step.value = 0
      passwordList.value.length = 0
    }
  }
)
</script>

<template>
  <a-modal
    :visible="visible"
    :title="step === 0 ? '请输入登录密码' : '查看root密码'"
    :footer="null"
    @cancel="$emit('update:visible', false)"
  >
    <div v-if="step === 0">
      <a-input-password v-model:value="loginPassword" :visibility-toggle="false" />
      <footer class="submit-footer">
        <a-button type="primary" @click="getRootPassword">确定</a-button>
        <a-button @click="$emit('update:visible', false)">取消</a-button>
      </footer>
    </div>

    <div v-else>
      <p v-show="selectedIds.length === 1" class="password-text">
        {{ passwordList[0].root_passwd }}
      </p>
      <a-table
        class="password-list-table"
        v-show="selectedIds.length > 1"
        v-bind="$tableConfigs(passwordList)"
        :columns="$columnsSetter(columns)"
        :scroll="$scroller(400)"
        row-key="device_sn"
      >
        <template #bodyCell="{ column, text }">
          <span v-if="column.title === '主机角色'">
            {{ softwareList.find(item => item.value === text)?.label }}
          </span>
        </template>
      </a-table>

      <a-button class="closer-btn" type="primary" block @click="$emit('update:visible', false)">
        OK
      </a-button>
    </div>
  </a-modal>
</template>

<style scoped lang="less">
.password-text {
  font-size: 16px;
  font-weight: bold;
}
.submit-footer {
  display: flex;
  justify-content: space-between;
  padding: 20px 0;
  > button {
    width: 45%;
  }
}
.closer-btn {
  margin: 20px 0;
}
</style>
