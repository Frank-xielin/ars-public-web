<script lang="ts" setup>
import { useCommandExec } from '@/composables/jobManagement/commandExecution'
import { useClusterAllList } from '@/composables/systemSettings/clusterInformation'
import { TemplateListItem } from '@/models/jobManagement/commonTemplate'
import { DeviceListItem } from '@/models/workbench/hostManagement'
import { message } from 'ant-design-vue'
import { cloneDeep } from 'lodash-es'
import { computed, ref } from 'vue'
import ChooseDeviceModal from './CommandExecution/ChooseDeviceModal.vue'
import ChooseTemplateModal from './CommandExecution/ChooseTemplateModal.vue'

const deviceShow = ref(false)
const templateShow = ref(false)
const selectedCluster = ref<DeviceListItem[]>([])
const selectedTemplate = ref<TemplateListItem[]>([])
const { dataSource: clusters, searchAllClusters } = useClusterAllList()
const { execResult, form, formModel, execCompleted, startCommand } = useCommandExec()

const clusterList = computed(() =>
  clusters.value.map(cluster => {
    return { ...cluster, label: `${cluster.client_name}${cluster.miner}` }
  })
)

function chooseDevice() {
  if (!formModel.value.miner_id) {
    message.warn('请先选择目标集群')
    return
  }
  deviceShow.value = true
}
function handleSelectDevice(rows: DeviceListItem[]) {
  // 选择主机
  selectedCluster.value = cloneDeep(rows)
  formModel.value.device_ids = selectedCluster.value.map(row => row.id)
}
function handleSelectTemp(rows: TemplateListItem[]) {
  // 选择模板
  selectedTemplate.value = cloneDeep(rows)
  formModel.value.id = rows[0].id
}
searchAllClusters()
</script>

<template>
  <div class="command-execution page">
    <a-form :label-col="{ span: 2 }">
      <a-form-item label="目标集群" v-bind="form.validateInfos.miner_id">
        <custom-select
          style="width: 300px"
          value-field="miner"
          :data="clusterList"
          :disabled="!$auth(189)"
          placeholder="请选择目标集群"
          v-model:value="formModel.miner_id"
        />
      </a-form-item>
      <a-form-item label="执行主机" v-bind="form.validateInfos.device_ids">
        <a-input class="form-input textarea" disabled :value="selectedCluster[0]?.device_sn" />
        <a-button :disabled="!$auth(189)" @click="chooseDevice">+ 选择主机</a-button>
      </a-form-item>
      <a-form-item label="执行命令" v-bind="form.validateInfos.id">
        <a-textarea
          class="form-input textarea"
          :value="selectedTemplate[0]?.content"
          disabled
          style="width: 530px; height: 150px"
        />
        <a-button :disabled="!$auth(189)" @click="templateShow = true">+ 选择模板</a-button>
      </a-form-item>
      <a-form-item :wrapper-col="{ offset: 2 }">
        <a-button type="primary" :disabled="execCompleted || !$auth(189)" @click="startCommand">
          开始执行
        </a-button>
      </a-form-item>
      <a-form-item label="执行结果">
        <a-textarea class="textarea exec-result" disabled :value="execResult" />
      </a-form-item>
    </a-form>

    <choose-device-modal
      :cluster-id="formModel.miner_id"
      :selected-devices="selectedCluster"
      v-model:visible="deviceShow"
      @select="handleSelectDevice"
    />
    <choose-template-modal
      v-model:visible="templateShow"
      :selected-temps="selectedTemplate"
      @select="handleSelectTemp"
    />
  </div>
</template>

<style scoped lang="less">
.form-input {
  width: 530px;
  margin-right: 20px;
}
.textarea {
  &.exec-result {
    width: 600px;
    height: 400px;
    color: #c7c3c3;
    background: #000;
    resize: both;
    cursor: default;
  }
}
</style>
