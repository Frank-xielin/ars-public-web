import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { ApprovalListItem, ApprovalListParams } from '@/models/home/approval'
import { pendingApprovalApi, submitApprovalApi } from '@/services/home/approval'
import { message } from 'ant-design-vue'
import { ref } from 'vue'

// 解析操作审批中独有的http_body字段，得到首页需要的集群、对象(devices)和留言(原因)
export function analysisHttpbody(data: any) {
  try {
    const obj2 = JSON.parse(data)
    // console.log(obj2, '--------')
    return obj2
  } catch (e) {
    return {}
  }
}

export const columns: Utils.ColumnField<ApprovalListItem>[] = [
  { title: '类型', dataIndex: 'target_type', width: '100px' },
  { title: '内容', dataIndex: 'target' },
  { title: '原因', dataIndex: 'target' },
  { title: '集群', dataIndex: 'target' },
  { title: '提交人', dataIndex: 'submitor', width: '100px' },
  { title: '时间', dataIndex: 'updated_at' },
  { title: '状态', dataIndex: 'state' },
  { title: '操作', dataIndex: 'id' }
]

export const colors = [
  // { text: '待提交', color: 'purple', id: 0, words: '去审核' },
  // { text: '待审核', color: 'cyan', id: 1, words: '查看' },
  // { text: '审核失败', color: 'red', id: 2, words: '查看' },
  // { text: '已发布', color: 'yellow', id: 3, words: '查看' }
  { text: '待提交', color: 'purple', id: 0 },
  { text: '待审核', color: 'blue', id: 1 },
  { text: '审核失败', color: 'red', id: 2 },
  { text: '审核通过，待发布', color: 'cyan', id: 3 },
  { text: '已发布', color: 'yellow', id: 4 }
]

// interface SearchForm extends Utils.NoPager<ApprovalListParams> {
//   dates?: [Dayjs, Dayjs]
// }

/** 待审批 获取数据 */
export function usePendingApproval(successFn: (val: number) => void) {
  const searchModel = ref({
    state: '',
    search: ''
    // start_date: '',
    // end_date: '',
    // dates: undefined
  })
  const dataSource = ref<ApprovalListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()

  const { loading, run } = useRequest(pendingApprovalApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
        successFn(data?.total || 0)
      } else {
        message.error(msg)
      }
    }
  })

  function handleSearch(vo?: Utils.SearchVO) {
    try {
      const params: ApprovalListParams = {
        ...searchModel.value,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params)
    } catch (e) {}
  }

  return { loading, searchModel, dataSource, pageVo, handleSearch }
}

/** 已提交 获取数据 */
export function useSubmitApproval(successFn: (val: number) => void) {
  const searchModel = ref({
    search: ''
    // start_date: '',
    // end_date: '',
    // dates: undefined
  })
  const dataSource = ref<ApprovalListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()

  const { loading, run } = useRequest(submitApprovalApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
        successFn(data?.total || 0)
      } else {
        message.error(msg)
      }
    }
  })

  function handleSearch(vo?: Utils.SearchVO) {
    try {
      const params: ApprovalListParams = {
        ...searchModel.value,
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return run(params)
    } catch (e) {}
  }

  return { loading, searchModel, dataSource, pageVo, handleSearch }
}
