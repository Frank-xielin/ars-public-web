import { message } from 'ant-design-vue'
import { ref } from 'vue'

import useRequest from '@/common/useRequest'
import config from '@/config'
import { OverviewListItem } from '@/models/workbench/clusterOverview'
import { codeByMinerApi } from '@/services/login'
import { overviewDetailApi } from '@/services/workbench/clusterOverview'

export function useDetailsOfCluster() {
  const isError = ref(false)
  const errorDesc = ref('')
  const clusterInfo = ref<OverviewListItem | null>(null)

  const { loading, run: detailsFetch } = useRequest(overviewDetailApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        clusterInfo.value = data
      } else {
        isError.value = true
        errorDesc.value = msg
      }
    }
  })

  async function getClusterDetails(minerId: string) {
    try {
      return detailsFetch({ miner_id: minerId })
    } catch (e) {}
  }

  return { loading, isError, errorDesc, clusterInfo, getClusterDetails }
}

/** 进入到指定集群的页面服务 */
export function useViewClusterServer() {
  async function intoClustersServer(minerId: string) {
    try {
      const reply = await codeByMinerApi(minerId)
      if (reply.code === 0 && reply.data) {
        const { domain, miner_id, code } = reply.data
        getMockUrl(domain, code, miner_id)
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { intoClustersServer }
}

/** 检测是否需要本地测试 */
function getMockUrl(domain: string, code: string, miner_id: string) {
  let url = ''
  if (config.env === 'development') {
    // TODO 地址根据实际情况进行调整
    url = `http://localhost:3001/#/OperatingPlatform/ClusterOverview?code=${code}&clusterId=${miner_id}`
    window.open(url, '_self')
  } else {
    url = `${domain}/#/OperatingPlatform/ClusterOverview?code=${code}&clusterId=${miner_id}`
  }
  window.open(url, '_self')
}
