<script lang="ts" setup>
import { useGetUserAssetsInfo, useTabDynamicGenerate } from '@/composables/home'
import Approval from './Home/Approval.vue'
import MessageApproval from './Home/MessageApproval.vue'

const {
  showPeddingApproval,
  activeKey,
  pOrsNumber,
  pOrsNumberTwo,
  pOrsNumberThree,
  handlePorSnumber,
  handlePorSnumberTwo,
  handlePorSnumberThree
} = useTabDynamicGenerate()
const { assetsInfo, initAssetsInfo } = useGetUserAssetsInfo()

initAssetsInfo()
</script>

<template>
  <div class="wrapper page">
    <ul class="show__list">
      <li class="show__list__four">
        <h5 class="show__list__four__title">集群</h5>
        <h3 class="show__list__four__number">
          {{ assetsInfo.cluster }}
          <h5 class="unit">个</h5>
        </h3>
      </li>
      <li class="show__list__four">
        <h5 class="show__list__four__title">主机</h5>
        <h3 class="show__list__four__number">
          {{ assetsInfo.device }}
          <h5 class="unit">台</h5>
        </h3>
      </li>
      <li class="show__list__four">
        <h5 class="show__list__four__title">总算力</h5>
        <h3 class="show__list__four__number">
          {{ assetsInfo.power.split(' ')[0] }}
          <h5 class="unit">{{ assetsInfo.power.split(' ')[1] }}</h5>
        </h3>
      </li>
      <li class="show__list__four">
        <h5 class="show__list__four__title">总资产</h5>
        <h3 class="show__list__four__number">
          {{ assetsInfo.asset.split(' ')[0] }}
          <h5 class="unit">{{ assetsInfo.asset.split(' ')[1] }}</h5>
        </h3>
      </li>
    </ul>

    <a-tabs class="approval" type="card" v-model:activeKey="activeKey">
      <a-tab-pane
        :forceRender="true"
        v-if="showPeddingApproval"
        key="1"
        :tab="`我的待办审批(${pOrsNumber <= 10 ? pOrsNumber : '10+'})`"
        class="approval__toDo"
      >
        <!-- <Approval type="1" @handlePorSnumber="pOrsNumber = $event" /> -->
        <Approval type="1" @handlePorSnumber="handlePorSnumber" />
        <!-- $event接受函数的第一个形参 -->
      </a-tab-pane>
      <a-tab-pane forceRender key="2" tab="我提交的审批" class="approval__toDo">
        <Approval type="2" @handlePorSnumber="handlePorSnumberTwo" />
      </a-tab-pane>
      <a-tab-pane
        forceRender
        key="3"
        :tab="`我的消息(${pOrsNumberThree <= 10 ? pOrsNumberThree : '10+'})`"
        class="approval__toDo"
      >
        <div class="approval__message">
          <MessageApproval @handlePorSnumber="handlePorSnumberThree" />
        </div>
      </a-tab-pane>
    </a-tabs>
    <div class="more">
      <h5 @click="$router.push('/JobManagement/TaskManagement')" v-if="activeKey !== '3'">
        查看更多任务审批
      </h5>
      <h5 @click="$router.push('/Personal/MyApprovals')" v-if="activeKey !== '3'">
        查看更多操作审批
      </h5>
      <h5 @click="$router.push('/Personal/MyMessages')" v-else>查看更多信息</h5>
    </div>

    <!-- <a-tab-pane v-for="item in tabVariable" :key="item.key" :tab="`${item.tab} (${item.all})`">
      </a-tab-pane> -->
    <!-- :tab="item.tab + ' (' + item.all + ')'" -->
  </div>
</template>

<style lang="less" scoped>
@import (reference) '@/assets/styles/index.less';
.wrapper {
  background: @backDivColor !important;
  padding: 0 !important;
  .show__list {
    height: 204px;
    background-color: #fff;
    padding: 18px 36px 18px !important;
    margin-bottom: 18px;
    display: flex;
    justify-content: space-between;
    box-shadow: 0 4px 60px 0 rgb(0 38 115 / 8%);

    &__four {
      flex-direction: column;
      width: 374px;
      height: 146px;
      border: 1px solid #ebf1f5;
      border-radius: 3px;
      display: flex;
      justify-content: center;
      align-items: center;
      &__title {
        height: 30px;
        font-size: 14px;
        font-weight: 100;
        letter-spacing: 1px;
      }
      &__number {
        display: flex;
        height: 30px;
        font-size: 28px;
        font-weight: bold;
        margin-top: 12px;
        line-height: 30px;
        .unit {
          font-size: 14px;
          color: @textColor_first;
          margin: 4px 0 0 4px;
        }
      }
    }
  }
  .approval {
    &__toDo {
      position: relative;
      background-color: #fff;
      padding: 44px 36px 0 36px;
      left: 1px;
      // box-shadow: 0 4px 60px 0 rgb(0 38 115 / 8%);
    }
    &__message {
      display: flex;
      flex-direction: column;
    }
    :deep(.ant-tabs-nav) {
      margin: 0;
    }
  }
  .more {
    display: flex;
    padding: 32px 0 73px 36px;
    background-color: #fff;
    > h5 {
      color: @textColor_first;
      font-size: 12px;
      text-decoration: underline;
      margin-right: 46px;
      cursor: pointer;
    }
  }
  :deep(div.ant-tabs-tab) {
    font-weight: 300;
    display: block;
    background: #ecf0fa;
    line-height: 52px;
    width: 220px;
    height: 52px;
    text-align: center;
    padding: 0 20px;
    border-radius: 6px 6px 0 0 !important;
  }
  :deep(div.ant-tabs-tab-active) {
    font-weight: bold;
    background-color: #fff;
  }
  :deep(div.ant-tabs-tab-btn) {
    color: @textColor_first;
  }
}
</style>
