import {
  CheckRootPwdParams,
  CheckRootPwdRes,
  GetUpdatePwdRecordRes,
  GetUpdateResultRes,
  RootPwdListParams,
  RootPwdListRes,
  UpdatePwdByRoleParams,
  UpdateSinglePwdParams
} from '@/models/systemSettings/rootManagement'
import { request } from '@/utils/httpConfig'

/**
 * root 密码列表
 * @param data 搜索条件
 * @returns
 */
export function rootPwdListApi(data: RootPwdListParams) {
  return request<RootPwdListRes>({
    url: 'v5/public/root/get/list',
    method: 'GET',
    data
  })
}

/**
 * 按角色修改root密码
 * @param data
 * @returns
 */
export function updatePwdByRoleApi(data: UpdatePwdByRoleParams) {
  return request<number>({
    url: 'v5/public/root/update/password/role',
    method: 'PUT',
    data,
    loading: true
  })
}

/** 获取执行修改后的结果 */
export function getUpdateResultApi(id: number) {
  return request<GetUpdateResultRes>({
    url: 'v5/public/root/get/exec/list',
    method: 'get',
    data: { id },
    loading: true
  })
}

/**
 * 单个修改 root 密码
 * @param data
 * @returns
 */
export function updateSinglePwdApi(data: UpdateSinglePwdParams) {
  return request({
    url: 'v5/public/root/update/password',
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 查看root密码
 * @param login_passwd 用户的登录密码
 * @returns
 */
export function checkRootPwdApi(data: CheckRootPwdParams) {
  return request<CheckRootPwdRes>({
    url: 'v5/public/root/get/password/list',
    method: 'post',
    data,
    loading: true
  })
}

/** 获取密码修改记录 */
export function getUpdatePwdRecord(data: Utils.SearchVO) {
  return request<GetUpdatePwdRecordRes>({
    url: 'v5/public/root/get/record/list',
    method: 'get',
    data
  })
}
