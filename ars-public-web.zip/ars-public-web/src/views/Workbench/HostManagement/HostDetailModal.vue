<script lang="ts" setup>
import { HostBaseInfoKey } from '@/composables/workbench/hostManagement/hostDetail'
import { DeviceListItem } from '@/models/workbench/hostManagement'
import { computed, provide, readonly, ref, watch } from 'vue'
import HostBaseInfo from './HostBaseInfo.vue'
import OperationRecordTable from './OperationRecordTable.vue'

const props = defineProps<{
  visible: boolean
  record?: DeviceListItem
}>()
defineEmits<{
  (event: 'update:visible', val: boolean): void
}>()

const activeKey = ref('base')

const deviceDetails = computed(() => ({
  ...props.record,
  ...props.record?.base_info
}))
provide(HostBaseInfoKey, readonly(deviceDetails))

watch(
  () => props.visible,
  visible => {
    if (!visible) {
      activeKey.value = 'base'
    }
  }
)
</script>

<template>
  <a-modal
    :visible="visible"
    :width="1264"
    :footer="null"
    destroy-on-close
    @cancel="$emit('update:visible', false)"
  >
    <a-tabs v-model:active-key="activeKey">
      <a-tab-pane key="base" tab="基本信息">
        <host-base-info />
      </a-tab-pane>
      <a-tab-pane key="records" tab="操作记录">
        <operation-record-table v-if="activeKey === 'records'" />
      </a-tab-pane>
    </a-tabs>
  </a-modal>
</template>
