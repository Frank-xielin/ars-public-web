import {
  CreateApprovalTempParams,
  NotifyChannelListItem
} from '@/models/systemSettings/approvalProcess/createApprovalTemp'
import {
  createApprovalTempApi,
  notifyChannelListApi
} from '@/services/systemSettings/approvalProcess/createApprovalTemp'
import { Form, message } from 'ant-design-vue'
import { Ref, ref } from 'vue'
import { useRouter } from 'vue-router'
import { requireInput, requireSelect } from '../clusterInformation/addEditCluster'

/** 通知类型 */
export const notifyTypeList = [
  { label: '系统通知', value: 1 },
  { label: '邮件通知', value: 2 },
  { label: '企业微信', value: 3 }
]
export const initialTempValues: CreateApprovalTempParams = {
  title: '',
  approver1_id: undefined,
  approver2_id: undefined,
  approver3_id: undefined,
  notifiers: [],
  notify_channels: [],
  enabled: true,
  tag: 'important_operation'
}

export function approvalUserValidator(
  val: any,
  formModel: Ref<CreateApprovalTempParams>,
  num: number
) {
  if (val) {
    if (num >= 1 && val === formModel.value.approver1_id) {
      return Promise.reject('不能和审核人1相同')
    } else if (num === 2 && val === formModel.value.approver2_id) {
      return Promise.reject('不能和审核人2相同')
    } else if (num === 2 && !formModel.value.approver2_id) {
      return Promise.reject('审核人2为空')
    }
  }
  return Promise.resolve()
}

export function useCreateApprovalTemp() {
  const router = useRouter()
  const formModel = ref<CreateApprovalTempParams>({ ...initialTempValues })
  const rules = ref<Utils.RulesObject<CreateApprovalTempParams>>({
    title: [requireInput('名称')],
    approver1_id: [requireSelect('审核人1')],
    approver2_id: [{ validator: (_, val) => approvalUserValidator(val, formModel, 1) }],
    approver3_id: [{ validator: (_, val) => approvalUserValidator(val, formModel, 2) }]
  })
  const form = Form.useForm(formModel, rules)

  async function submitApprovalTemp() {
    try {
      await form.validate()
      const reply = await createApprovalTempApi(formModel.value)
      if (reply.code === 0) {
        message.success('新建审批流模板成功')
        router.push('/SystemSettings/ApprovalProcess')
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { formModel, form, submitApprovalTemp }
}

/** 获取所有的通知方式 */
export function useNotifyChannelAllList() {
  const notifyChannels = ref<NotifyChannelListItem[]>([])

  async function getAllNotifyChannels() {
    try {
      const reply = await notifyChannelListApi()
      const { code, data, msg } = reply
      if (code === 0) {
        notifyChannels.value = data || []
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  return { notifyChannels, getAllNotifyChannels }
}
