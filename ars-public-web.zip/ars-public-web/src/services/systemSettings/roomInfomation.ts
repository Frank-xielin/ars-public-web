import {
  CreateRoomParams,
  GetRoomListRes,
  UpdateRoomParams
} from '@/models/systemSettings/roomInfomation'
import { request } from '@/utils/httpConfig'

/**
 * 新建机房信息
 * @param data
 * @returns
 */
export function createRoomApi(data: CreateRoomParams) {
  return request({
    url: 'v5/public/machine/create/one',
    method: 'POST',
    data,
    loading: true
  })
}

/**
 * 编辑机房信息
 * @param id 目标机房 id
 * @param data
 * @returns
 */
export function updateRoomApi(id: number, data: UpdateRoomParams) {
  return request({
    url: `v5/public/machine/update/id/${id}`,
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 获取机房列表
 * @param vo 分页信息
 * @returns
 */
export function getRoomListApi(vo: Utils.SearchVO) {
  return request<GetRoomListRes>({
    url: 'v5/public/machine/get/list',
    method: 'get',
    data: vo
  })
}
