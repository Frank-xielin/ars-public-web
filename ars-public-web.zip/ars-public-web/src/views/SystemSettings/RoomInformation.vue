<script lang="ts" setup>
import { columns, useRoomList } from '@/composables/systemSettings/roomInformation'
import { useAddEditModal } from '@/composables/workbench/errorRecord'
import { GetRoomListItem } from '@/models/systemSettings/roomInfomation'
import AddEditRoomInfo from './RoomInfomation/AddEditRoomInfo.vue'

const { visible, modalType, targetInfo, editModal, addModal } = useAddEditModal<GetRoomListItem>()
const { dataSource, pageVo, loading, handleSearch } = useRoomList()
handleSearch()
</script>

<template>
  <div class="room-information page">
    <a-button :disabled="!$auth(46)" class="add-btn" type="primary" shape="round" @click="addModal">
      新建机房
    </a-button>

    <a-table
      class="table-box"
      v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
      row-key="id"
      :scroll="$scroller('calc(100vh - 350px)')"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ column: col, text, record }">
        <a-button
          v-if="col.title === '操作'"
          type="link"
          :disabled="!$auth(47)"
          class="table-btn"
          @click="editModal(record)"
        >
          编辑
        </a-button>
        <template v-else-if="col.title === '算力机是否可调度'">
          <icon-font v-if="text" class="check-icon" type="iconicon_gou" />
        </template>
        <custom-tooltip v-else>{{ text }}</custom-tooltip>
      </template>
    </a-table>

    <add-edit-room-info
      :modal-type="modalType"
      v-model:visible="visible"
      v-model:target-info="targetInfo"
      @search="handleSearch(modalType === '编辑' ? pageVo : undefined)"
    />
  </div>
</template>

<style scoped lang="less">
.add-btn {
  position: absolute;
  right: 50px;
}
.table-box {
  margin-top: 55px;
  .check-icon {
    cursor: default;
  }
}
</style>
