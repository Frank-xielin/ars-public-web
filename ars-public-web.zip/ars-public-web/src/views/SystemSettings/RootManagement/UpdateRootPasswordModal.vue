<script lang="ts" setup>
import { useUpdateRootPwd } from '@/composables/systemSettings/rootManagement/updateRootPassword'
import { softwareList } from '@/composables/workbench/hostManagement'
import { toRefs, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  clusterId: string
  deviceId: number
  type: 'single' | 'role'
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'success'): void
}>()
const { type, deviceId, clusterId } = toRefs(props)

const { singleFormModel, batchFormModel, handleUpdatePassword } = useUpdateRootPwd(
  type,
  deviceId,
  clusterId,
  () => {
    emit('success')
    emit('update:visible', false)
  }
)

watch(
  () => props.visible,
  val => {
    if (val) {
      singleFormModel.value = { id: 0, password: '', cluster_id: '' }
      batchFormModel.value = { cluster_id: '', software_role: -1 }
    }
  }
)
</script>

<template>
  <a-modal
    :visible="visible"
    title="修改root密码"
    @ok="handleUpdatePassword"
    @cancel="$emit('update:visible', false)"
  >
    <a-form layout="vertical">
      <a-form-item v-if="type === 'role'" label="请选择软件角色">
        <custom-select :data="softwareList" v-model:value="batchFormModel.software_role" />
      </a-form-item>

      <a-form-item v-if="type === 'single'">
        <a-input placeholder="请输入新的root密码" v-model:value="singleFormModel.password" />
      </a-form-item>
    </a-form>
  </a-modal>
</template>
