import { Form } from 'ant-design-vue'
import { isBoolean } from 'lodash-es'
import { onMounted, ref } from 'vue'

import { usePagination } from '@/common/usePagination'
import { FormRenderOptions, QueryParams } from '@/models/formRender'

export function useFormRender(op: FormRenderOptions<any, any>) {
  const formModel = ref<Utils.Dict>({ ...op.initialValues })
  const dataSource = ref<any[]>([])
  const loading = ref(false)

  const form = Form.useForm(formModel)
  const { pageVo, setPageFromData } = usePagination()

  function handleReset() {
    const resetOpt = op.reset
    form.resetFields()
    if (!isBoolean(resetOpt)) {
      resetOpt?.onReset?.()
    }
    handleSearch()
  }
  async function handleSearch(vo?: Utils.SearchVO) {
    loading.value = true
    const showPager = op.pager
    if (showPager) {
      vo = {
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
    }
    const params = { ...formModel.value }
    const reply = await op.tableConfigs.onSearch(params, vo)
    if (reply) {
      setPageFromData(reply.vo)
      dataSource.value = reply.res
    }
    loading.value = false
  }
  function handleChange(formObject: QueryParams<any>) {
    return (...args: any[]) => {
      formObject.onChange?.(...args)
      if (formObject.type === 'select' || formObject.type.includes('picker')) {
        if (formObject.type.includes('picker') && formObject.range) {
          const start = formObject.range?.[0] || 'start_time'
          const end = formObject.range?.[1] || 'end_time'
          formModel.value[start] = args[1][0]
          formModel.value[end] = args[1][1]
        }
        handleSearch()
      }
    }
  }

  onMounted(() => {
    if (!op.manaul) {
      handleSearch()
    }
  })

  return { formModel, loading, pageVo, dataSource, handleSearch, handleChange, handleReset }
}
