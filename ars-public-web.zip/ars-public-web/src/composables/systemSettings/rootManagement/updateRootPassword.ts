import useRequest from '@/common/useRequest'
import {
  GetUpdateResultRes,
  UpdatePwdByRoleParams,
  UpdateSinglePwdParams
} from '@/models/systemSettings/rootManagement'
import {
  getUpdateResultApi,
  updatePwdByRoleApi,
  updateSinglePwdApi
} from '@/services/systemSettings/rootManagement'
import { RSAEncryption } from '@/utils/cryptage'
import { requestHandler } from '@/utils/formTools'
import { message } from 'ant-design-vue'
import { inject, ref } from 'vue'
import { ChangeResultListFnKey } from '.'

/**
 * 手动修改主机 root 密码
 * @param type 修改的方式类型
 * @returns
 */
export const useUpdateRootPwd = (
  type: Utils.Prop<'single' | 'role'>,
  deviceId: Utils.Prop<number>,
  clusterId: Utils.Prop<string>,
  successFn: () => void
) => {
  const encrypt = new RSAEncryption()
  const singleFormModel = ref<UpdateSinglePwdParams>({
    id: 0,
    cluster_id: '',
    password: ''
  })
  const batchFormModel = ref<UpdatePwdByRoleParams>({
    cluster_id: '',
    software_role: -1
  })

  const { getUpdateResult } = useGetUpdateResult()
  const { run: singleFetch } = useRequest(updateSinglePwdApi, {
    onSuccess: reply => {
      requestHandler('修改成功')(reply)
      if (reply.code === 0) {
        successFn()
      }
    }
  })
  const { run: batchRoleFetch } = useRequest(updatePwdByRoleApi, {
    onSuccess: reply => {
      requestHandler('修改成功')(reply)
      if (reply.code === 0) {
        getUpdateResult(reply.data || 0)
        successFn()
      }
    }
  })

  const handleUpdatePassword = () => {
    try {
      if (type.value === 'single') {
        singleFormModel.value.id = deviceId.value
        singleFormModel.value.cluster_id = clusterId.value
        if (!singleFormModel.value.password) {
          message.warn('请输入新密码！')
          return
        }
        const params: UpdateSinglePwdParams = {
          id: singleFormModel.value.id,
          cluster_id: singleFormModel.value.cluster_id,
          password: encrypt.encode(singleFormModel.value.password) || ''
        }
        singleFetch(params)
      } else {
        batchFormModel.value.cluster_id = clusterId.value
        batchRoleFetch(batchFormModel.value)
      }
    } catch (e) {
      console.log(e)
    }
  }

  return { singleFormModel, batchFormModel, handleUpdatePassword }
}

/**
 * 获取更改密码的结果
 * @param global 是否使用 RootManagement 的弹窗
 */
export const useGetUpdateResult = (global = true) => {
  const initialValue: GetUpdateResultRes = {
    list: [],
    offline_size: 0,
    online_size: 0,
    total_size: 0
  }
  const updatedRes = ref<GetUpdateResultRes>({ ...initialValue })
  const changeResultList = inject(ChangeResultListFnKey)

  const getUpdateResult = async (id: number) => {
    try {
      const reply = await getUpdateResultApi(id)
      const { code, data, msg } = reply
      if (code === 0) {
        if (data) {
          global && changeResultList?.({ ...data })
          updatedRes.value = data
        }
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  const initUpdatedData = () => {
    updatedRes.value = { ...initialValue }
  }

  return { updatedRes, initUpdatedData, getUpdateResult }
}
