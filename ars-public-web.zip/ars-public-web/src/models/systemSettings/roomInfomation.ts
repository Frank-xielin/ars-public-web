export interface CreateRoomParams {
  machine_name: string
  machine_site: string
  domain: string
  note: string
  scheduling: boolean
}

export type UpdateRoomParams = CreateRoomParams

export interface GetRoomListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string
  name: string
  site: string
  domain: string
  scheduling: boolean
  note: string
}

export interface GetRoomListRes extends Utils.PageVO {
  list: GetRoomListItem[]
}
