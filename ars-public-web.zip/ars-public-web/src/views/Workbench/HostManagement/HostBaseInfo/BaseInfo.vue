<script lang="ts" setup>
import { softwareList } from '@/composables/workbench/hostManagement'
import { gpuHandler, HostBaseInfoKey } from '@/composables/workbench/hostManagement/hostDetail'
import { DeviceBaseInfo, DeviceListItem } from '@/models/workbench/hostManagement'
import { inject } from 'vue'

interface ListItem {
  name: string
  key: keyof (DeviceBaseInfo & DeviceListItem)
}

const configs: ListItem[] = [
  { name: 'CPU', key: 'CPU' },
  { name: '内存', key: 'memory' },
  { name: 'GPU', key: 'gpu_list' },
  { name: '温度', key: 'temperature' }
]
const argumentList: ListItem[] = [
  { name: '机器SN', key: 'device_sn' },
  { name: 'IP', key: 'ips' },
  { name: '软件角色', key: 'software_type' }
]
const baseInfo = inject(HostBaseInfoKey)
</script>

<template>
  <div class="base-info">
    <div class="info-list">
      <h3 class="title">系统版本</h3>
      <p class="content">{{ baseInfo?.hos_version }}</p>
    </div>

    <div class="info-list">
      <h3 class="title">配置</h3>
      <p class="content" v-for="item of configs" :key="item.key">
        <span class="name">{{ item.name }}:</span>
        <span class="value" v-if="item.key === 'gpu_list'">
          {{ gpuHandler(baseInfo?.[item.key] || []) }}
        </span>
        <span class="value" v-else>{{ baseInfo?.[item.key] }}</span>
      </p>
    </div>

    <div class="info-list">
      <h3 class="title">参数</h3>
      <p class="content" v-for="item of argumentList" :key="item.key">
        <span class="name">{{ item.name }}:</span>
        <span class="value" v-if="item.key === 'software_type'">
          {{ softwareList.find(soft => baseInfo?.[item.key] === soft.value)?.label }}
        </span>
        <span class="value" v-else>{{ baseInfo?.[item.key] }}</span>
      </p>
    </div>
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.base-info {
  display: flex;
  justify-content: center;
  .info-list {
    width: 300px;
    padding: 0 55px;
    border-right: 1px solid @titleBack;
    h3.title {
      height: 21px;
      margin-bottom: 20px;
      font-size: 16px;
      font-weight: bold;
      color: @textColor_first;
    }
    .content {
      margin-bottom: 20px;
      .name {
        display: inline-block;
        margin-right: 10px;
      }
    }
    &:last-of-type {
      border: none;
    }
  }
  .content {
    font-size: 14px;
    color: @textColor_first;
  }
}
</style>
