export interface RootPwdListParams extends Utils.SearchVO {
  cluster_id: string
  software: number
  sn_ip: string
}

export interface RootPwdListItem {
  id: number
  ips: string
  device_sn: string
  software_type: number
  product_model: string
  client_name: string
  online_time_int: number
  online_time: string
  last_offline: string
  ops_server_status: number
  machine_status: number
  lotus_server_status: number
  base_info: {
    ops_version: string
    hos_version: string
    CPU: string
    memory: string
    temperature: string
    device_sn: string
    gpu_list: { gpu_model: string }[] | null
    net_list: {
      name: string
      proto: string
      ip: string
      gateway: string
      dns: string
      netmask: string
    }[]
  }
  disk_list: {
    dev_name: string
    space_used: number
    space_all: number
    type: string
    mountpoint: string
  }[]
}

export interface RootPwdListRes extends Utils.PageVO {
  list: RootPwdListItem[]
  online_size: number
  offline_size: number
}

export interface UpdatePwdByRoleParams {
  cluster_id: string
  software_role: number
}

export interface GetUpdateResultItem {
  ips: string
  device_sn: string
  software_type: number
  root_passwd_status: boolean
  passwrod_record_id: number
}

export interface GetUpdateResultRes {
  total_size: number
  online_size: number
  offline_size: number
  list: GetUpdateResultItem[]
}

export interface UpdateSinglePwdParams {
  password: string
  cluster_id: string
  id: number
}

export interface CheckRootPwdParams {
  login_passwd: string
  ids: number[]
}

export interface CheckRootPwdItem {
  device_sn: string
  software_type: number
  root_passwd: string
}

export interface CheckRootPwdRes {
  list: CheckRootPwdItem[]
}

export interface GetUpdatePwdRecordItem {
  id: number
  Time: string
  operation_type: number
  total: number
  success: number
  fail: number
}

export interface GetUpdatePwdRecordRes extends Utils.PageVO {
  list: GetUpdatePwdRecordItem[]
}
