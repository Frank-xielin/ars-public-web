import { UserInfoByIdRes } from '@/models/systemSettings/userManagement/user'
import { ClusterListItem } from '../systemSettings/clusterInformation'

export interface ApprovalListParams extends Utils.SearchVO {
  search: string
  // start_date: string
  // end_date: string
}

export interface ApprovalListItem {
  id: number
  created_at: string
  updated_at: string
  deleted_at: string | null
  target_id: number
  target_type: string
  target: {
    id: number
    created_at: string
    updated_at: string
    deleted_at: string | null
    name: string
    route: string
    http_text: string | null
    http_body: string | null
    script_content: string
    submiter_id: number
    submiter: UserInfoByIdRes
    submit_at: string
    state: number
    miner_id: number | null
    miner: ClusterListItem | null
    auto_submit: boolean
    auto_publish: boolean
    note: string | null
    devices: { device_sn: string }[]
  }
  state: number
  submitor_id: number
  submitor: UserInfoByIdRes
  total_step: number
  current_step: number
  current_node_id: number
  current_node: {
    id: number
    flow_id: number
    step: number
    title: string
    created_at: string
    updated_at: string
    note: string
    state: number
    approver_id: number
    Approver: null
  }
  notifiers: UserInfoByIdRes[]
}

export interface ApprovalListRes extends Utils.PageVO {
  list: ApprovalListItem[]
}
