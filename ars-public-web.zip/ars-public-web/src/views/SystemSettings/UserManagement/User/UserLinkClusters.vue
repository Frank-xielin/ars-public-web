<script lang="ts" setup>
import { useClusterAllList } from '@/composables/systemSettings/clusterInformation'
import {
  columns,
  useUsersClusterManager
} from '@/composables/systemSettings/userManagement/user/userLinkClusters'
import { UserListItem } from '@/models/systemSettings/userManagement/user'
import { computed, watch } from 'vue'

const props = defineProps<{
  visible: boolean
  record: UserListItem | null
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()

const correctUser = computed(() => props.record?.id || 0)

const { dataSource: clusterList, searchAllClusters } = useClusterAllList()
const { usersClusters, getUsersClusters, onSubmit } = useUsersClusterManager(correctUser, () => {
  emit('update:visible', false)
  emit('search')
})

function selectionHandle(keys: Utils.Key[]) {
  usersClusters.value = keys as string[]
}

watch(
  () => props.visible,
  visible => {
    if (visible) {
      getUsersClusters()
      searchAllClusters()
    } else {
      usersClusters.value.length = 0
    }
  }
)
</script>

<template>
  <a-modal
    :visible="visible"
    title="关联集群"
    @cancel="$emit('update:visible', false)"
    @ok="onSubmit"
  >
    <a-table
      row-key="miner"
      v-bind="$tableConfigs(clusterList)"
      :columns="$columnsSetter(columns)"
      :scroll="$scroller(400)"
      :row-selection="{ selectedRowKeys: usersClusters, onChange: selectionHandle }"
    />
  </a-modal>
</template>
