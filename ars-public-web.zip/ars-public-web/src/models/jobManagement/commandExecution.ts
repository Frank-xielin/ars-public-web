export interface PublishTemplateParams {
  miner_id: string
  device_ids: number[]
}

export interface PublishTemplateRes {
  uuid: string
}

export interface GetAnsibleExecParams extends Utils.SearchVO {
  uuid: string
}
