import { message } from 'ant-design-vue'
import { Ref, ref } from 'vue'

export interface RequestOptions<P extends any[], R> {
  onSuccess?: (reply: R, params: P) => void
  onError?: (error: any) => void
}

type ServiceType<R, P extends any[]> = P extends [] ? () => Promise<R> : (...arg: P) => Promise<R>

export default function useRequest<P extends any[], R = null>(
  service: ServiceType<Utils.Result<R>, P>,
  options?: RequestOptions<P, Utils.Result<R>>
) {
  const loading = ref(false)
  const data: Ref<R | null> = ref(null)

  const run = async (...args: P): Promise<Utils.Result<R>> => {
    loading.value = true
    try {
      const reply = await service(...args)
      if (options?.onSuccess) {
        options.onSuccess(reply, args)
      } else if (reply.code !== 0) {
        message.error(reply.msg)
      }
      data.value = reply.data

      return reply
    } catch (error) {
      options?.onError && options.onError(error)
      throw error
    } finally {
      loading.value = false
    }
  }
  // run的参数是请求内容的参数，request是请求配置的参数
  return { loading, data, run }
}
