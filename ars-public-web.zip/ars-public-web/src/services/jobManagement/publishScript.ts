import {
  CreateScriptParams,
  GetScriptInfoRes,
  ScriptListParams,
  ScriptListRes,
  ScriptTypeListRes,
  UpdateScriptParams
} from '@/models/jobManagement/publishScript'
import { request } from '@/utils/httpConfig'

/**
 * 公共脚本创建 - 单个
 * @param data
 * @returns
 */
export function createScriptApi(data: CreateScriptParams) {
  return request({
    url: 'v5/public/public_script/create/one',
    method: 'POST',
    data,
    loading: true
  })
}

/**
 * 公共脚本修改- 单个
 * @param id 目标脚本的 id
 * @param data
 * @returns
 */
export function updateScriptApi(id: number, data: UpdateScriptParams) {
  return request({
    url: `v5/public/public_script/update/id/${id}`,
    method: 'put',
    data,
    loading: true
  })
}

/** 公共脚本获取- 所有 */
export function scriptListAllApi(data: ScriptListParams) {
  return request<ScriptListRes>({
    url: 'v5/public/public_script/get/list',
    method: 'GET',
    data
  })
}

/**
 * 公共脚本获取-单个
 * @param id 目标脚本的 id
 * @returns
 */
export function getScriptInfoApi(id: number) {
  return request<GetScriptInfoRes>({
    url: `v5/public/public_script/get/id/${id}`,
    method: 'GET',
    loading: true
  })
}

/**
 * 公共脚本删除-单个
 * @param id 目标脚本的 id
 * @returns
 */
export function deleteScriptApi(id: number) {
  return request({
    url: `v5/public/public_script/delete/id/${id}`,
    method: 'delete',
    loading: true
  })
}

/**
 * 公共脚本启用-单个
 * @param id 目标脚本的 id
 * @param enable enable 为 true 表示启用，false 表示禁用
 * @returns
 */
export function enableScriptApi(id: number, enable: boolean) {
  return request({
    url: `v5/public/public_script/enable/id/${id}`,
    method: 'patch',
    data: { enable }
  })
}

/**
 * 公共脚本类型创建-单个
 * @param name 脚本名称
 * @returns
 */
export function createScriptTypeApi(name: string) {
  return request({
    url: 'v5/public/public_script_type/create/one',
    method: 'post',
    data: { name },
    loading: true
  })
}

/**
 * 公共脚本类型更新-单个
 * @param id 目标脚本类型的 id
 * @param name 脚本名称
 * @returns
 */
export function updateScriptTypeApi(id: number, name: string) {
  return request({
    url: `v5/public/public_script_type/update/id/${id}`,
    method: 'put',
    data: { name },
    loading: true
  })
}

/** 公共脚本类型获取-所有 */
export function scriptTypeListAllApi() {
  return request<ScriptTypeListRes>({
    url: 'v5/public/public_script_type/get/all',
    method: 'get'
  })
}

/**
 * 公共脚本类型删除-单个
 * @param id 目标脚本类型的 id
 * @returns
 */
export function deleteScriptTypeApi(id: number) {
  return request({
    url: `v5/public/public_script_type/delete/id/${id}`,
    method: 'delete',
    loading: true
  })
}
