import {
  CodeByMinerRes,
  LoginParams,
  LoginRes,
  SmsByPhoneParams,
  SmsCheckParams,
  SmsCheckRes,
  TokenByCodeRes,
  UpdatePwCodeParams,
  UpdatePwOriginParams
} from '@/models/login'
import { request } from '@/utils/httpConfig'

/**
 * 短信验证（登录、修改密码）
 * @param data 传手机号、验证码等信息
 * @returns
 */
export function smsCheckApi(data: SmsCheckParams) {
  return request<SmsCheckRes>({
    url: 'v5/public/sms/check',
    method: 'POST',
    data,
    loading: true
  })
}

/**
 * 通过手机号获取短信（登录、修改密码）
 * @param data
 * @returns
 */
export function smsByPhoneApi(data: SmsByPhoneParams) {
  return request({
    url: 'v5/public/sms/get',
    method: 'post',
    data,
    loading: true
  })
}

/**
 * 登录
 * @param data
 * @returns 返回 token 字符串
 */
export function loginApi(data: LoginParams) {
  return request<LoginRes>({
    url: 'v5/public/base/login',
    method: 'post',
    data
  })
}

/**
 * 退出登录
 * @returns
 */
export function logoutApi() {
  return request({
    url: 'v5/public/auth/logout',
    method: 'post',
    loading: true
  })
}

/**
 * 修改密码（不需要原密码，需要验证码）
 * @param data
 * @returns
 */
export function updatePwCodepi(data: UpdatePwCodeParams) {
  return request({
    url: 'v5/public/base/password/update/forget',
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 修改密码（需要原密码，不需要验证码）
 * @param data
 * @returns
 */
export function updatePwOriginApi(data: UpdatePwOriginParams) {
  return request({
    url: 'v5/public/base/password/update/modify',
    method: 'put',
    data,
    loading: true
  })
}

/**
 * 通过 miner_id 获取 code
 * @param miner_id
 * @returns
 */
export function codeByMinerApi(miner_id: string) {
  return request<CodeByMinerRes>({
    url: 'v5/public/auth/code/get/by_miner',
    method: 'get',
    data: { miner_id },
    loading: true
  })
}

/**
 * 根据 code 获取 token
 * @param code
 * @returns
 */
export function tokenByCodeApi(code: string) {
  return request<TokenByCodeRes>({
    url: 'v5/public/auth/token/get/by_code',
    method: 'get',
    data: { code },
    loading: true
  })
}

/**
 * url 能否访问机器端
 * @param url
 * @returns
 * @deprecated
 */
export function machineOnlineApi(url: string) {
  return request({
    url: 'v5/public/open/machine/get/is_online',
    method: 'get',
    data: { url },
    loading: true
  })
}
