<script lang="ts" setup>
import { useUpdatePw } from '@/composables/login/updatePassword'
import { message } from 'ant-design-vue'

const emit = defineEmits<{ (event: 'backLogin', val: number): void }>()

const { form, formModel, submitForm } = useUpdatePw(() => {
  message.success('密码修改成功')
  emit('backLogin', 0)
})
</script>

<template>
  <a-form
    class="login-form"
    size="large"
    @submit="submitForm"
    :wrapper-col="{ offset: 5, span: 14 }"
  >
    <a-form-item class="login-form-item" v-bind="form.validateInfos.phone">
      <a-input
        placeholder="请输入手机号"
        class="password-input"
        disabled
        :value="formModel.phone"
      />
    </a-form-item>
    <a-form-item class="login-form-item" v-bind="form.validateInfos.new_password">
      <a-input
        placeholder="请输入新密码"
        type="password"
        class="password-input"
        v-model:value="formModel.new_password"
      />
    </a-form-item>
    <a-form-item class="login-form-item" v-bind="form.validateInfos.repeat_new_password">
      <a-input
        placeholder="再次输入新密码"
        type="password"
        class="password-input"
        v-model:value="formModel.repeat_new_password"
      />
    </a-form-item>
    <a-form-item class="login-form-item">
      <a-button class="login-button" type="primary" shape="round" html-type="submit" block>
        提交更改
      </a-button>
    </a-form-item>
  </a-form>
</template>
