<script lang="ts" setup>
import { CreateUserKey } from '@/composables/systemSettings/userManagement/userSetting'
import { provide, readonly, ref } from 'vue'
import { useRoute } from 'vue-router'
import CheckUpdateUser from './UserSetting/CheckUpdateUser.vue'
import CreateUser from './UserSetting/CreateUser.vue'

const route = useRoute()
const isCreate = ref(false)
isCreate.value = route.query.type === 'create'

provide(CreateUserKey, readonly(isCreate))
</script>

<template>
  <div class="check-update-user page">
    <check-update-user v-if="!isCreate" />
    <create-user v-else />
  </div>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.check-update-user {
  :deep(.operate-title) {
    padding: 0 20px 10px;
    font-size: 14px;
    font-weight: bold;
    border-bottom: 1px solid @ueColor_fifth;
  }
  :deep(.operator-wrapper) {
    display: flex;
    justify-content: center;
    margin: 30px;
    > button {
      width: 100px;
      margin: 0 10px;
    }
  }
  :deep(.form-title) {
    max-width: 1214px;
    padding: 10px 10px 23px;
    margin: 0 auto 30px;
    color: @textColor_first;
    font-size: 16px;
    font-weight: bold;
    border-bottom: 1px solid @ueColor_fifth;
  }
  :deep(.user-edit-form) {
    max-width: 1214px;
    margin: auto;
    .ant-form-item {
      width: 45%;
      min-height: 56px;
      margin-bottom: 5px;
      &.ant-form-item-with-help {
        margin-bottom: 5px;
      }
      .ant-form-item-label {
        min-width: 80px;
      }
    }
  }
}
</style>
