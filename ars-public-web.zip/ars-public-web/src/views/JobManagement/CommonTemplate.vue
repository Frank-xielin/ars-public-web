<script lang="ts" setup>
import FormRender, { FormRenderExpose } from '@/components/FormRender.vue'
import {
  columns,
  useDeleteTemplate,
  useTemplateList
} from '@/composables/jobManagement/commonTemplate'
import { useEnableTemplate } from '@/composables/jobManagement/commonTemplate/checkTemplate'
import { useTemplateTypeAllList } from '@/composables/jobManagement/commonTemplate/templateTypeTable'
import { FormRenderOptions } from '@/models/formRender'
import { TemplateListItem, TemplateListParams } from '@/models/jobManagement/commonTemplate'
import router from '@/router'
import { scroller } from '@/utils/formTools'
import { cloneDeep } from 'lodash-es'
import { computed, ref } from 'vue'

const formRef = ref<FormRenderExpose>()
const { pageVo, searchModel, dataSource, handleSearch } = useTemplateList()
const { dataSource: typeList, run } = useTemplateTypeAllList()
const { deleteTemplate } = useDeleteTemplate(() => formRef.value?.onSearch())
const { enableTemplate } = useEnableTemplate(() => formRef.value?.onSearch())

const types = computed(() => {
  const arr = cloneDeep(typeList.value)
  arr.unshift({ created_at: '', id: 0, name: '全部', updated_at: '' })
  return arr
})
const formOp = (): FormRenderOptions<Utils.NoPager<TemplateListParams>, TemplateListItem> => ({
  queryParams: [
    {
      label: 'type_id',
      type: 'select',
      formLabel: '模板类型',
      style: { width: '100px' },
      selectOptions: {
        data: types.value,
        labelField: 'name',
        valueField: 'id'
      }
    },
    { label: 'content', type: 'search', placeholder: '模板内容' }
  ],
  reset: true,
  pager: true,
  initialValues: { type_id: 0, content: '' },
  tableConfigs: {
    columns,
    tableProps: { scroll: scroller('calc(100vh - 330px)'), rowKey: r => r.id },
    async onSearch(values, vo) {
      searchModel.value = values
      await handleSearch(vo)
      run().catch()
      return { res: dataSource.value, vo: pageVo.value }
    }
  }
})

function checkUpdateTemp(id: number, type: 'edit' | 'check') {
  router.push({
    path: '/JobManagement/CommonTemplate/CheckTemplate',
    query: { id, type }
  })
}
</script>

<template>
  <div class="common-template page">
    <form-render :op="formOp()" ref="formRef">
      <template #preItem>
        <a-form-item class="add-operator">
          <a-button
            class="add-btn"
            type="primary"
            @click="$router.push('/JobManagement/CommonTemplate/CreateTemplate')"
            :disabled="!$auth(45, 'menu')"
          >
            <icon-font type="icon-icon_add" style="color: #fff" />
            新建
          </a-button>
        </a-form-item>
      </template>
      <template #tableRender="{ column, text, record }">
        <div v-if="column.title === '操作'">
          <a-button
            type="link"
            class="table-btn"
            @click="checkUpdateTemp(text, 'check')"
            :disabled="!$auth(46, 'menu')"
          >
            查看
          </a-button>
          <a-button
            type="link"
            v-if="!record.enabled"
            class="table-btn"
            @click="checkUpdateTemp(text, 'edit')"
            :disabled="!$auth(85)"
          >
            编辑
          </a-button>
          <a-button
            type="link"
            v-if="!record.enabled"
            class="table-btn"
            @click="deleteTemplate(text)"
            :disabled="!$auth(88)"
          >
            删除
          </a-button>
          <a-button
            type="link"
            class="table-btn"
            @click="enableTemplate(text, !record.enabled)"
            :disabled="!$auth(89)"
          >
            {{ record.enabled ? '弃用' : '启用' }}
          </a-button>
        </div>
        <template v-else-if="column.title === '启用'">
          <icon-font v-if="text" type="icon-normal" />
          <span v-else>-</span>
        </template>
        <custom-tooltip v-else-if="column.title === '模板内容'" :title="text">
          <span class="template-content">{{ text }}</span>
        </custom-tooltip>
        <custom-tooltip v-else>{{ text }}</custom-tooltip>
      </template>
    </form-render>
  </div>
</template>

<style scoped lang="less">
.add-operator {
  position: absolute;
  right: 0;
}
.template-content {
  display: inline-block;
  width: 100%;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  word-break: keep-all;
}
</style>
