export interface TemplateTypeItem {
  id: number
  name: string
  created_at: string
  updated_at: string
}

export type TemplateTypeAllRes = TemplateTypeItem[]

export interface CreateTemplateParams {
  type_id?: number
  name: string
  content: string
  note: string
  enabled: boolean
}

export interface TemplateListParams extends Utils.SearchVO {
  type_id?: number
  enabled?: boolean
  content: string
}

export interface TemplateListItem {
  id: number
  template_name: string
  template_type: string
  template_type_id: number
  created_at: string
  updated_at: string
  updater: string
  enabled: boolean
  content: string
  creator: string
  note: string
}

export interface TemplateListRes extends Utils.PageVO {
  list: TemplateListItem[]
}

export type TemplateInfoRes = TemplateListItem

export type UpdateTemplateParams = CreateTemplateParams
