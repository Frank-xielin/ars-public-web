import {
  requireInput,
  requireSelect
} from '@/composables/systemSettings/clusterInformation/addEditCluster'
import { CreateBrokenRecordParams } from '@/models/workbench/errorRecord'
import { createBrokenRecordApi, updateBrokenRecordApi } from '@/services/workbench/errorRecord'
import { Form, message } from 'ant-design-vue'
import { Dayjs } from 'dayjs'
import { isObject } from 'lodash-es'
import { ref } from 'vue'
import { ModalType } from './'

interface BrokenRecordForm extends Omit<CreateBrokenRecordParams, 'record_time'> {
  record_time: string | Dayjs
}

/**
 * 修改/创建故障记录
 * @param type 新建/修改
 * @param successFn
 * @returns
 */
export function useChangeBrokenRecord(type: Utils.Prop<ModalType>, successFn: () => void) {
  const formModel = ref<BrokenRecordForm>({
    fault_description: '',
    fault_grade: 0,
    fault_reason: '',
    fault_sort: 0,
    miner_id: '',
    processing_status: 0,
    record_time: ''
  })
  const rules = ref<Utils.RulesObject<BrokenRecordForm>>({
    record_time: [requireSelect('故障日期')],
    miner_id: [requireSelect('集群')],
    fault_description: [requireInput('故障描述')],
    fault_reason: [requireInput('故障原因')],
    fault_sort: [requireSelect('故障分类')],
    fault_grade: [requireSelect('故障等级')],
    processing_status: [requireSelect('处理状态')]
  })
  const form = Form.useForm(formModel, rules)

  async function submitForm(id?: number) {
    try {
      await form.validate()
      const values = formModel.value
      const params: CreateBrokenRecordParams = {
        ...values,
        record_time: isObject(values.record_time)
          ? values.record_time.format('YYYY-MM-DD HH:mm:ss')
          : values.record_time
      }
      const reply =
        type.value === '新建'
          ? await createBrokenRecordApi(params)
          : await updateBrokenRecordApi(id ?? 0, params)
      if (reply.code === 0) {
        message.success(`${type.value}记录成功`)
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { formModel, form, submitForm }
}
