<script lang="ts" setup>
import { useCreateDevices } from '@/composables/workbench/hostManagement'
import { useUploadInput } from '@/composables/workbench/hostManagement/importDeviceModal'
import { message } from 'ant-design-vue'
import { ref } from 'vue'

const props = defineProps<{
  visible: boolean
  minerId: string
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'search'): void
}>()

const errorMsg = ref('')
const { inputRef, fileInfo, getFile, cleanFileInfo } = useUploadInput()
const { importDevices } = useCreateDevices(() => {
  emit('search')
  onCancel()
})

function handleUpload() {
  if (fileInfo.value.fileData) {
    importDevices(props.minerId, fileInfo.value.fileData)
  } else {
    message.warn('请选择一个文件上传')
  }
}
function onCancel() {
  emit('update:visible', false)
  cleanFileInfo()
}
</script>

<template>
  <a-modal
    title="上传文件"
    :width="430"
    :visible="visible"
    @cancel="onCancel"
    @ok="handleUpload"
    :ok-button-props="{ disabled: !$auth(21) }"
  >
    <input type="file" hidden ref="inputRef" @change="getFile" />
    <div class="my-upload-box">
      <a-input readonly :value="fileInfo.fileName" placeholder="导入文件（.csv）" />
      <a-button @click="inputRef?.click()">选择</a-button>
    </div>
    <p class="error-tips">{{ errorMsg }}</p>
  </a-modal>
</template>

<style scoped lang="less">
@import (reference) '@/assets/styles/index.less';

.my-upload-box {
  margin-top: 30px;
  input {
    width: 295px;
    margin-right: 20px;
  }
}
.error-tips {
  margin: 10px 0 40px;
  color: @errorColor;
  text-align: center;
}
</style>
