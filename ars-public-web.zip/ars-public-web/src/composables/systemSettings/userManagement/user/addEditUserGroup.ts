import { ModalType } from '@/composables/workbench/errorRecord'
import { CreateUserGroupParams } from '@/models/systemSettings/userManagement/user'
import {
  createUserGroupApi,
  updateUserGroupApi
} from '@/services/systemSettings/userManagement/user'
import { Form, message } from 'ant-design-vue'
import { ref } from 'vue'
import { requireInput } from '../../clusterInformation/addEditCluster'

export function useEditUserGroup(type: Utils.Prop<ModalType>, successFn: () => void) {
  const formModel = ref<CreateUserGroupParams>({
    group_name: '',
    note: '',
    parent_id: 0
  })
  const rules = ref<Utils.RulesObject<CreateUserGroupParams>>({
    group_name: [requireInput('组名')],
    parent_id: [requireInput('父级')]
  })
  const form = Form.useForm(formModel, rules)

  async function handleSubmit(id = 0) {
    try {
      await form.validate()
      const reply =
        type.value === '新建'
          ? await createUserGroupApi(formModel.value)
          : await updateUserGroupApi(id, formModel.value)
      if (reply.code === 0) {
        message.success(`${type.value}分组成功`)
        successFn()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { form, formModel, handleSubmit }
}
