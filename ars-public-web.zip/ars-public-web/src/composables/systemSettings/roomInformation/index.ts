import { message } from 'ant-design-vue'
import { ref } from 'vue'

import { usePagination } from '@/common/usePagination'
import useRequest from '@/common/useRequest'
import { GetRoomListItem } from '@/models/systemSettings/roomInfomation'
import { getRoomListApi } from '@/services/systemSettings/roomInfomation'

export const columns: Utils.ColumnField<GetRoomListItem>[] = [
  { title: '机房名称', dataIndex: 'name' },
  { title: '机房所在地', dataIndex: 'site' },
  { title: '域名', dataIndex: 'domain' },
  { title: '算力机是否可调度', dataIndex: 'scheduling' },
  { title: '操作', dataIndex: 'id' }
]

export function useRoomList() {
  const dataSource = ref<GetRoomListItem[]>([])
  const { pageVo, setPageFromData } = usePagination()

  const { run: roomListFetch, loading } = useRequest(getRoomListApi, {
    onSuccess: reply => {
      const { code, data, msg } = reply
      if (code === 0) {
        dataSource.value = data?.list || []
        setPageFromData(data)
      } else {
        message.error(msg)
      }
    }
  })

  async function handleSearch(vo?: Utils.SearchVO) {
    try {
      const params: Utils.SearchVO = {
        page: vo?.page ?? 1,
        page_size: vo?.page_size ?? pageVo.value.page_size
      }
      return roomListFetch(params)
    } catch (e) {}
  }

  return { dataSource, pageVo, loading, handleSearch }
}
