export interface UsersClusterListItem {
  id: number
  miner: string
  sector_size: number
  client_name: string
}

export type UsersClusterListRes = UsersClusterListItem[]

export interface BatchCreateDevicesItem {
  sn: string
  software_type: string
  client_id: string
  product_model: string
}

export interface BatchCreateDevicesParams {
  miner_id: string
  list: BatchCreateDevicesItem[]
}

export interface DeviceListParams extends Utils.SearchVO {
  miner_id: string
  software_type: number
  worker_status: number
  machine_status: number
  sn_ip: string
}

export interface DeviceNetListItem {
  name: string
  proto: string
  ip: string
  gateway: string
  dns: string
  netmask: string
}

export interface DeviceBaseInfo {
  ops_version: string
  hos_version: string
  CPU: string
  memory: string
  temperature: string
  device_sn: string
  gpu_list: { gpu_model: string }[] | null
  net_list: DeviceNetListItem[]
}

export interface DeviceDiskListItem {
  dev_name: string
  space_used: number
  space_all: number
  type: string
  mountpoint: string
}

export interface DeviceListItem {
  id: number
  ips: string
  device_sn: string
  client_name: string
  software_type: number
  product_model: string
  ops_server_status: number
  online_time: string
  last_offline: null
  worker_status: number
  machine_status: number
  lotus_server_status: number
  base_info: DeviceBaseInfo
  disk_list: DeviceDiskListItem[]
  is_approved: boolean
}

export interface DeviceListRes extends Utils.PageVO {
  list: DeviceListItem[]
  online_size: number
  offline_size: number
}

export interface DeviceOperationListParams extends Utils.SearchVO {
  start_time: string
  end_time: string
  key: string
  sn: string
}

export interface DeviceOperationListItem {
  created_at: string
  operation: string
  user_name: string
}

export interface DeviceOperationListRes extends Utils.PageVO {
  list: DeviceOperationListItem[]
}

export interface BatchUpdateMachinesStatParams {
  ids: number[]
  status: number
}

export interface ShutdownDevicesParams {
  sns: string[]
  miner_id: string
  message: string
}

export type BatchRemoveFaultMachinesParams = ShutdownDevicesParams

export type RebootDevicesParams = ShutdownDevicesParams

export type StartLotusParams = ShutdownDevicesParams

export type RestartLotusParams = ShutdownDevicesParams

export type StopLotusParams = ShutdownDevicesParams
