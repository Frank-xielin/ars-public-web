<script lang="ts" setup>
import { useUserTabManager } from '@/composables/systemSettings/userManagement/user'
import UserGroupManageTab from './User/UserGroupManageTab.vue'
import UserManageTab from './User/UserManageTab.vue'

const { activeTab } = useUserTabManager()
</script>

<template>
  <div class="user-management page">
    <a-tabs v-model:active-key="activeTab">
      <a-tab-pane tab="用户" key="user">
        <user-manage-tab />
      </a-tab-pane>
      <a-tab-pane tab="用户组" key="group">
        <user-group-manage-tab />
      </a-tab-pane>
    </a-tabs>
  </div>
</template>

<style lang="less" scoped>
.user-management {
  padding-top: 0 !important;
}
</style>
