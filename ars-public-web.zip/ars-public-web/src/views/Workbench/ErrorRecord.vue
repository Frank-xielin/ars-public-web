<script lang="ts" setup>
import {
  columns,
  deleteBrokenRecord,
  errorLevelList,
  errorTypeList,
  processStateList,
  useAddEditModal,
  useBrokenRecordList
} from '@/composables/workbench/errorRecord'
import { BrokenRecordListItem } from '@/models/workbench/errorRecord'
import AddOrEditRecord from './ErrorRecord/AddOrEditRecord.vue'

const {
  visible: editVisible,
  modalType,
  targetInfo,
  editModal,
  addModal
} = useAddEditModal<BrokenRecordListItem>()
const { dataSource, pageVo, searchModel, loading, form, handleSearch } = useBrokenRecordList()

function resetForm() {
  form.resetFields()
  handleSearch()
}
handleSearch()
</script>

<template>
  <div class="error-record page">
    <a-form class="search-form-wrapper" layout="inline" @submit="handleSearch()">
      <a-form-item>
        <custom-select
          class="search-select"
          :data="errorTypeList"
          v-model:value="searchModel.fault_sort"
          @change="handleSearch()"
        />
        <custom-select
          class="search-select"
          :data="errorLevelList"
          v-model:value="searchModel.fault_grade"
          @change="handleSearch()"
        />
        <custom-select
          class="search-select"
          :data="processStateList"
          v-model:value="searchModel.processing_status"
          @change="handleSearch()"
        />
      </a-form-item>
      <a-form-item>
        <a-range-picker
          separator="至"
          format="YYYY-MM-DD HH:mm:ss"
          v-model:value="searchModel.dates"
          @change="handleSearch()"
        />
      </a-form-item>
      <a-form-item>
        <custom-search-input
          class="search-input"
          placeholder="集群ID\客户"
          v-model:value="searchModel.search"
          @search-func="handleSearch()"
        />
        <a-button @click="resetForm">清空</a-button>
      </a-form-item>
      <a-form-item class="add-record">
        <a-button :disabled="!$auth(34)" type="primary" shape="round" @click="addModal">
          新建记录
        </a-button>
      </a-form-item>
    </a-form>

    <a-table
      class="table-box"
      v-bind="$tableConfigs(dataSource, loading, pageVo, handleSearch)"
      row-key="id"
      :scroll="$scroller('calc(100vh - 300px)')"
      :columns="$columnsSetter(columns)"
    >
      <template #bodyCell="{ column: col, text, record }">
        <template v-if="col.title === '操作'">
          <a-button type="link" class="table-btn" :disabled="!$auth(35)" @click="editModal(record)">
            编辑
          </a-button>
          <a-button
            type="link"
            class="table-btn"
            :disabled="!$auth(36)"
            @click="deleteBrokenRecord(record.id, () => handleSearch(pageVo))"
          >
            删除
          </a-button>
        </template>
        <custom-tooltip v-else>
          <template v-if="col.title === '故障分类'">
            {{ errorTypeList.find(item => item.value === text)?.label }}
          </template>
          <template v-else-if="col.title === '故障等级'">
            {{ errorLevelList.find(item => item.value === text)?.label }}
          </template>
          <template v-else-if="col.title === '处理状态'">
            {{ processStateList.find(item => item.value === text)?.label }}
          </template>
          <template v-else-if="col.title === '所属客户'">{{ text?.name }}</template>
          <template v-else-if="col.title === '记录人'">{{ text?.user_name }}</template>
          <template v-else>{{ text }}</template>
        </custom-tooltip>
      </template>
    </a-table>
    <add-or-edit-record
      @search="handleSearch(modalType === '编辑' ? pageVo : undefined)"
      v-model:visible="editVisible"
      :record-detail="targetInfo"
      :modal-type="modalType"
    />
  </div>
</template>

<style scoped lang="less">
.search-input {
  width: 200px;
  margin-right: 10px;
}
.search-select {
  width: 100px;
  margin-right: 10px;
}
.search-form-wrapper {
  position: relative;
  .add-record {
    position: absolute;
    right: 0;
    bottom: 0;
  }
}

@media screen and (max-width: 1547px) {
  .search-form-wrapper {
    .add-record {
      position: unset;
      margin-top: 10px;
    }
  }
}
</style>
