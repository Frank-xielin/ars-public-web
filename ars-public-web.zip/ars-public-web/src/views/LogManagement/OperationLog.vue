<script lang="ts" setup>
import { activeLogTab } from '@/composables/logManagement/operationLog/logTablePane'
import { provide, readonly, ref } from 'vue'
import LogTablePane from './OperationLog/LogTablePane.vue'

const activeTab = ref<'cluster' | 'system'>('cluster')
provide(activeLogTab, readonly(activeTab))
</script>

<template>
  <div class="operation-log page">
    <a-tabs v-model:active-key="activeTab">
      <a-tab-pane tab="集群操作" key="cluster">
        <log-table-pane />
      </a-tab-pane>
      <a-tab-pane tab="系统操作" key="system">
        <log-table-pane />
      </a-tab-pane>
    </a-tabs>
  </div>
</template>
