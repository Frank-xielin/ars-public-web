<script lang="ts" setup>
import { useCreateScriptType } from '@/composables/jobManagement/publishScript/createScriptType'
import { watch } from 'vue'

const props = defineProps<{
  visible: boolean
}>()
const emit = defineEmits<{
  (event: 'update:visible', val: boolean): void
  (event: 'submit'): void
}>()

const { name, createType } = useCreateScriptType(() => {
  emit('update:visible', false)
  emit('submit')
})

watch(
  () => props.visible,
  val => {
    if (val) {
      name.value = ''
    }
  }
)
</script>

<template>
  <a-modal
    title="添加脚本类型"
    :visible="visible"
    @cancel="$emit('update:visible', false)"
    @ok="createType"
  >
    <a-input style="margin: 20px 0" placeholder="脚本类型名称" v-model:value="name" />
  </a-modal>
</template>
