export interface MessageListParams extends Utils.SearchVO {
  search: string
  start_date: string
  end_date: string
  is_read?: boolean
}

export interface MessageListItem {
  id: number
  created_at: string
  updated_at: string
  title: string
  content: string
  has_been_read: boolean
  metadata: {
    reason: string
    cluster: string
    datetime: string
    submitor: string
    operation: string
  }
  metadata_type: string
}

export interface MessageListRes extends Utils.PageVO {
  list: MessageListItem[]
}
