import { CurrentUserLogsRes, UpdateCurrentUserParams } from '@/models/personal/personalInfomation'
import { request } from '@/utils/httpConfig'

/** 登录历史-当前用户信息 */
export function currentUserLogsApi() {
  return request<CurrentUserLogsRes>({
    url: 'v5/public/self/log/login/get/list',
    method: 'GET',
    loading: true
  })
}

/**
 * 修改当前用户信息
 * @param data
 * @returns
 */
export function updateCurrentUserApi(data: UpdateCurrentUserParams) {
  return request({
    url: 'v5/public/self/user/update/info',
    method: 'put',
    data,
    loading: true
  })
}
