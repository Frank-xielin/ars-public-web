import {
  requireInput,
  requireSelect
} from '@/composables/systemSettings/clusterInformation/addEditCluster'
import { TemplateInfoRes, UpdateTemplateParams } from '@/models/jobManagement/commonTemplate'
import router from '@/router'
import {
  enableTemplateApi,
  templateInfoApi,
  updateTemplateApi
} from '@/services/jobManagement/commonTemplate'
import { Form, message, Modal } from 'ant-design-vue'
import { ref } from 'vue'
import { useRoute } from 'vue-router'
import { templateFormValues } from './createTemplate'

/** 编辑公共模板 */
export function useUpdateTemplate(id: Utils.Prop<number>, successFn?: () => void) {
  const formModel = ref<UpdateTemplateParams>({ ...templateFormValues })
  const rules = ref<Utils.RulesObject<UpdateTemplateParams>>({
    type_id: [requireSelect('模板类型')],
    name: [requireInput('模板名称')],
    content: [requireInput('模板内容')]
  })
  const form = Form.useForm(formModel, rules)

  async function submitForm() {
    try {
      await form.validate()
      const reply = await updateTemplateApi(id?.value ?? 0, formModel.value)
      if (reply.code === 0) {
        message.success('编辑模板成功')
        successFn?.()
      } else {
        message.error(reply.msg)
      }
    } catch (e) {}
  }

  return { formModel, form, submitForm }
}

/** 获取指定公共模板的信息 */
export function useGetTemplateInfo() {
  const route = useRoute()
  const templateId = ref(0)
  const isEdit = ref(false)
  const templateModel = ref<TemplateInfoRes | null>(null)

  async function getTemplateInfo() {
    try {
      const reply = await templateInfoApi(templateId.value)
      const { code, data, msg } = reply
      if (code === 0) {
        templateModel.value = data
      } else {
        message.error(msg)
      }
    } catch (e) {}
  }

  function initTemplate() {
    const { id, type } = route.query
    if (!id || isNaN(+id)) {
      message.warn('无效的模板id！')
      router.push('/JobManagement/CommonTemplate')
      return
    }
    if (type === 'edit') {
      isEdit.value = true
    }
    templateId.value = +id
    getTemplateInfo()
  }

  return { templateModel, isEdit, templateId, initTemplate, getTemplateInfo }
}

/**
 * 启用目标模板
 * @param id 模板 id
 * @param successFn
 * @returns
 */
export function useEnableTemplate(successFn: () => void) {
  function enableTemplate(id: number, enable: boolean) {
    Modal.confirm({
      content: `是否${enable ? '启用' : '停用'}指定模板？`,
      async onOk() {
        try {
          const reply = await enableTemplateApi(id, enable)
          if (reply.code === 0) {
            message.success(`${enable ? '启用' : '停用'}成功`)
            successFn()
          } else {
            message.error(reply.msg)
          }
        } catch (e) {}
      }
    })
  }

  return { enableTemplate }
}
