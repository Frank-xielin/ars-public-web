/** 定义 emit 的类型 */
function emitter(): () => void
function emitter<T extends any[]>(): (...args: T) => void
function emitter<T extends any[]>() {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  return (...args: T) => true
}

export default emitter
