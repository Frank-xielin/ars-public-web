import useRequest from '@/common/useRequest'
import { DeviceListItem } from '@/models/workbench/hostManagement'
import { batchUpdateMachinesStatApi } from '@/services/workbench/hostManagement'
import { requestHandler } from '@/utils/formTools'

export const columns: Utils.ColumnField<DeviceListItem>[] = [
  { title: '主机SN', dataIndex: 'device_sn', width: 120 },
  { title: '资产归属', dataIndex: 'client_name', width: 100 },
  { title: '软件角色', dataIndex: 'software_type', width: 100 },
  { title: '产品型号', dataIndex: 'product_model', width: 150 },
  { title: 'IP', dataIndex: 'ips', width: 100 },
  { title: '在线时长', dataIndex: 'online_time', width: 100 },
  { title: '最近离线时间', dataIndex: 'last_offline', width: 100 },
  { title: '是否故障', dataIndex: 'machine_status', width: 100 },
  { title: '服务状态', dataIndex: 'ops_server_status', width: 100 },
  { title: 'lotus状态', dataIndex: 'lotus_server_status', width: 100 },
  { title: '详情', dataIndex: 'id', width: 50 }
]
export const machineErrorList = [
  { value: 1, label: '否' },
  { value: 2, label: '是' }
]

/**
 * 批量标注故障机
 * @param successFn
 * @returns
 */
export function useUpdateMachinesStatus(successFn: () => void) {
  const { run } = useRequest(batchUpdateMachinesStatApi, {
    onSuccess: reply => {
      if (reply.code === 0) {
        successFn()
      }
      requestHandler('修改成功')(reply)
    }
  })

  const changeMachinesStatus = (status: number, list: DeviceListItem[]) => {
    run({ ids: list.map(item => item.id), status }).catch()
  }

  return { changeMachinesStatus }
}
