import useRequest from '@/common/useRequest'
import { LoginParams, SmsCodeType } from '@/models/login'
import router from '@/router'
import { loginApi, smsByPhoneApi, smsCheckApi } from '@/services/login'
import { RSAEncryption } from '@/utils/cryptage'
import { strEquals } from '@/utils/dataJudgement'
import { requestHandler } from '@/utils/formTools'
import { getLastPath } from '@/utils/routerController'
import storage from '@/utils/storage'
import { storageKeys } from '@/utils/storage/storageList'
import { Form, message } from 'ant-design-vue'
import { Base64 } from 'js-base64'
import Cookies from 'js-cookie' // 设置cookies全局变量
import { inject, Ref, ref, watch } from 'vue'
import { ChangeUserFnKey } from '.'
import { requireInput } from '../systemSettings/clusterInformation/addEditCluster'

export interface TokenInfo {
  user_id: number
  user_name: string
  buffer_time: number
  exp: number
  iss: string
  nbf: number
}

const crypto = new RSAEncryption()

/**
 * 根据请求结果动态触发验证码校验
 * @param val
 * @param codeError
 * @returns
 */
export function codeValidator(val: string, codeError: boolean) {
  if (!val) {
    return Promise.resolve()
  } else if (codeError) {
    return Promise.reject('验证码错误')
  }
  return Promise.resolve()
}

export function useLogin(changePwFn: () => void) {
  const action = ref(false)
  const isReadyToPush = ref(false)
  const loginForm = ref<LoginParams>({ phone: '', password: '', sms_code: '' })
  const rules = ref<Utils.RulesObject<LoginParams>>({
    phone: [requireInput('手机号'), { pattern: /^1([3-9])\d{9}$/, message: '手机号格式错误' }],
    password: [requireInput('密码')],
    sms_code: [
      requireInput('验证码'),
      { validator: (_, val) => codeValidator(val, codeError.value) }
    ]
  })
  const form = Form.useForm(loginForm, rules)
  const changeUser = inject(ChangeUserFnKey)
  const { codeError, checkCode } = useVerifyCode(loginForm, () => form.validate('sms_code'))

  /** 提交登录信息 */
  async function submitLogin() {
    try {
      await form.validate()
      // 开始登录动画
      action.value = true
      const rsaPw = await inputValidator()
      const reply = await loginApi({ ...loginForm.value, password: rsaPw })
      const { code, data, msg } = reply
      if (code === 0 && data) {
        Cookies.set(storageKeys.token, data.token, { secure: true }) // 缓存jwt
        const tokenObj: TokenInfo = JSON.parse(Base64.decode(data.token.split('.')[1]))
        storage.setItem(storageKeys.userId.key, tokenObj.user_id, storageKeys.userId.module)
        isReadyToPush.value = true
      } else {
        if (code === 2) {
          changeUser?.('phone', loginForm.value.phone)
          changeUser?.('origin_password', loginForm.value.password)
          changePwFn()
        }
        message.error(msg)
        throw new Error('登录失败')
      }
    } catch (error) {
      // 登录异常，立刻停止登录动画
      action.value = false
    }
  }

  /** 登录前校验 */
  async function inputValidator() {
    const rsaPw = crypto.encode(loginForm.value.password)
    if (!rsaPw) {
      message.error('密码无效，请重新输入！')
      throw new Error('登录失败')
    }
    const isValidCode = await checkCode('login')
    if (!isValidCode) {
      throw new Error('登录失败')
    }
    return rsaPw
  }

  watch(action, act => {
    let index = 0
    let stop: NodeJS.Timer | null = null
    if (act) {
      // 当登录动画开始时，启动定时监测
      stop = setInterval(() => {
        if (isReadyToPush.value && index >= 3) {
          // 如果请求成功完成且耗时大于等于五秒则跳转页面
          stop && clearInterval(stop)
          backToLastView()
        } else {
          index++
        }
      }, 1000)
    } else {
      // 因为出错而强制停止动画时取消计时器
      stop && clearInterval(stop)
    }
  })

  return { form, loginForm, submitLogin, action }
}

export interface VerifyCodeForm {
  phone: string
  sms_code: string
}

/** 校验验证码 */
export function useVerifyCode(formModel: Ref<VerifyCodeForm>, errorFn: () => void) {
  const codeError = ref(false)

  /**
   * 请求验证码是否正确
   * @param type 验证类型
   * @returns
   */
  async function checkCode(type: SmsCodeType) {
    const validReply = await smsCheckApi({
      sms_type: type,
      phone: formModel.value.phone,
      sms_code: formModel.value.sms_code
    })
    if (validReply.code !== 0) {
      codeError.value = true
      errorFn()
      return false
    }
    return true
  }

  watch(
    () => formModel.value.sms_code,
    code => {
      if (code) {
        codeError.value = false
      }
    }
  )

  return { codeError, checkCode }
}

/** 根据手机号接收验证码 */
export function useSmsByPhone() {
  const readyToSend = ref(true)
  // 剩余时间
  const excessTime = ref(0)
  const timer = ref<NodeJS.Timer | null>(null)

  const { run: getCodeBySms } = useRequest(smsByPhoneApi, {
    onSuccess: reply => {
      const { code } = reply
      if (code === 0) {
        readyToSend.value = false
        excessTime.value = 60
        countDown()
      }
      requestHandler('验证码发送成功，15分钟内有效')(reply)
    }
  })

  function countDown() {
    if (timer.value) {
      clearInterval(timer.value)
    }
    // 获取到验证码后开始计时，六十秒内不能再发送新验证码
    timer.value = setInterval(() => {
      excessTime.value--
      if (!excessTime.value) {
        readyToSend.value = true
        timer.value && clearInterval(timer.value)
      }
    }, 1000)
  }

  return { readyToSend, excessTime, getCodeBySms }
}

/** 返回登录前一页，如果不是同域名的页面则直接去主页 */
function backToLastView() {
  const last = getLastPath()
  if (
    last?.substring(1) &&
    !strEquals(last, '/Login') &&
    !strEquals(last, '/Personal/PersonalInfomation')
  ) {
    router.back()
  } else {
    router.push({ path: '/' })
  }
}
