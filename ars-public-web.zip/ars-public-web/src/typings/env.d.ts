// 环境变量类型声明

interface ImportMetaEnv {
  VITE_BASE_URL: string
}
